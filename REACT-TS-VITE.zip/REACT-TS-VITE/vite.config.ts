/// <reference types="vitest" />
import { ConfigEnv, defineConfig, loadEnv, UserConfig } from 'vite';
import react from '@vitejs/plugin-react';
import vitePluginImp from 'vite-plugin-imp';
// 调试时检查 Vite 插件的中间状态插件
import Inspect from 'vite-plugin-inspect';
import { resolve } from 'path';
import fs from 'fs';

/**
 * 获取自定义环境变量
 * @param mode 环境模式
 * @param envDir 修改环境变量保存目录
 * @param envDir 增加自定义环境变量前缀
 * @returns
 */
const getEnv = (mode: string, envDir?: string, envPrefix?: string[]) => {
  // 增加自定义环境变量前缀：FG
  const _envPrefix = ['VITE_', ...(envPrefix ?? [])];
  // 获取环境变量，如指定环境变量目录，则第二个参数需要与新目录对应
  return loadEnv(mode, envDir, _envPrefix);
};

const isHttps = (
  enableHttps: boolean | string,
  host: string | boolean = '0.0.0.0',
) => {
  if (typeof enableHttps === 'string') {
    enableHttps = enableHttps === 'true';
  }
  return enableHttps
    ? {
      host, // 激活Network地址，"0.0.0.0"表示用IP地址显示。
      // https: {
      //   // 启用https（http2），配置自签证书
      //   key: fs.readFileSync('./.cert/rootCA-key.pem'),
      //   cert: fs.readFileSync('./.cert/rootCA.pem'),
      // },
    }
    : {};
};

// https://vitejs.dev/config/
export default defineConfig(({ /*command, */ mode }: ConfigEnv): UserConfig => {
  // 修改环境变量目录，目录结构更清晰
  const envDir = './.env';
  // 增加自定义环境变量前缀：NBS
  const envPrefix = ['VITE_', 'NBS_'];
  // 获取环境变量
  const importEnv = getEnv(mode, envDir, envPrefix);

  const config: UserConfig = {
    test: {
      globals: true,
    },
    // logLevel: 'error',
    // 修改环境变量目录，目录结构更清晰
    envDir,
    // 增加自定义环境变量前缀：NBS
    envPrefix,
    // vite Environment Variables环境变量-定义全局常量替换方式
    // https://cn.vitejs.dev/config/shared-options.html#define
    define: {
      appName: JSON.stringify('test-fangle'),
    },
    plugins: [
      react(),
      vitePluginImp({
        libList: [
          {
            libName: 'antd',
            style: (name) => `antd/es/${name}/style`,
          },
        ],
      }),
      // 调试时显示编译代码中间状态 http://localhost:28/__inspect
      Inspect(),
    ],
    css: {
      // CSS模块化文件以.module.[css|less|scss]结尾
      modules: {
        /**
         * 样式名替换规则
         * 参数：
         * [name]：less模块名
         * [local]：替换的样式名
         * [hash:base64:5]：5位随机hash值
         *
         * 用例：替换FormView.module.less文件中.demo-form样式名位唯一键
         * 规则：[name]__[local]___[hash:base64:5]
         * 结果：FormView-module__demo-form___MJy-e
         */
        generateScopedName: '[name]__[local]___[hash:base64:5]',
        hashPrefix: 'prefix',
      },
      preprocessorOptions: {
        less: {
          javascriptEnabled: true,
          modifyVars: {
            // '@primary-color': '#000000', // 设置antd主题色4377FE
            hack: `true; @import (reference) "${resolve(
              'src/assets/styles/antd.reset.less',
            )}";`,
          },
        },
      },
    },
    server: {
      open: true, // 自动打开浏览器预览
      port: Number(importEnv.VITE_APP_BASE_PORT), // 配置端口号，防止端口冲突
      ...isHttps(importEnv.VITE_APP_ENABLE_HTTPS), // 是否开启HTTPS
    },
    resolve: {
      alias: [
        { find: /^~/, replacement: '' },
        { find: '@', replacement: resolve(__dirname, './src') },
      ],
    },
    build: {
      rollupOptions: {
        input: {
          index: resolve(__dirname, 'index.html'),
          // form: resolve(__dirname, 'form/index.html'),
        },
      },
    },
  };
  return config;
});
