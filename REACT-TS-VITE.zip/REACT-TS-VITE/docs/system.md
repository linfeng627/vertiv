# 系统编译环境

## 编译环境

- 操作系统不限
- Chrome 浏览器
- VsCode
- Node.js `v16+`
- [`pnpm`](https://pnpm.io/)（也可以通过 npm 安装 pnpm）

  ```sh
  npm install -g pnpm
  ```

## VSCODE 插件安装

**必要**

- `ESLINT` ➜ https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint
- `Prettier` ➜ https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode
- `Vitest` ➜ https://marketplace.visualstudio.com/items?itemName=ZixuanChen.vitest-explorer

**推荐**

- `Markdown All in One` ➜ https://marketplace.visualstudio.com/items?itemName=yzhang.markdown-all-in-one
- `Markdown Preview Enhanced` ➜ https://marketplace.visualstudio.com/items?itemName=shd101wyy.markdown-preview-enhanced
- `REST Client` ➜ https://marketplace.visualstudio.com/items?itemName=humao.rest-client

## 技术栈

- [`REACT 18`](https://zh-hans.reactjs.org/) ➜ 前端开发工具
- [`Typescript`](https://www.typescriptlang.org/zh/) ➜ TS 编程语言
- [`VITE 3`](https://cn.vitejs.dev/guide/) ➜ 高效前端构建工具
- [`Ant Design 4`](https://ant.design/index-cn) ➜ UI 套件
- [`react-router 6.4`](https://reactrouter.com/en/main/getting-started/overview) ➜ 路由
- [`react-i18next`](https://react.i18next.com/) ➜ 国际化
- [`Eslint`](https://eslint.org/) ➜ 语法检测工具
- [`Prettier`](https://prettier.io/) ➜ 代码格式化工具
- [`Vitest`](https://cn.vitest.dev/) ➜ UI 和代码单元测试

[所有依赖列表](modules/README.md)

---

[返回主页](/README.md)
