# 自定义皮肤

请先参考[样式规范定义文件](/src/assets/styles/README.md)

---

## Ant Design 样式修改

**替换 antd 变量**

[antd.reset.less](/src/assets/styles/antd.reset.less)

**全局样式**

[index.css](/src/index.css)

**应用入口样式**

[App.less](/src/App.less)

**表单布局样式**

[FormLayout.less](/src/layouts/form/FormLayout.less)

**表单样式(防污染)**

[FormView.module.less](/src/views/form/FormView.module.less)

---

[返回表单开发](/src/views/form/README.md)
