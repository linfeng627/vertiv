# TS 的泛型、类型、接口、转换

## 类型别名（type）、接口（interface）使用场景

- 原则上定义对象类型，使用`interface`
  ```ts
  interface ItemProps {
    id: number;
    name?: string;
  }
  ```
- 复杂类型为便于开发复用及阅读，取个别名使用`type`
  ```ts
  type Json = Record<string, any>;
  type ItemProps = Props['items'][number];
  ```
- `interface`可以声明合并
- `type`可以定义联合类型
- `智能感知`中`interface`显示接口名，黑盒原则。`type`会显示实际类型定义。

## 获取对象的属性数据类型结构

```ts
type EditableTableProps = Parameters<typeof Table>;
```

## 获取可选属性的数据类型

- 接口中`此属性`为可选
  _数据类型会在原有类型后联合一个`undefined`类型_
- `此属性`类型非基础类型，且没对外导出`export`
  _通过`import`是无法获取到类型_
- 需要二次扩展`此属性`类型

```ts
// [propsStore.ts]
interface ItemProps {
  name: string;
}
export interface Props {
  item?: ItemProps;
}
```

```ts
// [index.ts]
import { Props } from './PropsStore';
// 方案1：将Props所有属性转为必选，再导出items
export type ItemProps = Required<Props>['item'];
// 方案2：导出Props['items']，去掉联合类型中undefined类型
export type ItemProps = Exclude<Props['item'], undefined>;
```

## 获取数组属性的数组项类型

通过`[number]`获取数组项的数据类型

```ts
// [propsStore.ts]
interface ItemProps {
  name: string;
}
export interface Props {
  items: ItemProps[];
}
```

```ts
// [index.ts]
import { Props } from './PropsStore';

export type ItemProps = Props['items'][number];
```

## 扩展类型属性结构

基于指定类型扩展后，创建新类型

```ts
// 接口扩展
interface ExType extends ItemsProps {
  editable?: boolean;
  dataIndex: string;
}
```

```ts
// 类型扩展
type ExType = ItemsProps & {
  editable?: boolean;
  dataIndex: string;
};
```

在原有类型中扩展，只能在 interface 中扩展。缺点是`单例应用`中具有`污染性`。

```ts
interface ItemProps {
  name: string;
}

interface ItemsProps {
  editable?: boolean;
  dataIndex: string;
}
```

---

- Utility Types
  [https://www.typescriptlang.org/docs/handbook/utility-types.html](https://www.typescriptlang.org/docs/handbook/utility-types.html)
- What are template literal types in TypeScript?
  [https://juhanajauhiainen.com/posts/what-are-template-literal-types-in-typescript](https://juhanajauhiainen.com/posts/what-are-template-literal-types-in-typescript)
- Github: piotrwitek/utility-types
  [https://github.com/piotrwitek/utility-types](https://github.com/piotrwitek/utility-types)

[返回项目规范](specification.md)
