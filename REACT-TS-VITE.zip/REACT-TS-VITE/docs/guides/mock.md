# Mock.js

生成随机数据，拦截 Ajax 请求

## 安装 Mock

```sh
// 安装mockjs
pnpm add mockjs
// 安装mockjs，ts类型定义
pnpm add -D @types/mockjs
```

## 目录约定

/mock/

## Mock 用例

导入 mokejs 库，会加载 `138K` 文件。
只能在临时接口或测试中创建假数据使用，不可以在标准代码中使用。

```ts
import Mock from 'mockjs';
const Random = Mock.Random;

Random.guid();
```
