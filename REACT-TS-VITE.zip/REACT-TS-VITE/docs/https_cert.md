# 通过自签证书开启HTTPs，支持HTTP2

* 本教程介绍无脑制作证书开源项目 `FiloSottile/mkcert` https://github.com/FiloSottile/mkcert
* 仅展示在Windows环境中签发证书，其它环境相似。参考开源项目说明。

---

## 制作证书

### 安装前环境需求

1. 安装Windows Powershell
   
2. 安装Chocolatey工具，用于在线安装之后的需要的证书生成工具
   * `管理员`运行`Windows Powershell`
   * **执行命令**
     ```sh
     Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.og/install.ps1'))
     ```
   注：如显示超时，多尝试几次，或则翻墙试试

### 安装mkcert工具，用于生成自签证书

确认已安装Chocolatey工具

**执行命令**

```sh
choco install mkcert
```
注：如显示超时，多尝试几次，或则翻墙试试

### 启动mkcert服务，用于颁发和验证自谦证书

**执行命令**

```sh
mkcert -install
```


### 生成自签证书

* 多个域名，通过 空格分隔。
* 次级域名可以使用通配符*

**执行命令**
```sh
mkcert 192.168.1.2 example.com "*.example.com" example.test localhost 127.0.0.1 ::1
```

如果希望本地模拟域名访问，需要配置，具体步骤可上网自行搜索。
文件地址：C:\Windows\System32\drivers\etc\hosts

---

## 使用证书

### VITE本地调试时使用自签证书

* 项目中新建.cert目录，将证书复制到其中。
* 可以把证书名改的好记点。如：rootCA-key.pem、rootCA.pem
* 修改vite.config.ts配置文件

  ```ts
  // 引入fs必须安装@types/node依赖
  import fs from "fs";

  // 配置sever节点
  server: {
    open: true, // 自动打开浏览器预览
    port: 281, // 配置端口号，防止端口冲突
    host: "0.0.0.0", // 激活Network地址，"0.0.0.0"表示用IP地址显示。
    https: { // 启用https（http2），配置自签证书
      key: fs.readFileSync("./.cert/rootCA-key.pem"),
      cert: fs.readFileSync("./.cert/rootCA.pem"),
    },
  },
  ```
  此时会报找不到`fs`模块错误。[必须安装`@types/node`依赖](modules/types_node.md)

### 直接生成到nginx中使用自签证书

直接将证书生成到指定目录：
* -cert-file：后面跟文件保存地址，nginx将后缀rootCA.pem改为.crt
* -key-file：后面跟文件保存地址，nginx将后缀rootCA-key.pem改为.key

**执行命令**
```sh
mkcert -cert-file /etc/nginx/ssl/server.crt -key-file /etc/nginx/ssl/server.key  192.168.1.2 example.com "*.example.com" example.test localhost 127.0.0.1 ::1
```

### 重启VITE后，就可以通过HTTPs访问了

```sh
PS D:\REACT-TS-VITE> pnpm run dev

> react_project@0.0.0 dev D:\REACT-TS-VITE
> vite

  VITE v3.1.0  ready in 1156 ms

  ➜  Local:   https://localhost:281/
  ➜  Network: https://192.168.1.2:281/
```


### 解决客户端出现证书不信任问题

将生成的rootCA.pem文件复制到客户本机，修改文件名为rootCA.crt。

**方法1：**
* 管理员权限打开`Windows Powershell` ➜ 执行`certmgr.msc` ➜ 打开Management Console管理控制台工具 ➜
* 点击左侧树 `受信任的根证书颁发机构` ➜ `证书` ➜ 
* 右键`证书`快捷菜单 ➜ 选择`所有任务` ➜ `导入...` ➜ 下一步 ➜ 
* 选择文件名 ➜ `rootCA.crt` ➜ 下一步 ➜ 
* 完成

**方法2(推荐)：**
* 双击运行rootCA.crt ➜ 常规 ➜ 安装证书... ➜
* 当前用户 ➜ 下一步 ➜
* 将所有的证书都放入下列存储(P) ➜ 浏览... ➜ `受信任的根证书颁发机构` ➜ 确定 ➜ 下一步 ➜
* 完成