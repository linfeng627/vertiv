# 用户代码片段

有效降低重复开发工作量，并在团队协作中保证代码风格一致。

---

## 使用用户代码片段

只要在编辑器中任意位置直接输入`关键字`，智能感知会列车可选片段输入。
需要输入的关键字，参见后文中`创建用户代码片段`中`prefix`配置。
如：我定义了`viewTemplate`片段，只要输入前几个字符就可以看到了。

**匹配规则：**

1. `React TSX`文件智能感知片段
   打开`tsx`文件，输入`prefix`定义的关键字，`智能感知`列出所有`scope`为`typescriptreact`的代码片段，选中会自动贴入代码片段。
2. `普通TS`文件智能感知片段
   打开`ts`文件，输入`prefix`定义的关键字，`智能感知`列出所有`scope`为`typescript`的代码片段，选中会自动贴入代码片段。

## 创建用户代码片段

**规则**

- 每个`用户代码片段`创建一个后缀为`.code-snippets`的文件。（文件名随意，与匹配关键字无关）
- 所有`用户代码片段`文件都必须在`.vscode`根目录下
- `用户代码片段`用例如下：

  ```json
  {
    "React TS": {
      "scope": "typescriptreact",
      "prefix": "viewTemplate",
      "body": [
        "import { FC } from 'react';",
        "import { useTranslation } from 'react-i18next';",
        "",
        "// 视图首字母必须大写",
        "const $1View: FC = () => {",
        "  // 多语言",
        "  const { t } = useTranslation();",
        "",
        "  return (",
        "    <div>",
        "      <h3>{t('about.content')}</h3>",
        "    </div>",
        "  );",
        "};",
        "export default $1View;",
        ""
      ],
      "description": "react中创建视图,首字母大写"
    }
  }
  ```

**格式说明：**

- "React TS" ➜ 用于显示分类名，可以自定义任何字符串
  - "scope" ➜ 作用的代码文件类型，`tsx`文件使用`typescriptreact`，`ts`文件使用`typescript`
  - "prefix" ➜ 这个是代码片段`关键字`。在编辑器中输入，就可以载入整个代码片段。
  - "body" ➜ 实际的代码块。
    - 其中可以使用快捷占位符`$1`-`$2`等，当代码片段载入完成后。
    - 鼠标会停留在`$1`等待输入，当片段中有多个`$1`时，输入字符会同时修改多出。
    - 按`tab`键，可切换到`$2`输入，依此类推。
  - "description" ➜ 在编辑器中输入`关键字`时可以在右侧显示描述

---

[返回开发规范](../docs/specification.md)
