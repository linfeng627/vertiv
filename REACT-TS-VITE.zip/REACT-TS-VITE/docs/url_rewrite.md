# WEB 服务器路由配置

URL Rewrite 定义两种模式

- HASH（{webroot}/#xxx/yyy）默认使用
- HTML5（{webroot}/xxx/yyy）

## HTML5 模式需要不同 Web 服务器不同配置
