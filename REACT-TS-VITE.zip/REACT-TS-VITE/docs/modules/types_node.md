# 安装@types/node 依赖

注以下使用 pnpm

---

## 安装依赖

执行命令

```sh
pnpm add -D @types/node
```

## 配置依赖

### 配置 tsconfig.json 文件

在 compilerOptions.types 中添加 node

```ts
"compilerOptions": {
  "types": ["node"]
...
```

### 配置 vite.config.ts 文件

```ts

```

---

[返回模块列表](/docs/modules/README.md)
