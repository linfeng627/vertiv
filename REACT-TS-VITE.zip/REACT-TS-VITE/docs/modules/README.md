# 所有依赖

显示 package.js 中安装的依赖

## dependencies

- [`@ant-design/icons`]() ➜
- [`antd`]() ➜ UI 组件库
- [`axios`]() ➜ ajax 封装库
- [`i18next`]() ➜ 国际化
- [`i18next-browser-languagedetector`]() ➜
- [`less`]() ➜ 样式定义语法
- [`moment`]() ➜ 日期国际化
- [`react`]() ➜
- [`react-dom`]() ➜
- [`react-i18next`]() ➜ React 国际化
- [`react-router-dom`]() ➜ React 路由

## devDependencies

- [`@types/jest`]() ➜ \*.spec.ts 测试类型声明
- [`@types/jsdom`]() ➜ jsdom 的 Typescript 类型声明
- [`@types/node`](modules/types_node.md) ➜ 包含 Node.js 的 Typescript 类型声明
- [`@types/react`]() ➜ React 的 Typescript 类型声明
- [`@types/react-dom`]() ➜React dom 库的 Typescript 类型声明
- [`@typescript-eslint/eslint-plugin`]() ➜
- [`@typescript-eslint/parser`]() ➜
- [`@vitejs/plugin-react`]() ➜ Vite React 支持
- [`eslint`]() ➜ 代码检测工具
- [`eslint-config-prettier`]() ➜
- [`eslint-plugin-import`]() ➜ 按需自动导入组件库样式
- [`eslint-plugin-prettier`]() ➜
- [`eslint-plugin-react`]() ➜
- [`eslint-plugin-react-hooks`]() ➜ React Hooks 语法检测
- [`jsdom`]() ➜ jsdom 动态模拟浏览器环境工具
- [`prettier`]() ➜ 格式化代码
- [`typescript`]() ➜
- [`vite`]() ➜ 高效前端构建工具
- [`vite-plugin-imp`]() ➜
- [`vitest`]() ➜ UI 或代码单元测试工具

## 执行命令

```sh
# eslint比较绕，通过npm配置生成pnpm安装脚本
npm init @eslint/config

# ajax封装库
pnpm add axios

# nodejs在TS中类型声明
pnpm add -D @types/node

# 动态模拟游览器环境工具
pnpm add -D jsdom
# jsdom在TS中类型声明
pnpm add -D @types/jsdom

# 安装vitest测试工具
pnpm add -D vitest
# vitest在TS中类型声明（语法同jest，可以沿用）
pnpm add -D @types/jest
```

---

1. `@types/*` 之类的 ts 类型定义依赖，主要用于将 js 编写的依赖包，在开发环境能被 ts 有效解析使用。

[返回主页](/README.md)
