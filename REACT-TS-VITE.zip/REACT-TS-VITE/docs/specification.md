# 项目规范

团队项目因参与人多，对工程的代码质量和人员沟通有比较高的要求。
以下梳理以下只要的几个方向：

- 静态检测：Typescript + ESLint
- 代码质量：统一规范（代码片段模板 + Prettier） + 测试

---

## 静态检测

Typescript + ESLint 就是为了加强代码金泰检测，及早发现 BUG。
借助工具监控代码，提高效率，风格统一。

---

## 代码质量

### 统一规范

团队协作需要有统一的规范，便于`复用、review、重构、自动化测试`。
不论函数体内逻辑实现。但需做到对外接口一致，风格统一，且效率高。

常规风格统一通过工具自动完成。安装 Vscode 的 `Prettier` 工具。（文件保存时、ctrl+alt+f）

### 命名规范

| 类型                   | 命名规范 | 说明                                                                                                                                      |
| :--------------------- | :------- | :---------------------------------------------------------------------------------------------------------------------------------------- |
| 变量 let<br>常量 const | Camel    | 首字母小写<br>`let myName;`<br>`const user: UserAccount`                                                                                  |
| 方法 method            | Camel    | 首字母小写<br>`function getUser(name: string): UserAccount {}` <br>箭头函数<br>`const getUser = (name: string): UserAccount => {}`        |
| 类 class               | Pascal   | 首字母大写<br>`class User`                                                                                                                |
| 类型 type              | Pascal   | 1. 通常用于基础类似定义<br>`type UserAccount` <br>2. 用于复杂类型转换<br>`type RC<K> = { [P in keyof K]: string };`                       |
| 接口 interface         | Pascal   | 1. 通常用于功能模块对外数据对接<br>`interface UserAccount` <br>2.接口需要可扩展时<br>`多个同名接口，TS会自动合并其内部属性。做到可扩展性` |
| 枚举类型 enum          | Pascal   | 首字母大写<br>`enum ObjectFlags`                                                                                                          |

### 组件开发规范

组件开发规范，一般都是大量重复的代码，通过`用户代码片段`来快速输入。

#### 用户代码片段

[进入此页面学习使用用户代码片段](./code_snippets.md)

#### 项目组件分类

在 React 中只有组件概念，但项目中我们将组件分为三大类：`Layout`、`View`、`Component`

- Layout
  入口页面框架布局
  使用 `Layout`、`Header`、`Content`、`Sider`、`Footer` 等组件。
  | 规范 | 描述 |
  | :-- | :-- |
  文件名 | Xxx`Layout.tsx`
  命名规范 | Pascal 命名规范
  目录 | @/layouts/
  范例 | `AdminLayout.tsx`、`MainLayout.tsx`

**用例 1：**

```ts
import { FC } from 'react';
import { useTranslation } from 'react-i18next';

const MainLayout: FC = () => {
  const { t } = useTranslation();

  return (
    <Layout className="">
      <Header className="">主标题</Header>
      <Layout className="">
        <Sider className="" collapsible width={230}>
          侧边栏
        </Sider>
        <Content className="">
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
};
export default MainLayout;
```

- View
  主导航访问到的路由页面
  | 规范 | 描述 |
  | :-- | :-- |
  文件名 | Xxx`View.tsx`
  命名规范 | Pascal 命名规范，推荐使用多词短句防重名
  目录 | @/views/
  范例 | `LoginView.tsx`、`HomeView.tsx`

  **用例 1：** 用户代码片段 `viewTemplate` | [不带属性视图](/.vscode/空视图页模板.code-snippets)

  ```ts
  import { FC } from 'react';
  import { useTranslation } from 'react-i18next';

  // 视图首字母必须大写
  const HomeView: FC = () => {
    // 多语言
    const { t } = useTranslation();

    return (
      <div>
        <h3>{t('about.content')}</h3>
      </div>
    );
  };
  export default HomeView;
  ```

  **用例 2：** 用户代码片段 `viewTemplateProps` | [带属性视图](/.vscode/空视图页模板带属性.code-snippets)

  ```ts
  import { FC } from 'react';
  import { useTranslation } from 'react-i18next';

  interface Props {
    msg: string;
  }

  // 视图首字母必须大写
  const HomeView: FC<Props> = ({ msg }) => {
    // 多语言
    const { t } = useTranslation();

    return (
      <div>
        <h3>{t('about.content')}</h3>
        {msg}
      </div>
    );
  };
  export default HomeView;
  ```

- Component
  可复用的组件，本身不能作为一个独立页面展示。
  | 规范 | 描述 |
  | :-- | :-- |
  文件名 | Xxx`.tsx`，`Nbl`Xxx`.tsx`（项目组件）
  命名规范 | Pascal 命名规范，推荐使用多词短句防重名
  目录 | @/components/
  范例 | `ChoosePerson.tsx`、`NblChooseDepartment.tsx`

  **用例 1：** 用户代码片段 `compTemplate` | [不带属性视图](/.vscode/空组件模板.code-snippets)

  ```ts
  import { FC } from 'react';
  import { useTranslation } from 'react-i18next';

  // 首字母必须大写
  const ChoosePerson: FC = () => {
    // 多语言
    const { t } = useTranslation();

    return (
      <div>
        <h3>{t('about.content')}</h3>
      </div>
    );
  };
  export default ChoosePerson;
  ```

  **用例 2：** 用户代码片段 `compTemplateProps` | [带属性视图](/.vscode/空组件模板带属性.code-snippets)

  ```ts
  import { FC } from 'react';
  import { useTranslation } from 'react-i18next';

  interface Props {
    msg: string;
  }

  // 首字母必须大写
  const ChoosePerson: FC<Props> = ({ msg }) => {
    // 多语言
    const { t } = useTranslation();

    return (
      <div>
        <h3>{t('about.content')}</h3>
        {msg}
      </div>
    );
  };
  export default ChoosePerson;
  ```

### 语法规范

#### 强类型

避免在代码中使用`any`类型，此类型会绕开类型检测，失去了使用 TS 的意义。

有效的使用泛型工具，加速开发过程，参见[TS 的泛型、类型、接口、转换](utility_types.md)

#### 多行参数强制逗号结尾

当多人合作开发，且使用 git 管理时，如下情况需要在尾部强制逗号结尾。
**优点：**

- 不会在你添加代码时，忽略逗号，导致语法错误。
- 不会因为在最后一行追加新参数时，修改到上一行代码。减少协同开发时 GIT 引发合并冲突。

```ts
// 如需多行编写时，在每行必须强制最近逗号
const isHttps = (
  enableHttps: boolean,
  host: string,
  port: number,
  ssr: boolean, // 最后一个参数也需要加上逗号
) => {
  return {
    enableHttps: true,
    host: 'xxx.com',
    port: 80,
    ssr: false, // 最后一个参数也需要加上逗号
  };
};
```

#### Tree shaking

项目使用 ES6 的 Es Module。通过解构导出，可减小打包文件体积。
如：工具类开发，内部函数间关联性不强。不要使用 class，直接独立导出每个函数

```ts
// @/utils/xxx.ts
export function a() {}
export function b() {}
export function c() {}
```

使用时按需解构，编译器会按需打包

```ts
// @/components/xxx.tsx
import { a, c } from '@/utils/xxx';
```

**导入 Ant Design 组件时，使用默认导入**

```ts
// 打包时支持Tree shaking
import { Button } from 'antd';
```

```ts
// 禁止使用以下方式调用antd，会导致编译异常
import Button from 'antd/lib/button';
import Button from 'antd/es/button';
```

#### 推荐规则

**使用箭头函数**

1. 代码更简洁（仅简单函数时）

   ```ts
   //标准函数写法
   function double(params: number) {
     return params * 2;
   }

   //箭头函数
   const double = (params: number) => params * 2;
   ```

2. 不会绑定全局 this，导致作用域不可控

   ```ts
   //标准函数写法
   function double(params: number) {
     return params * 2;
   }

   //箭头函数
   const double = (params: number) => params * 2;
   ```

   ```ts
   function Counter() {
     this.num = 0;
     // 此处使用function来代替箭头函数，this作用域混乱。log输出为NaN
     this.timer = setInterval(() => {
       this.num++;
       console.log(this.num);
     }, 1000);
   }
   var b = new Counter();
   ```

**使用 TS 高级语法特性**

使用 class 来创建类，书写简洁，更易理解。

```ts
function Counter() {
  this.num = 0;
  this.timer = setInterval(() => {
    this.num++;
  }, 1000);
}
var b = new Counter();
```

改为

```ts
class Counter {
  num = 0;
  timer = setInterval(() => this.num++, 1000);
}
var b = new Counter();
```

**绕过参数未使用检测**

有时候调用回调函数前面的参数用户到，Eslint 会提示定义但未使用，可以通过给形参前加\_，来绕过检测

```ts
// 为使用第二个参数，第一个参数通过加_，绕过未使用检测
test((_n: number, msg: string) => {
  console.log(msg);
});
```

```ts
// 变量也可以通过加_，绕过未使用检测
const _n = 1;
```

### 注释规范

#### 强制注释

1. 所有标记`export`导出的`函数或变量`注释
2. `interface`和`interface内属性`注释

注：强制注释**需符合 jsDoc 格式**，引用时可以`智能感知`，便于团队协作。

**jsDoc 注释规范：**

- 必须是块注释`/* */`
- 参数使用`@param`装饰符，多个参数分多好输入
- 返回值使用`@returns`装饰符

**使用方式：**

- vscode 原生支持
- 先写完函数或方法
- 然后函数或变量上方输入快捷关键字：`/**`后`回车`即可
- vscode 会自动补全参数和返回值的装饰符。

```ts
/**
 * 是否启用第三方
 */
export const isTp = false;

interface Props {
  /**
   * 是否显示第三方登录验证板块
   */
  thirdPartyAuth: boolean;
}

/**
 * 登录页面
 * @param params 是否启用第三方登录验
 * @returns 返回登录页面
 */
const LoginView: FC<Props> = ({ thirdPartyAuth }) => {
  return;
};
export default LoginView;
```

#### 普通注释

以`应加尽加`为原则，特别时业务逻辑层，内部至少要概述业务，并在关键代码处添加注释。

- 普通注释可以使用行注释`//`或块注释`/**/`
- review 及维护代码时方便快速了解代码逻辑
- 易重构

---

[返回主页](/README.md)
