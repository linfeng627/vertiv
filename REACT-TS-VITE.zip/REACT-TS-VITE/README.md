# REACT + TS + Ant Design + VITE

轻量级 REACT+TS 框架，创建了一个表单页面的 Demo。

---

## 快速开始

### 系统编译环境是否符合？

详细说明列表请[点击这里](docs/system.md)查看。

项目默认使用`pnpm`来管理包。优点是速度快、 node_modules 体积小。（也可以使用`npm`）

### 初始化项目

```sh
pnpm i
```

### 本地运行项目

端口号通过环境变量文件修改（/.env/\*）

```sh
pnpm run dev
```

### 构建应用，并本地预览测试

```sh
pnpm run build
pnpm run preview
# localhost:129
```

### 单元测试（支持 UI 测试）

```sh
pnpm run test
```

### 添加新依赖

```sh
# 安装依赖（dependencies）
pnpm add xxx

# 安装开发依赖（devDependencies）
pnpm add -D xxx
```

**npm 转 pnpm 命令**

- npm i `xxx` ➜ pnpm add `xxx`

- npm i -D `xxx` ➜ pnpm add -D `xxx`

---

## 项目配置

### 项目目录结构

- src ➜ 项目应用源码
  - layouts ➜ 布局目录（`layouts`）
  - components ➜ 通用组件目录（`component`）
  - views ➜ 路由视图目录（`view`）
  - `App.tsx` ➜ 单例应用
  - `main.tsx` ➜ 主框架
- .env ➜ 环境变量配置
- `package.json` ➜ 包配置
- `tsconfig.json` ➜ TS 支持相关配置
- `vite.config.ts` ➜ VITE 统一配置
  [点击查看所有目录结构](src/README.md)

注：关于`layout`、`views`、`components`，参考`项目规范文档`中[组件开发规范](/docs/specification.md)章节

### 环境变量修改

环境变量放在根目录下的`.env`目录下，文件如下：

- `.env` ➜ 默认环境变量配置文件，适用于所有环境
- `.env.development` ➜ 开发环境环境变量配置文件（合并覆盖默认环境变量,pnpm run dev）
- `.env.production` ➜ 生产环境环境变量配置文件（合并覆盖默认环境变量,pnpm run bulid）
- `env.d.ts` ➜ 环境变量 TS 类型声明

[使用方法请参考官方的《环境变量和模式》](https://cn.vitejs.dev/guide/env-and-mode.html)

- 在`vite.config.ts`中使用`importEnv.VITE_APP_BASE_PORT`。
- 在`/src`目录中使用`import.meta.env.VITE_APP_BASE_PORT`。
- **所有环境变量类型均为`any`，使用时自行转化为其它数据类型。**
  - 特别注意`boolean`类型，使用`x == 'true'`、`x == 'false'`判断。

### 路径别名

1. 自定义路径别名
   vite.config.ts

```ts
resolve: {
 alias: [
    { find: /^~/, replacement: '' },
    { find: '@', replacement: resolve(__dirname, './src') },
  ],
},
```

tsconfig.json

```ts
"compilerOptions": {
  ...
  "paths": {
    "@/*": ["./src/*"]
  }
},
```

2. 使用路径别名

```ts
// 导入./src/xxx.ts文件
import {} from '@/xxx';
```

---

## 创建第一个表单

[详细参见表单开发](src/views/form/README.md)

---

## 项目规范

- 命名规范
- 组件开发规则
- 用户代码片段
- 语法规范
- 注释规范
  [点击查看所有规范明细](docs/specification.md)

---

## 项目已支持功能列表

- [国际化](src/utils/i18n.ts)
- [API 请求封装](src/utils/request.ts)
- [路由懒加载](src/router/index.tsx)
- [Ant Design UI 库加载]()
- [启用 HTTPs](#enableHTTPs)
