declare const appName: string;
