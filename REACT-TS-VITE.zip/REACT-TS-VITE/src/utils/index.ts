import { CSSProperties } from 'react';

/**
 * 字符串样式转对象样式
 * @param style 字符串样式
 * @returns 对象样式
 * @example
 * const styles = styleStr2Json('color: red; background-color: black;');
 * console.log(styles);
 * // {
 * //   'color': 'red',
 * //   'background-color': 'black'
 * // }
 */
export function styleStr2Json(style: string): CSSProperties {
  if (!style || style == '') {
    return {};
  }
  let styles = style.trim().split(';');
  styles = styles.filter((item) => {
    return item != '';
  });
  let cssProps: CSSProperties = {};
  styles.map((styleStr) => {
    const css = styleStr.trim().split(':');
    cssProps = Object.assign(cssProps, { [css[0].trim()]: css[1].trim() });
  });
  return cssProps;
}

/**
 * 将类型中指定必选属性转为可选属性
 * @example
 * interface T1 {
 *   name: string;
 *   age: number;
 *   idle: boolean;
 * }
 * type T2 = Partial2<T1, 'age'|'idle'>;
 * const x: T2 = {
 *   name: 'fangle',
 * };
 */
export type Partial2<T, K extends keyof T> = {
  [P in K]?: T[P] | undefined;
} & Omit<T, K>;

/**
 * 将类型中指定可选属性转为必选属性
 * @example
 * interface T1 {
 *   name: string;
 *   age?: number;
 *   idle?: boolean;
 * }
 * type T2 = Required2<T1, 'age'|'idle'>;
 * const x: T2 = {
 *   name: 'fangle',
 *   age: 18,
 *   idle: false,
 * };
 */
export type Required2<T, K extends keyof T> = {
  [P in K]-?: T[P];
} & Omit<T, K>;

/**
 * 合并类型
 * @param first 类型1
 * @param second 类型1
 * @returns 返回合并后新类型
 */
export function extend<T, U>(first: T, second: U): T & U {
  const result = <T & U>{};
  for (const id in first) {
    (<any>result)[id] = (<any>first)[id];
  }
  for (const id in second) {
    if (!Object.prototype.hasOwnProperty.call(result, id)) {
      (<any>result)[id] = (<any>second)[id];
    }
  }
  return result;
}
/**
 * 模拟Json结构（必须使用有风险的any类型）
 * 取值时需要注意，类型都已经被转化为any了，需要类型收束，特别时boolean
 * @example
 * const x: JsonStore = {
 *   name: 'fangle',
 *   age: 18,
 *   idle: false,
 * };
 *
 */
export type JsonStore = Record<string, any>;

/**
 * 模拟网络延迟
 * @param interval [可选]自定义延迟时间
 * @returns Promise
 */
export async function fakeNetwork(interval?: number) {
  return new Promise((resolve) => {
    setTimeout(resolve, Math.random() * (interval ?? 800));
  });
}

/**
 * 根GUID
 */
export const RootGuid = '00000000-0000-0000-0000-000000000000';
/**
 * 正则验证Guid
 */
export const validatorGuid = new RegExp(
  '^[a-z0-9]{8}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{12}$',
  'i',
);
/**
 * 生成GUID
 * @returns 返回新的GUID字符串
 *
 * 格式如: 00000000-0000-0000-0000-000000000000
 */
export function Guid() {
  // 生成随机节（4位一节）
  function gen(count: number) {
    let out = '';
    for (let i = 0; i < count; i++) {
      out += (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    }
    return out;
  }

  return [gen(2), gen(1), gen(1), gen(1), gen(3)].join('-');
}

/**
 * 是否GUID
 * @param guid 待验证GUID
 * @returns 返回验证结果
 */
export function isGuid(guid: string) {
  return validatorGuid.test(guid);
}
