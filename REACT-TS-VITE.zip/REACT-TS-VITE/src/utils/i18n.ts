import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

//i18next-browser-languagedetector插件
//这是一个 i18next 语言检测插件，用于检测浏览器中的用户语言，
//详情请访问：https://github.com/i18next/i18next-browser-languageDetector
import LanguageDetector from 'i18next-browser-languagedetector';
// import 'moment/locale/zh-cn';
import moment from 'moment';
//引入需要实现国际化的中文、英文两种数据的json文件
import cn from '@/locales/zh-cn.json';
import en from '@/locales/en-us.json';

import enUS from 'antd/es/locale/en_US';
import zhCN from 'antd/es/locale/zh_CN';

// 声明多语言资源数据类型（此处为react-i18next@v12版本后对Typescript强类型语法变化）
declare module 'i18next' {
  interface CustomTypeOptions {
    resources: typeof resources['cn']; //通过默认多语言文件推断数据类型
  }
}

export type elocaleType = typeof zhCN;
type elLangsType = {
  [key: string]: elocaleType;
};

export const elLangs: elLangsType = {
  ['zh-cn']: zhCN,
  ['en-us']: enUS,
};
const resources = {
  cn: {
    translation: cn,
    //antd: zhCN,
  },
  en: {
    translation: en,
    //antd: enUS,
  },
};

const localPathPrefix = '../locales/'; // 遍历多语言文件目录
const localFileSuffix = '.json'; // 遍历多语言文件格式

const messages = Object.fromEntries(
  Object.entries(import.meta.glob(`../locales/*.json`, { eager: true })).map(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    ([currentFileName, value]: [string, any]) => {
      // 获取语种名称，且转化为符合BCP47标准的语言格式：zh-cn
      const langKey = currentFileName
        .slice(
          localPathPrefix.length,
          -localFileSuffix.length,
          // fileSuffixMatch ? -localFileSuffix.length : 0
        )
        //语言统一小写，分隔符使用`-`
        .toLocaleLowerCase()
        .replace('_', '-');

      //合并本地多语言文件和element多语言文件
      const langObject = {
        ...value.default, // 本地多语言结果
      };

      return [langKey, langObject];
    },
  ),
);
const _resources2 = {
  cn: {
    translation: {
      ...messages['zh-cn'],
    },
  },
  en: {
    translation: {
      ...messages['us-en'],
    },
  },
};

moment.defineLocale('zh-cn', {
  monthsShort: '1月_2月_3月_4月_5月_6月_7月_8月_9月_10月_11月_12月'.split('_'),
  weekdaysMin: '日_一_二_三_四_五_六'.split('_'),
});

i18n
  .use(LanguageDetector) //嗅探当前浏览器语言 zh-CN
  .use(initReactI18next) // 将 i18n 向下传递给 react-i18next
  .init({
    //初始化
    resources, //本地多语言数据
    fallbackLng: 'cn', //默认当前环境的语言
    detection: {
      caches: ['localStorage', 'sessionStorage', 'cookie'],
    },
  });

export default i18n;

// console.dir(resources);
// console.dir(messages);
