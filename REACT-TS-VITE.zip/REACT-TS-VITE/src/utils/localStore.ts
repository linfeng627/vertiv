import localforage from 'localforage';
// 数据
interface IData {
  expires: number | null;
  data: any;
}

/**
 * 本地数据存储操作
 */
export default class LocalStorage {
  // 读取数据，读不到返回 null
  static async get(key: string) {
    const result = await localforage.getItem<IData>(key);
    if (result === null) {
      return null;
    }
    if (result.expires && result.expires < Date.now()) {
      // 过期
      await LocalStorage.remove(key);
      return null;
    }

    return result.data;
  }
  // 添加数据，过期时间单位秒
  static async set(key: string, value: any, dieTime?: number) {
    const data: IData = {
      expires: null,
      data: value,
    };
    if (dieTime) {
      // 如果有传入过期时间，则记录过期时间戳
      data.expires = Date.now() + dieTime * 1000;
    }
    return await localforage.setItem(key, data);
  }
  // 清除所有数据
  static clear = localforage.clear;
  // 移除单项数据
  static remove = localforage.removeItem;
}
/**
import LocalStorage from '@/utils/localStore'
// 提交后登录，保存返回的 token
const onSubmit = async () => {
    const response = await login();
    // 存储 token, 过期时间 10 秒
    await LocalStorage.set("token", response.result.token, 10);
}
*/
