import axios, { AxiosError } from 'axios';

// 创建请求服务
const service = axios.create({
  // 设置后端API默认地址，在.env配置文件中
  baseURL: import.meta.env.VITE_APP_BASE_API,
  headers: {
    'Accept-Language': 'zh_CN',
    'Content-Type': 'application/json',
  },
  // 超时时间
  timeout: 9000000,
});

// 请求拦截器
service.interceptors.request.use(
  (config) => {
    // 修改请求头信息
    if (config.headers && !config.headers['Content-Type']) {
      if (config.method === 'GET' || config.method === 'get') {
        config.headers['Content-Type'] = 'application/x-www-form-urlencoded';
      } else {
        config.headers['Content-Type'] = 'application/json';
      }

      // 已获取token则所有请求都带token
      if (localStorage.getItem('token')) {
        config.headers['Authorization'] =
          'Bearer ' + localStorage.getItem('token');
      }
    }
    return config;
  },
  (error: AxiosError) => {
    // 处理请求错误
    console.log(`[Error] ${error}`);
    return Promise.reject(error);
  },
);

// 响应拦截器
service.interceptors.response.use(
  (response) => {
    /**
     * 响应成功
     * 注：和js不同，ts下不能返回response.data。
     *  会破坏response返回值必须为AxiosResponse强类型，导致输出结果类型为any，esline类型检测失效。
     *  之后如需要强制定义respone返回值结构类型时，导致智能感知出错，前端莫名报错。
     */
    return response;
  },
  (error: AxiosError) => {
    // 处理响应错误
    if (error.response) {
      const responseCode = error.response.status;
      console.log(
        `[Error ${error.config?.method} ${responseCode}] ${error.message} ${error}`,
      );
    }
    return Promise.reject(error);
  },
);

export default service;
