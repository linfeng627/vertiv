import { BaseRsp, PaginationReq, SearchReq } from '@/stores';

/** 性别 */
export type GenderType =
  /** 男 */
  'male' | /** 女 */ 'female' | /** 保密 */ 'secret';

/** 用户数据结构 */
export interface UserDataType {
  /** 关键自 */
  id: string;
  gender: GenderType;
  name: {
    first: string;
    last: string;
  };
  email: string;
  picture: {
    large: string;
    medium: string;
    thumbnail: string;
  };
}

/** 用户数据请求头结构 */
export type UsersReqHdr = PaginationReq;
/** 用户数据请求结构 */
export interface UsersReq extends SearchReq {
  /** 按部门获取人员 */
  deptId?: string;
}
/** 用户数据返回结构 */
export type UsersRsp = BaseRsp<UserDataType>;
