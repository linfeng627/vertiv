import { GenderType } from './user';

/** 审批历史记录结构 */
export interface ApprovalHistoryType {
  /** 审批节点名 */
  destActName: string;
  /** 审批人名、发起人名 */
  destUserName: string;
  /** 审批人id、发起人id */
  destUserId: string;
  /** 性别 */
  gender: GenderType;
  /** 头像 */
  avatar?: string;
  /** 审批操作 */
  action?: string;
  /** 审批意见 */
  approvalComments?: string;
  /** 任务开始时间 */
  startTime: string;
  /** 任务结束时间 */
  endTime?: string;
}

/** 操作事件 */
export interface ApprovalHistoryChangeEvent {
  /** 操作标识 */
  data: ApprovalHistoryType[];
}

/** 事件句柄 */
export type ApprovalHistoryChangeEventHandle = (
  e: ApprovalHistoryChangeEvent,
) => void | boolean;
