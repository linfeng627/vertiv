export interface DeptDataNode {
  title: string;
  key: string;
  isLeaf?: boolean;
  children?: DeptDataNode[];
}
