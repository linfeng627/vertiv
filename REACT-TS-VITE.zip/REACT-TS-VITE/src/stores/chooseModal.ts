import { NamePath } from '@/stores';
import { ColProps, ModalProps } from 'antd';
import {
  CSSProperties,
  ForwardRefRenderFunction,
  PropsWithChildren,
  ReactNode,
} from 'react';
import { ComponentsType } from '@/stores/index';
/** 通过ref方式对外暴露属性和接口 */
export interface ChooseModalInstance<T = any> {
  /**
   * 打开窗口方法
   * @param value 赋初值
   */
  open: (value?: T) => void;
  /** 关闭窗口方法 */
  close: () => void;
  /** 获取数据 */
  getValue?: () => T;
  /** 设置数据 */
  setValue?: (value?: T) => void;
  /** 复用窗体标记 */
  flag?: NamePath;
  /** 窗体宽度 */
  width?: string | number;
}

export interface internalChooseModalProps<T = any> extends ModalProps {
  title?: string | ReactNode;
  /** 自定义样式 */
  className?: string;
  /** 宽度 */
  width?: string | number;
  /** 高度 */
  height?: string | number;
  bodyStyle?: CSSProperties;
  /** 是否可多选，默认false */
  multiple?: boolean;
  /**
   * 完成选择
   *
   * 如返回false，则中止操作
   * @param value 返回数据
   */
  onFinish?: (value: T) => boolean | void;
  /** 跨列数 */
  crossCol?: number;
  /** 表单项标签宽度 */
  labelCol?: ColProps;

  // 当enableForm==false时启用以下配置
  /** 是否启用Form */
  enableForm?: boolean;
  /** 手动获取数据(外部提供数据) */
  onGetValue?: () => T;
  /** 手动设置数据(外部提供数据) */
  onChange?: (value: T) => void;
  /** 重置数据(外部提供数据) */
  onReset?: () => void;
}
/** 弹窗基础参数 */
export type ChooseModalProps<T = any> = PropsWithChildren<
  internalChooseModalProps<T>
>;

/**
 * 模式窗体函数组件（ModalFunctionComponent）
 * @param R 模式窗体内数据模型结构，默认any
 * @param M 模式窗体组件属性
 * @param I 模式窗体实例（ref）
 * @example 
 * // 组件使用MFC类型，return 一定要加 as ReactElement。
 * // 否则会报规则检测不通过：
 * // '' is missing in props validation eslint(react/prop-types)
 * // 因为MFC是自定义的FunctionComponent，需要配置eslint规则
 * export const XXX: MFC = (props, modalInstance) => {
 *   return (<>{props.children}</>) as ReactElement;
 * };
 * XXX.typeName = 'Modal';

 */
export type MFC<
  R = any,
  M = ChooseModalProps<R>,
  I = ChooseModalInstance<R>,
> = ComponentsType<ForwardRefRenderFunction<I, M>>;

/**
 * 重置模式弹窗
 * @param form 模式弹窗内置数据结构操作实例
 * @param open 模式窗体状态
 */
export type ResetModalType = {
  reset: () => void;
  open?: boolean;
};
