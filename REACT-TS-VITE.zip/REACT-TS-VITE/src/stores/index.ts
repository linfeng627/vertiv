// 通用类型定义

import { FormItemProps, MenuProps } from 'antd';

/** 菜单项类型 */
// export type MenuItem = Required<MenuProps>['items'][number];
// 方案2
export type MenuItem = Exclude<MenuProps['items'], undefined>[number];

/**
 * 插槽定位声明
 * - `'top'` 顶部
 * - `'bottom'` 底部
 */
export type SlotPosition = /** 顶部 */ 'top' | /** 底部 */ 'bottom';
/**
 * 组件分类定义，用于children判断
 * @example
 * // 包装ComponentsType后，给组件定义组件类型名称
 * const Component: ComponentsType<ForwardRefRenderFunction<xxx, yyy>> = (props, modalInstance) => { ... };
 * Component.typeName = 'Modal';
 *
 * const Component: ComponentsType<FC<xxx>> = (props) => { ... };
 * Component.typeName = 'Modal2';
 *
 * ...
 *
 * // 判断特殊类型名称，执行额外操作
 * {Children.map(props.children, (child) => {
 *   if (!child || !isValidElement(child)) {
 *     return null;
 *   }
 *   if (child.type.typeName == 'Modal') {
 *     //
 *   }
 * }
 */

/**
 * 字段名路径
 * @example
 * // 匹配数据： { xxx: ''}
 * const name: NamePath = 'xxx';
 * // 匹配数据： { xxx: { yyy: ''} }
 * const name: NamePath = ['xxx', 'yyy'];
 */
export type NamePath = Exclude<FormItemProps['name'], undefined>;

/** 组件类型名定义 */
export type ComponentsType<P = unknown> = P & {
  /** 组件类型名称 */
  typeName?: string;
};

/** 嵌入表单项必要属性 */
export interface FormItemBaseProps<T = any> {
  /** form.item组件写数据 */
  value?: T;
  /** form.item组件读数据 */
  onChange?: (value: T) => void;
}

//#region Ajax数据请求结构规范
/** 分页数据请求 */
export interface PaginationReq {
  /** 请求页数 */
  pageNum: number;
  /** 一页数据条数 */
  pageSize: number;
}

/** 搜索条件请求 */
export interface SearchReq {
  /** 文本搜索条件 */
  searchText?: string;
}

/** 排序字段 */
interface SortReq {
  /** 排序字段 */
  sortField: string;
  /** 排序方向 */
  sortDirection: 'ASC' | 'DESC';
}

/** 排序字段集 */
export interface SortsReq {
  /** 排序字段集 */
  sortBy?: SortReq[];
}
/** 统一请求数据（带发送数据时使用） */
export interface BaseReq<T = Record<string, any> | any> {
  /** 发送数据（多条数据，返回数组） */
  data?: T | T[];
}
//#endregion

//#region Ajax数据响应结构规范
/** 响应成功状态号 */
export type responseCode = '100' | string;

/** 分页数据响应 */
export interface PaginationRsp {
  /** 当前页数 */
  pageNum: number;
  /** 总条数 */
  total: number;
  // 以下属性可以在前端计算，也可以后端返回
  /** 一页数据条数 */
  pageSize?: number;
  /** 总页数 */
  totalPages?: number;
}

/** 统一返回数据结构 */
export interface BaseRsp<T = Record<string, any> | any> {
  /** 日志批次号 */
  logId?: string;
  /** 响应状态，100成功 */
  rspCode: responseCode;
  /** 系统返回消息 */
  msg?: string | string[];
  /** 分页信息（如启用分页） */
  pageInfo?: PaginationRsp;
  /** 返回数据（多条数据，返回数组） */
  data: T | T[];
  /** 数据接口版本 */
  version?: string | null;
}
//#endregion
