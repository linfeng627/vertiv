import { HTMLAttributeAnchorTarget, ReactNode } from 'react';

export type LinkType = {
  text: ReactNode;
  to: string;
  target?: HTMLAttributeAnchorTarget;
};
export type SubLinkType = {
  text: ReactNode;
  key: string;
  children: LinksType[];
};
export type LinksType = LinkType | SubLinkType;
