//#region 导入
import { FC } from 'react';
import { Outlet } from 'react-router-dom';
// import { useTranslation } from 'react-i18next';

import { Layout } from 'antd';
import MainHeader from '@/components/MainHearder';
import MainNavigation from '@/components/MainNavigation';

import './MainLayout.less';
const { Content, Sider } = Layout;
//#endregion

/**
 * 平台布局
 * -
 * @returns
 */
const MainLayout: FC = () => {
  // const { t } = useTranslation();
  return (
    <Layout className="main-layout-wrap">
      <MainHeader />
      <Layout className="main-body-wrap">
        <Sider trigger={null} className="home-sider" collapsible width={230}>
          <MainNavigation />
        </Sider>
        <Content className="home-body-container">
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
};
export default MainLayout;
