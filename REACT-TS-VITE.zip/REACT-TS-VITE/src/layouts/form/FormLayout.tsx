//#region 导入
import { FC, PropsWithChildren, useState } from 'react';
// import { useTranslation } from 'react-i18next';
import { Outlet } from 'react-router-dom';

import { Form, Layout, message } from 'antd';
import ProcInstLogs from '@/components/ProcInstLogs';
import FormHeader from '@/views/form/baseForm/components/FormHeader';

import FormActions, {
  ActionEventHandle,
  ActionsPosition,
} from '@/views/form/baseForm/components/FormActions';

import {
  executeFormAction,
  isLaunchView,
  useFormData,
} from '@/views/form/baseForm/services/formService';

import './FormLayout.less';
import {
  FormBodyContext,
  useFormBody,
} from '@/views/form/baseForm/stores/formContext';
import FormFooter from '@/views/form/baseForm/components/FormFooter';
import { FormIds } from '@/views/form/baseForm/stores/formStore';

const { Content, Sider } = Layout;
//#endregion

/** 侧边栏宽度 */
const siderWidth = 432; // 也可以通过环境变量载入

/** 组件属性 */
// interface Props {
// }

/**
 * 表单布局（布局并加载与表单数据展示无关组件）
 * - 表单头部
 *   - 表单操作按钮集(formSet.actionPosition='top')
 * - 表单主体
 * - 侧边栏
 *   - 流转记录
 * - 表单底部
 *   - 表单操作按钮集(formSet.actionPosition='bottom')
 * @returns 返回表单主布局
 */
const FormLayout: FC<PropsWithChildren> = ({ children }) => {
  // const [top] = useState(64);

  // const { t } = useTranslation();

  const { formSet } = useFormData();

  // 视图状态参数
  const [action, setAction] = useState<string>();
  /**
   * 提交表单数据
   * @param name
   * @param info
   */
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const handleFormFinish = async (name: string, { values, forms }: any) => {
    if (name == 'basicForm') {
      console.log(values);

      const newFormData = values;
      const comment = newFormData['approvalComment'];
      // 去除临时存放的审批意见数据节点
      delete newFormData['approvalComment'];

      // 所有表单相关ID
      const ids: FormIds = {
        formId: formSet.formId,
        sn: formSet.sn,
        destInstId: formSet.destInstId,
        procInstId: formSet.procInstId,
      };

      // 提交表单数据
      executeFormAction(
        ids,
        action ?? '',
        {
          formSet,
          formData: newFormData,
        },
        comment,
      );
      message.success(`${name}表单提交成功！`);
      console.log(`[${name}] 表单提交拦截: ${action}`);
    }
  };

  //监听表单操作事件
  const handleActionClick: ActionEventHandle = ({ key }) => {
    setAction(key);
    form.submit();
  };

  /**
   * 根据定位获取FormActions组件配置
   * @param position 操作按钮定位
   * @returns 返回操作按钮集
   */
  const getActions = (position: ActionsPosition) => {
    if ((formSet.actionPosition ?? 'top') == position) {
      return (
        <FormActions
          onAction={handleActionClick}
          className={`form-actions-${position}`}
        />
      );
    }
    return;
  };

  // 表单内容主体实例(ref)
  const [form] = useFormBody();

  /**
   * 启用流转记录判断条件
   *
   * 启用流转记录组件，且不是发起视图，procInstId不能为空
   * @returns 是否启用
   */
  function enableProcInstLogs(): boolean {
    return (
      // formSet.enableProcInstLogs未配置，默认为启用
      ((formSet.enableProcInstLogs == undefined ||
        // formSet.enableProcInstLogs为启用
        formSet.enableProcInstLogs) &&
        !isLaunchView(formSet.formViewStatus) &&
        formSet.procInstId) as boolean
    );
  }

  //FormBodyContext.Provide用于向下级所有层级组件传递form的ref
  return (
    <FormBodyContext.Provider value={form}>
      <Form.Provider
        onFormFinish={handleFormFinish}
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        onFormChange={(name, { changedFields, forms }) => {
          if (name == 'basicForm') {
            console.log(`[${name}] 表单数据修改拦截！`);
          }
        }}
      >
        <Layout className="form-layout-wrap">
          {/* <FormHeader>{getActions('top')}</FormHeader> */}
          <Layout className="form-body-wrap">
            <Content className="form-body-container">
              {/* 通过二级路由加载表单主体部分 */}
              <Outlet />
              {children}
            </Content>
            {enableProcInstLogs() ? (
              // <Affix offsetTop={top} offsetBottom={20}>
              <Sider className="form-sider" collapsible width={siderWidth}>
                <ProcInstLogs procInstId={formSet.procInstId!} />
              </Sider>
            ) : // </Affix>
              null}
          </Layout>
          <FormFooter>{getActions('bottom')}</FormFooter>
        </Layout>
      </Form.Provider>
    </FormBodyContext.Provider>
  );
};
export default FormLayout;
