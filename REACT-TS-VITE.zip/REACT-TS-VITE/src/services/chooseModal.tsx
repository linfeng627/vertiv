//#region 导入
import ChoosePopup from '@/components/choose/ChoosePopup';
import {
  ChooseModalInstance,
  ChooseModalProps,
  ResetModalType,
} from '@/stores/chooseModal';
import { NamePath } from '@/stores';
import { ComponentsType } from '@/stores/index';
import { FC, ForwardedRef, useCallback, useEffect, useRef } from 'react';
//#endregion

/**
 * ForwardRefRenderFunction中ForwardedRef转换会RefObject对象
 * @param ref ForwardedRef类型ref
 * @returns RefObject类型ref
 */
export function useForwardedRef<T>(ref: ForwardedRef<T>) {
  const innerRef = useRef<T>(null);

  useEffect(() => {
    if (!ref) return;
    if (typeof ref === 'function') {
      ref(innerRef.current);
    } else {
      ref.current = innerRef.current;
    }
  }, [ref]);

  return innerRef;
}

/** 重置弹窗表单数据 */
export const useResetModalOnCloseModal = ({ reset, open }: ResetModalType) => {
  const prevOpenRef = useRef<boolean>();
  useEffect(() => {
    prevOpenRef.current = open;
  }, [open]);
  const prevOpen = prevOpenRef.current;

  useEffect(() => {
    // 打开表单，且开启Form时重置表单数据
    if (!open && prevOpen && reset) {
      reset();
    }
  }, [prevOpen, open, reset]);
};

/**
 * 获取可复用弹窗
 * @returns 返回弹窗和打开方法
 * @example
 * // onOpen, ChoosePopup名可自定义
 * const [ open, ChoosePopup ] = useChooseModal();
 * ...
 * <ChoosePopup title="弹窗1" onFinish={(value, flag) => console.log(value, flag)}>
 *   <Form.Item name="name" label="User Name">
 *     <Input />
 *   </Form.Item>
 * </ChoosePopup>
 * <Button onClick={() => { open(null, 'flag1')}}>共用1:不回显值</Button>
 * <Button onClick={() => { open('fangle', 'flag2')}}>共用2:回显值</Button>
 */
export function useChooseModal<T extends ChooseModalProps>(
  Modal: any = ChoosePopup,
  /** 弹窗属性 */
  config?: Record<string, any>,
) {
  type ExChooseModalProps = Omit<T, 'onFinish'> & {
    /**
     * 完成选择
     * @param value 选择返回值
     * @param flag 引用ID
     */
    onFinish: (value: any, flag?: NamePath) => void;
  };

  // 返回数组解构函数，方便复用时自定义名称
  type UseFormModal = [
    /**
     * 打开窗口
     * @param flag 引用ID
     */
    open: (value?: any, flag?: NamePath) => void,
    /** 可复用弹窗 */
    Modal: FC<ExChooseModalProps>,
  ];

  const popup = useRef<ChooseModalInstance>(null);

  const _Modal: ComponentsType<FC<ExChooseModalProps>> = (props) => {
    const onFinish = (value: any) => {
      if (props.onFinish) {
        props.onFinish(value, popup.current?.flag);
      }
    };

    return (
      <Modal
        ref={popup}
        {...props}
        {...config}
        crossCol={0}
        onFinish={onFinish}
      >
        {props.children}
      </Modal>
    );
  };
  _Modal.typeName = 'ChooseModal';

  return [
    //open
    useCallback(
      (value, flag) => {
        if (!popup.current!.flag) {
          popup.current!.flag = '';
        }
        popup.current!.flag = flag;

        popup.current!.open(value);
      },
      [popup],
    ),
    //Modal
    useCallback(_Modal, [Modal, config]),
  ] as const as UseFormModal;
}
