import { LinksType } from '@/stores/router';

/**
 * 获取主导航菜单
 * @returns 返回平台主导航
 */
export const getMainNav = async () => {
  return new Promise<LinksType[]>((resolve) => {
    resolve([
      {
        text: 'Login',
        to: 'login',
      },
      {
        text: 'Home',
        to: '/',
      },
      {
        text: 'About',
        to: 'about',
      },
      {
        text: '申请表单1',
        key: 'formview',
        children: [
          { text: '发起', to: 'form/demo/FormView', target: `_blank` },
          {
            text: '审批',
            to: 'form/demo/FormView/?procInstId=adfaf-adfaf-23414-eqr4',
            target: `_blank`,
          },
        ],
      },
      {
        text: '差旅报销',
        key: 'tripview',
        children: [
          { text: '发起', to: 'trip/TandEView', target: `_blank` },
          {
            text: '审批',
            to: 'trip/TandEView/?procInstId=adfaf-adfaf-23414-eqr4',
            target: `_blank`,
          },
        ],
      },
      {
        text: '资产管理',
        key: 'tealpointview',
        children: [
          {
            text: '资产转移电子流',
            to: 'form/assetManagement/TransferView',
            target: `_blank`,
          },
          {
            text: '资产清退报废电子流',
            to: 'form/assetManagement/ScrapView',
            target: `_blank`,
          },
          {
            text: '资产赔偿电子流',
            to: 'form/assetManagement/CompensateView',
            target: `_blank`,
          },
          {
            text: '资产维修电子流',
            to: 'form/assetManagement/RepairView',
            target: `_blank`,
          },
        ],
      },
      {
        text: 'Management',
        key: 'datadictview',
        children: [
          {
            text: '数据字典',
            to: 'Management/DictView',
            target: `_blank`,
          },
        ],
      },
    ]);
  });
};
