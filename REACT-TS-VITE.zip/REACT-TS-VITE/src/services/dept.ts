import { DeptDataNode } from '@/stores/dept';
import { fakeNetwork } from '@/utils';

/**
 * 获取组织树
 * @returns 返回组织树
 */
export const getDepts = async () => {
  await fakeNetwork();
  return new Promise<DeptDataNode[]>((resolve) => {
    resolve([
      {
        title: 'A公司',
        key: '0',
        children: [
          { title: '行政部', key: '0-1', isLeaf: true },
          { title: '财务部', key: '0-2', isLeaf: true },
          { title: 'IT部', key: '0-3', isLeaf: true },
        ],
      },
      {
        title: 'B公司',
        key: '1',
        children: [
          { title: '财务部', key: '1-1', isLeaf: true },
          { title: 'IT部', key: '1-2', isLeaf: true },
        ],
      },
      { title: 'C公司', key: '2', isLeaf: true },
    ]);
  });
};
