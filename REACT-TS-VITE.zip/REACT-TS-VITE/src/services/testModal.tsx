import {
  Button,
  Form,
  FormInstance,
  Input,
  message,
  Modal,
  ModalProps,
} from 'antd';
import React, {
  forwardRef,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import { PropsWithoutRef, useCallback } from 'react';

type ModalRefType<T> =
  | { open: (initProp?: Partial<T>) => void; close: () => void }
  | undefined;

export const useFormModal = function <T>(
  modalProps: Partial<ModalProps>,
  Slot: React.ComponentType<T>,
) {
  const modalRef = useRef<ModalRefType<T>>();

  const FormModal = forwardRef<ModalRefType<T>, T>((slotProps, mRef) => {
    const [visiable, setVisiable] = useState(false);
    const [loading, setLoading] = useState(false);
    const [slotInitProp, setSlotInitProp] = useState<Partial<T>>();
    const open = (initProp?: Partial<T>) => {
      if (initProp) {
        setSlotInitProp(initProp);
      }
      setVisiable(true);
    };
    const close = () => {
      setVisiable(false);
    };
    useImperativeHandle(mRef, () => ({ open, close }));
    const onCancel = () => {
      close();
    };
    const formRef = React.useRef<FormInstance>();
    const ok = () => {
      formRef.current?.submit();
    };
    return (
      <Modal
        onCancel={onCancel}
        onOk={ok}
        open={visiable}
        wrapClassName="modal-wrap"
        okText="提交"
        cancelButtonProps={{ shape: 'round' }}
        okButtonProps={{ shape: 'round' }}
        confirmLoading={loading}
        width={600}
        {...modalProps}
      >
        <Slot
          ref={formRef}
          {...slotProps}
          {...slotInitProp}
          afterSubmit={() => {
            setLoading(false);
            close();
          }}
          beforeSubmit={() => setLoading(true)}
        />
      </Modal>
    );
  });
  FormModal.displayName = 'FormModal';
  return {
    FormModal: useCallback(
      (props: PropsWithoutRef<T>) => {
        return <FormModal ref={modalRef} {...props} />;
      },
      [FormModal],
    ),
    modalRef,
  };
};

interface UserFormPropsType {
  depart?: number;
  beforeSubmit?: (values: any) => void;
  afterSubmit?: (values: any, form: FormInstance<any>) => void;
}
const UserForm = (
  props: React.PropsWithChildren<UserFormPropsType>,
  ref?: React.ForwardedRef<FormInstance>,
) => {
  const [form] = Form.useForm();

  const onSubmit = async (values: any) => {
    props.beforeSubmit?.(values);
    // 模拟请求
    await new Promise((r) => {
      setTimeout(r, 3000);
    });
    props.afterSubmit?.(values, form);
    message.success('操作完成~');
    form.resetFields();
  };
  return (
    <div className="form">
      <Form
        onFinish={onSubmit}
        ref={ref}
        form={form}
        labelCol={{ span: 4 }}
        wrapperCol={{ span: 16 }}
      >
        <Form.Item
          label="用户名"
          name="uname"
          rules={[{ required: true, message: 'Please input  username!' }]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="用户邮箱"
          name="mail"
          rules={[{ required: true, message: 'Please input mail!' }]}
        >
          <Input />
        </Form.Item>
      </Form>
    </div>
  );
};

export default function TestPage() {
  const { modalRef, FormModal: UserModal } = useFormModal(
    { title: '新建用户' },
    React.forwardRef(UserForm),
  );

  return (
    <div>
      <div className="text-center">
        <Button
          type="primary"
          onClick={() => modalRef.current?.open({ depart: 1 })}
        >
          新增
        </Button>
      </div>
      <UserModal />
    </div>
  );
}
