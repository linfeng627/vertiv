import { ApprovalHistoryType } from '@/stores/approvalHistory';
// fake a cache so we don't slow down stuff we've already seen

/**
 * 根据流程实例获取审批历史记录数据
 * @param procInstId 流程实例
 * @returns 返回指定流程实例的流转记录
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export const getApprovalHistory = async (procInstId: string) => {
  /**
   * [待处理]假数据，需修为实际异步服务端请求
   * GET http://xxx/form/approvalHistory
   * request data
   * {
   *   procInstId,
   * }
   */
  // console.log(`procInstId: ${procInstId}`);
  // 返回数据按procInstId状态管理，防止重复调用
  return new Promise<ApprovalHistoryType[]>((resolve) => {
    resolve([
      {
        destActName: '流程开始',
        destUserName: 'Fangle',
        destUserId: 'edf2343-ae34f6-2344-443',
        gender: 'male',
        avatar: 'edf2343-ae34f6-2344-443.png',
        action: 'launch',
        startTime: '2022-09-17 09:12:03',
        endTime: '2022-09-17 09:12:03',
      },
      {
        destActName: '主管审批',
        destUserName: 'Tony',
        destUserId: 'edf2343-ae34f6-2344-443',
        gender: 'secret',
        avatar: 'edf2343-ae34f6-2344-443.png',
        action: 'agree',
        approvalComments:
          '同意审批流程，没有任何意见。同意审批流程，没有任何意见。同意审批流程，没有任何意见。',
        startTime: '2022-09-17 10:00:21',
        endTime: '2022-09-18 09:01:14',
      },
      {
        destActName: '财务审批',
        destUserName: 'Mary',
        destUserId: 'edf2343-ae34f6-2344-443',
        gender: 'female',
        avatar: 'edf2343-ae34f6-2344-443.png',
        startTime: '2022-09-18 10:45:34',
      },
    ]);
  });
};
