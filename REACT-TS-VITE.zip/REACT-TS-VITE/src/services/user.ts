import { PaginationRsp } from '@/stores';
import { UserDataType } from '@/stores/user';
import { ApiResponseModel } from '@/views/form/baseForm/stores/formStore';
import { DataNode } from 'antd/lib/tree';
import axios from 'axios';

/**
 * 根据部门获取人员列表
 * @param deptId 组织编号
 * @returns 返回人员列表
 * @example
 * [POST] /api/user
 * request header: UsersHdr
 * request data: UsersReq
 * ---
 * response data: UsersRsp
 * ---
 * data type:UserDataType
 */
export const getUsersByDept = async (
  deptId: string | number,
  pageNum = 1,
  pageSize = 5,
) => {
  console.log(`deptId: ${deptId}`);
  console.log(`pageNum: ${pageNum}`);
  return await axios
    .get<ApiResponseModel<UserDataType[]>>('/api/userlist')
    .then((res) => {
      const page: PaginationRsp = {
        total: res.data.data.length,
        pageNum: pageNum,
        pageSize: pageSize,
        totalPages:
          res.data.data.length % pageSize === 0
            ? res.data.data.length / pageSize
            : Math.trunc(res.data.data.length / pageSize) + 1,
      };
      return { data: res.data.data, pageInfo: page };
    });
};

/**
 * 获取资产转移电子流表单数据
 * @param pricInstid
 */
export const CapitalTransferFormData = async (pricInstid?: string | number) => {
  console.log(`pricInstid: ${pricInstid}`);
  return axios
    .get<ApiResponseModel>('/api/CapitalTransfer/GetFormData')
    .then((res) => res.data.data);
};

/**
 * 数据字典树
 * @param pricInstid
 * @returns
 */
export const GetDictTree = async () => {
  // console.log(`pricInstid: ${pricInstid}`);
  return axios
    .get<ApiResponseModel<Array<DataNode>>>('/api/DataDictionary/GetDictTree')
    .then((res) => {
      console.log(res.data);
      return res.data;
    });
};
