import { ApiResponseModel } from '@/views/form/baseForm/stores/formStore';
import axios from 'axios';

export interface DictDataType {
  key: React.Key;
  itemKey: string;
  itemValue: string;
  itemName: string;
  remark?: string;
  startTime: string;
  endTime: string;
}

/**
 * 获取数据字典项
 * @param parentid
 * @returns
 */
export const getDictItems = async (parentid: string) => {
  console.log(`pricInstid: ${parentid}`);
  return axios
    .get<ApiResponseModel<Array<DictDataType>>>(
      '/api/DataDictionary/GetDictItems',
    )
    .then((res) => {
      console.log(res.data);
      return res.data;
    });
};
