export interface CapitalTransferElectronFlow {
  /* 是否为电脑或软件转移 */
  computerOrSoftware: boolean;
  /**公司段 */
  companyType: string;
  /**转出部门 */
  outDept: OutDeptModel;
  /**转入部门 */
  inputDept: InputDeptModel;
  /**资产明细 */
  assetDetail: Array<CapitalDetailModel>;
  /**资产转移原因 */
  capitalTransferRemark: string;
  /**上传附件 */
  uploadFiles: Array<Attachment>;
  /** 审批历史 */
  approvalHistory: Array<ApprovalHistory>;
}

/**转出部门 */
export interface OutDeptModel {
  /**使用人ID */
  userID: string;
  /**部门名称(大部门) */
  deptName: string;
  /**部门编码 */
  deptCode: string;
  /**部门名称(小部门) */
  deptName2: string;
  /**转移原因 */
  leaveTransfer: boolean;
  /**PC数据清理确认 */
  pCDataClear: string;
  /**转出部门一级资产管理员 */
  firstAdmin: string;
  /**转出部门主管 */
  manager: string;
  /**转出资产所缺配件 */
  sparepart: string;
}

/**转入部门 */
export interface InputDeptModel {
  /**使用人ID */
  userID: string;
  /**部门名称(大部门) */
  deptName: string;
  /**部门编码 */
  deptCode: string;
  /**部门名称(小部门) */
  deptName2: string;
  /**转入部门一级资产管理员 */
  firstAdmin: string;
}

/**资产明细 */
export interface CapitalDetailModel {
  /**资产编号 */
  identifier: string;
  /**资产名称 */
  name: string;
  /**使用人姓名 */
  useName: string;
  /**使用人工号 */
  useCode: string;
  /**部门名称 */
  deptName: string;
  /**部门代码 */
  deptCode: string;
  /**附属物品 */
  attachItem: string;
  /**存放位置 */
  savePosition: string;
  /**产品段 */
  product: string;
}

/**附件 */
export interface Attachment {
  /**文件名 */
  fileName: string;
  /**文件大小 */
  fileSize: string;
  /**文件类型 */
  fileType: string;
  /**上传时间 */
  date: string;
  /**上传节点 */
  activityName: string;
  /**上传人 */
  userName: string;
}

/**审批历史 */
export interface ApprovalHistory {
  id: number;
  activityName: string;
  approver: string;
  action: string;
  date: string;
  reamrk: string;
}
