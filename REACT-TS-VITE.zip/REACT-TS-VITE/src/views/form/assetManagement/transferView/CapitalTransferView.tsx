/* eslint-disable no-debugger */
//#region 导入
import { FC, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import FormBlock from '@/views/form/baseForm/components/blocks/FormBlock';
import FormBlockSet from '@/views/form/baseForm/components/FormBlockSet';
import FormFiledSet from '@/views/form/baseForm/components/FormFiledSet';
import FormItem from '@/views/form/baseForm/components/FormItem';

import styles from './CapitalTransferView.module.less';
import FormTitelBlock from '../../baseForm/components/blocks/FormTitelBlock';
import {
  Button,
  Form,
  Input,
  Modal,
  Radio,
  Select,
  Space,
  Table,
  Upload,
  UploadFile,
  UploadProps,
} from 'antd';
import ChoosePeople from '@/components/choose/ChoosePeople';
import {
  CaretDownOutlined,
  UploadOutlined,
  UserOutlined,
} from '@ant-design/icons';
//#endregion

import './CapitalTransferView.module.less';
import { useFormBody, useFormContext } from '../../baseForm/stores/formContext';

import { useChooseModal } from '@/services/chooseModal';
import { useFormData } from '../../baseForm/services/formService';
import React from 'react';
import FormTable from '../../baseForm/components/formFields/Table/FormTable';
import XApprovalHistoryBlock from '../../components/blocks/XApprovalHistoryBlock';
import { CapitalTransferFormData } from '@/services/user';
import {
  Attachment,
  CapitalTransferElectronFlow,
} from '@/views/form/assetManagement/transferView/CapitalTransferModel';
import { FormSetConfig } from '../../baseForm/stores/formStore';
import XAttachmentBlock from '../../components/blocks/XAttachmentBlock';
import TiggerChoose from '../../baseForm/components/formFields/TrggerChoose';
import FormEditorTable from '../../baseForm/components/formFields/Table/FormEditorTable';
import XAssetDetaislModal from '../../components/blocks/XAssetDetaislModal';

const { Option } = Select;

/**
 *
 * @returns 返回表单
 */
const CapitalTransferView: FC = () => {
  // 多语言
  const { t } = useTranslation();
  // 通过上下文获取表单form对象
  const formContext = useFormContext();
  const formBody = useFormBody();
  const { formSet, formData } = useFormData<CapitalTransferElectronFlow>();

  //资产明细
  const assetDetailHeader = [
    {
      title: '序号',
      dataIndex: 'num',
      key: 'num',
    },
    {
      title: '资产编号',
      dataIndex: 'code',
      key: 'code',
    },
    {
      title: '资产名称',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '使用人姓名',
      dataIndex: 'username',
      key: 'username',
    },
    {
      title: '使用人工号',
      dataIndex: 'usercode',
      key: 'usercode',
    },
    {
      title: '部门名称',
      dataIndex: 'deptname',
      key: 'deptname',
    },
    {
      title: '部门代码',
      dataIndex: 'deptcode',
      key: 'deptcode',
    },
    {
      title: '附属物品',
      dataIndex: 'attachedItems',
      key: 'attachedItems',
    },
    {
      title: '存放位置',
      dataIndex: 'address',
      key: 'address',
    },
    {
      title: '产品段',
      dataIndex: 'productname',
      key: 'productname',
    },
  ];

  // 获取表单数据
  const [formheader, SetFormheader] = useState<FormSetConfig>();
  const [assetDetail, SetAssetDetail] = useState<Attachment[]>([]);
  useEffect(() => {
    CapitalTransferFormData().then((res) => {
      console.log(res);
      formContext.setFieldsValue(res.formData);
      SetFormheader(res.formSet);
      SetAssetDetail(res.formData.assetDetail);
    });
  }, []);

  const [fileList, setFileList] = useState<UploadFile[]>([
    {
      uid: '-1',
      name: 'xxx.png',
      status: 'done',
      url: 'http://www.baidu.com/xxx.png',
    },
  ]);

  const handleChange: UploadProps['onChange'] = (info) => {
    let newFileList = [...info.fileList];
    newFileList = newFileList.slice(-2);
    newFileList = newFileList.map((file) => {
      if (file.response) {
        file.url = file.response.url;
      }
      return file;
    });

    setFileList(newFileList);
  };
  /**文件上传 */
  const fileUploadprops: UploadProps = {
    action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    onChange: handleChange,
    multiple: true,
  };

  //转出部门 选人控件
  // 选人弹窗联动
  const [openModal, ChoosePopupModal] = useChooseModal();
  const onClick = function () {
    console.log('aaa');
  };

  const textAreaHandleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    // inputRef.current?.select();
    e.target.value;
  };

  // const

  return (
    <FormBlockSet key="cccc" className={styles['capital-transfer-form']}>
      <FormTitelBlock key="kTitle" title="资产转移电子流" {...formheader} />
      <FormBlock
        // hidden={true}
        key="K001"
        header="表单信息"
        className="aaa-block"
        cols={1}
      >
        <FormFiledSet>
          <FormItem
            //hidden={true}
            name="computerOrSoftware"
            label="是否为电脑或软件转移"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Radio.Group>
              <Radio value={true}>是</Radio>
              <Radio value={false}>否</Radio>
            </Radio.Group>
          </FormItem>
          <FormItem
            name="companyType"
            label="公司段"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Select
              showSearch
              placeholder="Search to Select"
              optionFilterProp="children"
              filterOption={(input, option) =>
                (option!.children as unknown as string).includes(input)
              }
              filterSort={(optionA, optionB) =>
                (optionA!.children as unknown as string)
                  .toLowerCase()
                  .localeCompare(
                    (optionB!.children as unknown as string).toLowerCase(),
                  )
              }
            >
              <Option value="1">Not Identified</Option>
              <Option value="2">Closed</Option>
              <Option value="3">Communicated</Option>
              <Option value="4">Identified</Option>
              <Option value="5">Resolved</Option>
              <Option value="6">Cancelled</Option>
            </Select>
          </FormItem>
        </FormFiledSet>
        <FormFiledSet title="转出部门">
          <FormItem
            name={['outDept', 'userID']}
            label="使用人ID"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <TiggerChoose
              placeholder="请选择人员"
              icon={UserOutlined}
              modal={ChoosePeople}
              onFinish={(value: any) => {
                const names: string[] = [];
                const keys: string[] = [];
                value.forEach((record: any) => {
                  names.push(record.name.first);
                  keys.push(record.id);
                });
                formContext.setFieldValue(
                  ['outDept', 'userID'],
                  names.join(', '),
                );
              }}
            />
          </FormItem>
          <FormItem
            name={['outDept', 'deptName']}
            label="部门名称(大部门)"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
          <FormItem
            name={['outDept', 'deptCode']}
            label="部门编码"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
          <FormItem
            name={['outDept', 'deptName2']}
            label="部门名称(小部门)"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
          <FormItem
            name={['outDept', 'leaveTransfer']}
            label="转移原因"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Radio.Group>
              <Radio value={true}>离职转移</Radio>
              <Radio value={false}>非离职转移</Radio>
            </Radio.Group>
          </FormItem>
          <FormItem
            name={['outDept', 'pCDataClear']}
            label="PC数据清理确认"
            rules={[{ required: true, message: 'Required Field' }]}
            required
            tooltip="说明：未经授权将公司保存有保密信息的计算机、信息设备、电子存储介质等做数据清理、擦除或者销毁，将按照《ENPGC【2017】-NO.24-员工行为管理规范》处罚"
          >
            <Input></Input>
          </FormItem>
        </FormFiledSet>
        <FormFiledSet title="转入部门">
          <FormItem
            name={['inputDept', 'userID']}
            label="使用人ID"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <TiggerChoose
              placeholder="请选择人员"
              icon={UserOutlined}
              modal={ChoosePeople}
              onFinish={(value: any) => {
                const names: string[] = [];
                const keys: string[] = [];
                value.forEach((record: any) => {
                  names.push(record.name.first);
                  keys.push(record.id);
                });
                formContext.setFieldValue(
                  ['inputDept', 'userID'],
                  names.join(', '),
                );
              }}
            />
          </FormItem>
          <FormItem
            name={['inputDept', 'deptName']}
            label="部门名称(大部门)"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
          <FormItem
            name={['inputDept', 'deptCode']}
            label="部门编码"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
          <FormItem
            name={['inputDept', 'deptName2']}
            label="部门名称(小部门)"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
        </FormFiledSet>
        <FormFiledSet title=" ">
          <FormItem
            name={['outDept', 'firstAdmin']}
            label="转出部门一级资产管理员"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <TiggerChoose
              placeholder="请选择人员"
              icon={UserOutlined}
              modal={ChoosePeople}
              onFinish={(value: any) => {
                const names: string[] = [];
                const keys: string[] = [];
                value.forEach((record: any) => {
                  names.push(record.name.first);
                  keys.push(record.id);
                });
                formContext.setFieldValue(
                  ['outDept', 'firstAdmin'],
                  names.join(', '),
                );
              }}
            />
          </FormItem>
          <FormItem
            name={['inputDept', 'firstAdmin']}
            label="转入部门一级资产管理员"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <TiggerChoose
              placeholder="请选择人员"
              icon={UserOutlined}
              modal={ChoosePeople}
              onFinish={(value: any) => {
                const names: string[] = [];
                const keys: string[] = [];
                value.forEach((record: any) => {
                  names.push(record.name.first);
                  keys.push(record.id);
                });
                formContext.setFieldValue(
                  ['inputDept', 'firstAdmin'],
                  names.join(', '),
                );
              }}
            />
          </FormItem>
          <FormItem
            name={['outDept', 'manager']}
            label="转出部门主管"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <TiggerChoose
              placeholder="请选择人员"
              icon={UserOutlined}
              modal={ChoosePeople}
              onFinish={(value: any) => {
                const names: string[] = [];
                const keys: string[] = [];
                value.forEach((record: any) => {
                  names.push(record.name.first);
                  keys.push(record.id);
                });
                formContext.setFieldValue(
                  ['outDept', 'manager'],
                  names.join(', '),
                );
              }}
            />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet title="资产明细" cols={1}>
          <FormItem
            shouldUpdate={(prevValues, currentValues) =>
              prevValues.gyxzk1 !== currentValues.gyxzk1
            }
          >
            <Button
              type="primary"
              size="small"
              onClick={() => openModal(null, 'zcmx')}
            >
              新增资产明细
            </Button>
          </FormItem>
          <FormItem
            key="ktable3"
            label=""
            wrapperCol={{ span: 24 }}
            className="custom-table"
          >
            <FormTable
              key="njbasdhfge"
              columns={assetDetailHeader}
              dataSource={assetDetail}
            ></FormTable>
          </FormItem>
          <FormItem>
            <ChoosePopupModal
              title="资产明细"
              width={1000}
              onFinish={(value, flag) => {
                debugger;
                if (flag) {
                  formContext.setFieldValue(flag, value.name);
                  formContext.validateFields([flag]);
                }
                console.log(value, flag);
              }}
            >
              <FormFiledSet cols={3}>
                <FormItem name="name" label="工号" rules={[{ required: true }]}>
                  <Input />
                </FormItem>
                <FormItem name="name2" label="资产编号">
                  <Input />
                </FormItem>
              </FormFiledSet>
              <FormFiledSet cols={3}>
                <FormItem
                  name="name"
                  label="使用人"
                  rules={[{ required: true }]}
                >
                  <Input />
                </FormItem>
                <FormItem name="name2" label="资产名称">
                  <Input />
                </FormItem>
                <FormItem name="name2" label="">
                  <Button size="small" type="primary">
                    查询
                  </Button>
                </FormItem>
              </FormFiledSet>
              <Table
                scroll={{ x: 900, y: 500 }}
                columns={assetDetailHeader}
                dataSource={assetDetail}
                rowSelection={{
                  onChange: (selectedRowKeys, selectedRows) => {
                    console.log(
                      `selectedRowKeys: ${selectedRowKeys}`,
                      'selectedRows: ',
                      selectedRows,
                    );
                  },
                  onSelect: (record, selected, selectedRows) => {
                    console.log(record, selected, selectedRows);
                  },
                  onSelectAll: (selected, selectedRows, changeRows) => {
                    console.log(selected, selectedRows, changeRows);
                  },
                }}
              ></Table>
            </ChoosePopupModal>
          </FormItem>
        </FormFiledSet>
        <FormFiledSet>
          <FormItem
            fill
            label="资产转移原因"
            name="capitalTransferRemark"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input.TextArea
              rows={2}
              placeholder={`意见在1000字以内`}
              showCount
              maxLength={1000}
              onChange={textAreaHandleChange}
            />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet>
          <FormItem
            fill
            label="转出资产所缺配件"
            name={['outDept', 'sparepart']}
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input.TextArea
              rows={2}
              placeholder={`意见在1000字以内`}
              showCount
              maxLength={1000}
              onChange={textAreaHandleChange}
            />
          </FormItem>
        </FormFiledSet>
        {/* <FormFiledSet>
          <FormItem name="UploadFiles" label="上传附件">
            <Upload {...fileUploadprops} fileList={fileList}>
              <Button icon={<UploadOutlined />}>点击上传附件</Button>
            </Upload>
          </FormItem>
        </FormFiledSet> */}
        <FormFiledSet cols={3}>
          <FormItem labelCol={{ span: 3 }} wrapperCol={{ span: 21 }}>
            <Space>
              <Button
                type="primary"
                size="small"
                name="btnSubmit"
                onClick={formContext.submit}
              >
                提交
              </Button>
              <Button
                type="primary"
                size="small"
                name="btnSaveDraft"
                onClick={() => {
                  console.log('btnSaveDraft');
                }}
              >
                保存
              </Button>
              <Button type="primary" size="small" name="btnUndo">
                作废
              </Button>
            </Space>
          </FormItem>
          <FormItem label="签字" className="signAndDate"></FormItem>
          <FormItem label="时间" className="signAndDate"></FormItem>
        </FormFiledSet>
      </FormBlock>
      <FormBlock hidden={true} key="K002" header="2.转出部门主管审核" cols={1}>
        <FormFiledSet fill>
          <FormItem
            label="审批"
            name="ApprovalAction"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Radio.Group>
              <Radio value={1}>同意</Radio>
              <Radio value={0}>不同意，退回申请人</Radio>
            </Radio.Group>
          </FormItem>
          <FormItem
            label="意见"
            name={['approvalComment', 'comment']}
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
            fill
          >
            <Input.TextArea
              rows={2}
              placeholder={`意见在500字以内`}
              showCount
              maxLength={500}
              onChange={textAreaHandleChange}
            />
          </FormItem>
          <FormItem
            fill
            name="CCList"
            label="抄送人"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
          >
            <Input
              readOnly
              placeholder="请选择人员"
              allowClear
              addonAfter={<UserOutlined onClick={onClick} />}
              onClick={onClick}
              onFocus={(e) => {
                e.target.blur();
              }}
            />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet cols={3}>
          <FormItem labelCol={{ span: 3 }} wrapperCol={{ span: 21 }}>
            <Space>
              <Button
                type="primary"
                size="small"
                name="btnSubmit"
                onClick={formContext.submit}
              >
                提交
              </Button>
            </Space>
          </FormItem>
          <FormItem label="签字" className="signAndDate"></FormItem>
          <FormItem label="时间" className="signAndDate"></FormItem>
        </FormFiledSet>
      </FormBlock>
      <FormBlock
        hidden={true}
        key="K003"
        header="3.IT热线数据清理确认"
        cols={1}
      >
        <FormFiledSet fill>
          <FormItem
            label="审批"
            name="ApprovalAction"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Radio.Group>
              <Radio value={1}>同意</Radio>
              <Radio value={0}>不同意，退回申请人</Radio>
            </Radio.Group>
          </FormItem>
          <FormItem
            label="意见"
            name={['approvalComment', 'comment']}
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
            fill
          >
            <Input.TextArea
              rows={2}
              placeholder={`意见在500字以内`}
              showCount
              maxLength={500}
              onChange={textAreaHandleChange}
            />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet cols={3}>
          <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>
            <Button
              type="primary"
              size="small"
              name="btnSubmit"
              onClick={formContext.submit}
            >
              提交
            </Button>
          </FormItem>
          <FormItem label="签字" className="signAndDate"></FormItem>
          <FormItem label="时间" className="signAndDate"></FormItem>
        </FormFiledSet>
      </FormBlock>
      <FormBlock
        hidden={true}
        key="K004"
        header="4.转出部门一级资产管理员确认"
        cols={1}
      >
        <FormFiledSet fill>
          <FormItem
            fill
            label="是否需要转入部门主管"
            name="aaa"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Radio.Group>
              <Radio value={1}>是</Radio>
              <Radio value={0}>否</Radio>
            </Radio.Group>
          </FormItem>
          <FormItem
            fill
            label="审批"
            name="ApprovalAction"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Radio.Group>
              <Radio value={1}>同意</Radio>
              <Radio value={0}>不同意，退回申请人</Radio>
            </Radio.Group>
          </FormItem>
          <FormItem
            label="意见"
            name={['approvalComment', 'comment']}
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
            fill
          >
            <Input.TextArea
              rows={2}
              placeholder={`意见在500字以内`}
              showCount
              maxLength={500}
              onChange={textAreaHandleChange}
            />
          </FormItem>
          <FormItem
            fill
            name="userName17"
            label="资产转移账务处理"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
          <FormItem
            fill
            name="userName17"
            label="抄送人"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
          >
            <Input
              readOnly
              placeholder="请选择人员"
              allowClear
              addonAfter={<UserOutlined onClick={onClick} />}
              onClick={onClick}
              onFocus={(e) => {
                e.target.blur();
              }}
            />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet cols={3}>
          <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>
            <Button
              type="primary"
              size="small"
              name="btnSubmit"
              onClick={formContext.submit}
            >
              提交
            </Button>
          </FormItem>
          <FormItem label="签字" className="signAndDate"></FormItem>
          <FormItem label="时间" className="signAndDate"></FormItem>
        </FormFiledSet>
      </FormBlock>
      <FormBlock hidden={true} key="K005" header="5.资产人确认投递" cols={1}>
        <FormFiledSet fill>
          <FormItem
            label="意见"
            name={['approvalComment', 'comment']}
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
            fill
          >
            <Input.TextArea
              rows={2}
              placeholder={`意见在500字以内`}
              showCount
              maxLength={500}
              onChange={textAreaHandleChange}
            />
          </FormItem>
          <FormItem
            fill
            name="userName17"
            label="抄送人"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
          >
            <Input
              readOnly
              placeholder="请选择人员"
              allowClear
              addonAfter={<UserOutlined onClick={onClick} />}
              onClick={onClick}
              onFocus={(e) => {
                e.target.blur();
              }}
            />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet cols={3}>
          <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>
            <Button type="primary" size="small" name="btnSubmit">
              提交
            </Button>
          </FormItem>
          <FormItem label="签字" className="signAndDate"></FormItem>
          <FormItem label="时间" className="signAndDate"></FormItem>
        </FormFiledSet>
      </FormBlock>
      <FormBlock hidden={true} key="K006" header="6.转入接收人确认" cols={1}>
        <FormFiledSet fill>
          <FormItem
            label="审批"
            name="ApprovalAction"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Radio.Group>
              <Radio value={1}>同意</Radio>
              <Radio value={0}>不同意，退回申请人</Radio>
            </Radio.Group>
          </FormItem>
        </FormFiledSet>
        <FormFiledSet>
          <FormItem
            label="确认接收"
            name="userName30"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
          <FormItem
            label="部门主管"
            name="userName31"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
        </FormFiledSet>
        <FormFiledSet>
          <FormItem
            label="产品段"
            name="userName32"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
          <FormItem
            label="存放位置"
            name="userName33"
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Input></Input>
          </FormItem>
        </FormFiledSet>
        <FormFiledSet fill>
          <FormItem
            name="userName17"
            label="抄送人"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
          >
            <Input
              readOnly
              placeholder="请选择人员"
              allowClear
              addonAfter={<UserOutlined onClick={onClick} />}
              onClick={onClick}
              onFocus={(e) => {
                e.target.blur();
              }}
            />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet cols={3}>
          <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>
            <Button type="primary" size="small" name="btnSubmit">
              提交
            </Button>
          </FormItem>
          <FormItem label="签字" className="signAndDate"></FormItem>
          <FormItem label="时间" className="signAndDate"></FormItem>
        </FormFiledSet>
      </FormBlock>
      <FormBlock
        hidden={true}
        key="K007"
        header="7.转入部门一级资产管理员确认"
        cols={1}
      >
        <FormFiledSet fill>
          <FormItem
            label="审批"
            name="ApprovalAction"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Radio.Group>
              <Radio value={1}>同意</Radio>
              <Radio value={0}>不同意，退回申请人</Radio>
            </Radio.Group>
          </FormItem>
          <FormItem
            label="意见"
            name={['approvalComment', 'comment']}
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
            fill
          >
            <Input.TextArea
              rows={2}
              placeholder={`意见在500字以内`}
              showCount
              maxLength={500}
              onChange={textAreaHandleChange}
            />
          </FormItem>
          <FormItem
            label="备注"
            name={['approvalComment', 'comment']}
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
            fill
          >
            <Input.TextArea
              rows={2}
              placeholder={`意见在500字以内`}
              showCount
              maxLength={500}
              onChange={textAreaHandleChange}
            />
          </FormItem>
          <FormItem
            fill
            name="userName17"
            label="抄送人"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
          >
            <Input
              readOnly
              placeholder="请选择人员"
              allowClear
              addonAfter={<UserOutlined onClick={onClick} />}
              onClick={onClick}
              onFocus={(e) => {
                e.target.blur();
              }}
            />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet cols={3}>
          <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>
            <Button type="primary" size="small" name="btnSubmit">
              提交
            </Button>
          </FormItem>
          <FormItem label="签字" className="signAndDate"></FormItem>
          <FormItem label="时间" className="signAndDate"></FormItem>
        </FormFiledSet>
      </FormBlock>
      <FormBlock hidden={true} key="K008" header="8.资产转移账务处理" cols={1}>
        <FormFiledSet fill>
          <FormItem
            label="审批"
            name="ApprovalAction"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
          >
            <Radio.Group>
              <Radio value={1}>同意</Radio>
              <Radio value={0}>不同意，退回申请人</Radio>
            </Radio.Group>
          </FormItem>
          <FormItem
            label="账务处理"
            name={['approvalComment', 'comment']}
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
            rules={[{ required: true, message: 'Required Field' }]}
            fill
          >
            <Input.TextArea
              rows={2}
              placeholder={`意见在500字以内`}
              showCount
              maxLength={500}
              onChange={textAreaHandleChange}
            />
          </FormItem>
          <FormItem
            fill
            name="userName17"
            label="抄送人"
            // labelCol={{ span: 3 }}
            // wrapperCol={{ span: 21 }}
          >
            <Input
              readOnly
              placeholder="请选择人员"
              allowClear
              addonAfter={<UserOutlined onClick={onClick} />}
              onClick={onClick}
              onFocus={(e) => {
                e.target.blur();
              }}
            />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet cols={3}>
          <FormItem labelCol={{ span: 6 }} wrapperCol={{ span: 18 }}>
            <Button type="primary" size="small" name="btnSubmit">
              提交
            </Button>
          </FormItem>
          <FormItem label="签字" className="signAndDate"></FormItem>
          <FormItem label="时间" className="signAndDate"></FormItem>
        </FormFiledSet>
      </FormBlock>
      {/* 流程审批历史 */}
      <FormBlock
        key="KApprovalHistoryBlock"
        header="审批历史"
        cols={1}
        className="custom-table"
      >
        <XApprovalHistoryBlock
          key="4234"
          procInstId={1234}
        ></XApprovalHistoryBlock>
      </FormBlock>
      <FormBlock
        key="KAttachmentBlock"
        header="附件列表"
        cols={1}
        className="custom-table"
      >
        <XAttachmentBlock
          key="aaaavssda123123"
          procInstId={1234}
        ></XAttachmentBlock>
      </FormBlock>
    </FormBlockSet>
  );
};
export default CapitalTransferView;
