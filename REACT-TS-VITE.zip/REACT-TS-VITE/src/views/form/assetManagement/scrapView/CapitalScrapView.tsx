/* eslint-disable prettier/prettier */
//#region 导入
import { FC } from 'react';
import { useTranslation } from 'react-i18next';

import FormBlock from '@/views/form/baseForm/components/blocks/FormBlock';
import FormBlockSet from '@/views/form/baseForm/components/FormBlockSet';
import FormFiledSet from '@/views/form/baseForm/components/FormFiledSet';
import FormItem from '@/views/form/baseForm/components/FormItem';
import { useFormData } from '@/views/form/baseForm/services/formService';

import styles from './CapitalScrapView.module.less';
import FormTitelBlock from '../../baseForm/components/blocks/FormTitelBlock';
import { Button, Space } from 'antd';
//#endregion

/**
 *
 * @returns 返回表单
 */
const CapitalScrapView: FC = () => {
    // 多语言
    const { t } = useTranslation();

    // 表单配置与数据
    const { formSet, formData } = useFormData();

    return (
        <FormBlockSet className={styles['-form']}>
            <FormTitelBlock key="kTitle" title="资产清退报废电子流" />
        </FormBlockSet>
    );
};
export default CapitalScrapView;
