import { fakeNetwork } from '@/utils';
import {
  LoaderFunctionArgs,
  redirect,
  useRouteLoaderData,
} from 'react-router-dom';
import Storage from '@/utils/localStore';
import {
  CurrViewStatus,
  FormIds,
  FormInfo,
  FormItemStatusFN,
  FormViewStatus,
  ItemStatus,
} from '../stores/formStore';
import axios from 'axios';

/**
 * 表单路由载入共享数据
 * @param request 请求信息
 * @returns 返回解构的表单设置和表单数据
 * @example 子孙路由中所有组件中可以通过useLoaderData获取
 * const { formSet, formData } = useFormData();
 */
export async function loader({ request }: LoaderFunctionArgs) {
  // [待处理]判断用户是否登录
  const token = await Storage.get('token');
  if (!token) {
    return redirect('/login');
  }
  const url = new URL(request.url);
  const { formSet, formData } = await LoadFormData(url);
  return { formSet, formData };
}

/**
 * 使用表单配置和数据
 * @returns 表单配置和数据
 */
export function useFormData<T>(routerId?: string) {
  // return useLoaderData() as FormInfo;
  return useRouteLoaderData(routerId ?? 'formRoot') as FormInfo<T>;
}
/**
 * 获取表单当前状态
 * @returns 返回表单当前状态
 */
export function useFormCurrStatus() {
  const { formSet } = useFormData();
  return formSet as CurrViewStatus;
}

/**
 * 异步加载表单配置和表单实例数据。
 * @param url 获取URL参数
 * @returns 返回表单配置和表单实例数据
 */
export const LoadFormData = async (url: URL) => {
  //所有表单相关id
  const ids = {
    formId: url.searchParams.get('formId') ?? '',
    sn: url.searchParams.get('sn') ?? '',
    destInstId: url.searchParams.get('destInstId') ?? '',
    procInstId: url.searchParams.get('procInstId') ?? '',
  };
  /**
   * [待处理]这里根据项目需要替换成实际的异步服务端请求
   * GET http://xxx/form
   * request data
   * {
   *   ...ids,
   * }
   */
  return new Promise<FormInfo>((resolve) => {
    resolve({
      formSet: {
        ...ids, //所有表单相关id
        formViewStatus: 'approval', // 表单视图状态
        enableProcInstLogs: false, // 是否启用侧边栏显示流转记录
        enableFormSideCatalog: false, // 是否启用快捷目录
        actionPosition: 'top', // 表单操作按钮集显示位置
        header: '申请表单',
        actions: [
          {
            text: '同意',
            action: 'agree',
            // style: 'color:green;',
          },
          {
            text: '沟通',
            action: 'communicate',
          },
          {
            text: '拒绝',
            action: 'reject',
            // className: 'reject2',
          },
          {
            text: '转签',
            action: 'turnToDo',
            collapsed: true, //自动放入更多按钮中
          },
        ],
        formCompTree: {
          tables: [
            {
              title: '姓名',
              dataIndex: 'name',
              key: 'name',
              width: '30%',
              editable: true,
            },
            {
              title: '金额',
              dataIndex: 'amount',
              key: 'amount',
            },
            {
              title: '描述',
              dataIndex: 'desc',
              key: 'desc',
              width: '30%',
              editable: true,
            },
          ],
        },
      },
      formData: {
        formInstId: Math.random().toString(36).substring(2, 9),
        userName: 'Fangle',
        email: 'fangjing24@gmail.com',
        desp: '因业务需要',
        // approvalComment: {
        //   comment: '附件需补齐',
        //   cc: 'Fangle',
        // },
        tables: [
          {
            key: '1',
            name: 'Fangle',
            amount: 10000,
            desc: '吃喝玩乐',
          },
          {
            key: '2',
            name: 'Tony',
            amount: 15000,
            desc: '吃喝玩乐吃喝玩乐',
          },
          {
            key: '3',
            name: 'John',
            amount: 17000,
            desc: '吃喝玩乐吃喝玩乐吃喝玩乐',
          },
          {
            key: '4',
            name: 'Tom',
            amount: 25000,
            desc: '吃喝玩乐吃喝玩乐吃喝',
          },
        ],
      },
    });
  });
};

/**
 * 表单统一执行操作
 * @param action 操作名
 * @param formData 表单数据
 * @param comment 审批意见
 * @param ids 所有表单相关ID
 */
export const executeFormAction = async (
  ids: FormIds,
  action: string,
  formData: FormInfo,
  comment?: string | any,
) => {
  //所有表单相关id

  console.log('action: ', action);
  console.log('ids: ', ids);
  console.log('comment: ', comment);
  console.log(formData);
  /**
   * [待处理]这里需要改为实际的远程操作
   * POST http://xxx/form/action
   * request data
   * {
   *  ...ids,
   *  action,
   *  formdata: formData.formData,
   * }
   */
  switch (action) {
    default:
      await fakeNetwork();
      console.log(`'${formData.formSet.header}' 表单，${action}操作成功！`);
      break;
  }
};

/**
 * 默认表单项规则定义
 * @param status 当前表单状态
 * @param fn 自定义表单项状态
 * @returns 返回表单项
 */
export const FormItemDisable: FormItemStatusFN = (status, fn) => {
  /**
   * 默认规则：
   * - 查看视图时全部只读
   * - 打印视图时全部只读
   */
  let rtn: ItemStatus = {
    disabled:
      status.formViewStatus == 'view' || status.formViewStatus == 'print'
        ? true
        : undefined,
  };

  if (fn) {
    rtn = fn(status, rtn);
  }
  return rtn;
};

/**
 * 是否发起视图
 * @example
 * const status = useFormCurrStatus();
 * if (isLaunchView(status.formViewStatus)) {
 *   //
 * }
 */
export function isLaunchView(status: FormViewStatus) {
  return status == 'launch';
}

/**
 * 是否审批视图
 * @example
 * const status = useFormCurrStatus();
 * if (isApprovalView(status.formViewStatus)) {
 *   //
 * }
 */
export function isApprovalView(status: FormViewStatus) {
  return status == 'approval';
}

/**
 * 是否查看视图
 * @example
 * const status = useFormCurrStatus();
 * if (isViewView(status.formViewStatus)) {
 *   //
 * }
 */
export function isViewView(status: FormViewStatus) {
  return status == 'view';
}

/**
 * 是否打印视图
 * @example
 * const status = useFormCurrStatus();
 * if (isPrintView(status.formViewStatus)) {
 *   //
 * }
 */
export function isPrintView(status: FormViewStatus) {
  return status == 'print';
}
