//#region 导入
import { FC } from 'react';
// import { useTranslation } from 'react-i18next';

import { Input } from 'antd';
import FormBlock, { FormPanelProps } from './FormBlock';
import { SlotPosition } from '@/stores';
import FormItem from '../FormItem';
import {
  useFormCurrStatus,
  isLaunchView,
  isViewView,
} from '../../services/formService';
// import { useFormData } from '../../services/formService';
//#endregion

/** 审批意见最大输入字符数 */
const approvalCommentsMaxLength = 500;

/** 组件属性 */
export interface ApprovalCommentsProps extends FormPanelProps {
  /** 审批意见长度，默认500字 */
  maxLength?: number;
  // getComment: () => string;
  /**
   * 插槽定位声明
   * - `'top'` 顶部
   * - `'bottom'` 底部
   */
  slotPosition?: SlotPosition;
}

/**
 * 审批意见板块
 * @param props 表单板块属性
 * @returns 返回组件
 */
const ApprovalCommentsBlock: FC<ApprovalCommentsProps> = (props) => {
  // 审批视图显示
  const status = useFormCurrStatus();
  if (
    isLaunchView(status.formViewStatus) ||
    isViewView(status.formViewStatus)
  ) {
    return null;
  }
  // const { formSet } = useFormData();

  // 审批意见输入框对象引用
  // const inputRef = useRef<InputRef>(null);

  const maxLength = props.maxLength ?? approvalCommentsMaxLength;
  const cpProps: FormPanelProps = {
    header: '审批意见',
    collapsible: 'disabled',
    cols: 1,
    ...props,
  };
  cpProps.className += ' form-approval-comments-block';

  //[待处理]获取审批意见，特殊组件，内容不包含在表单数据中。
  function handleChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    // inputRef.current?.select();
    e.target.value;
  }
  const slotPosition = props.slotPosition ?? 'bottom';
  return (
    <FormBlock {...cpProps}>
      {slotPosition == 'top' && props.children ? props.children : null}
      <FormItem noStyle name={['approvalComment', 'comment']} fill>
        <Input.TextArea
          rows={4}
          placeholder={`意见在${maxLength}字以内`}
          showCount
          maxLength={maxLength}
          // ref={inputRef}
          onChange={handleChange}
        />
      </FormItem>
      {slotPosition == 'bottom' && props.children ? props.children : null}
    </FormBlock>
  );
};

export default ApprovalCommentsBlock;
