//#region 导入
import { Children, FC, isValidElement } from 'react';
// import { useTranslation } from 'react-i18next';
import { JsonStore, Partial2 } from '@/utils';

import { Col, Collapse, CollapsePanelProps, Row } from 'antd';
import { ComponentsType } from '@/stores/index';
const { Panel } = Collapse;
//#endregion

/**
 * 板块属性
 *
 * 将CollapsePanelProps接口中header属性改为可选
 */
export interface FormPanelProps
  extends Partial2<CollapsePanelProps, 'header' | 'key'> {
  /** 板块标识 */
  key: string | number;
  /** 初始值 */
  initialValues?: JsonStore;
  /** 字段列列数，自动覆盖span.colSpan设置 */
  cols?: number;
  /** 是否隐藏板块 */
  hidden?: boolean;
}

/**
 * 表单通用板块，默认两列等分布局
 * @param props 板块属性
 * @returns 返回表单通用板块
 */
const FormBlock: FC<FormPanelProps> = (props) => {
  //通过上下文获取表单form对象
  // const form = useFormContext();

  //默认一行两列
  const cols = props.cols ?? 2;
  const colLayout = {
    span: 24 / cols,
  };

  // 合并所有属性，给header赋默认值
  const blockProps = {
    header: undefined,
    // 配置ID用于快捷目录组件（FormSideCatalog）寻找板块锚点
    id: String(props.id ?? props.key),
    ...props,
  };

  return (
    <Panel
      {...blockProps}
      className={`form-block form-block-${blockProps.id.toString()} ${
        blockProps.className ?? ''
      } ${props.hidden === true ? 'nbl-hidden' : ''}`}
    >
      <Row gutter={24}>
        {Children.map(blockProps.children, (child) => {
          if (!child || !isValidElement(child)) {
            return null;
          }
          const typeName = (child.type as ComponentsType).typeName;
          if (typeName == 'ChooseModal') {
            return child;
          }
          // FormItem强制定义了跨列，则按FormItem为准
          let span = colLayout.span;
          // 因子组件类型不可预知。如报错，则放弃跨列。
          try {
            if (child.props.fill) {
              span = 24;
            } else if (child.props.crossCol) {
              span = span * child.props.crossCol;
            }
          } catch {
            console.log('此组件不适用跨列');
          }
          return <Col span={span}>{child}</Col>;
        })}
      </Row>
    </Panel>
  );
};

export default FormBlock;
