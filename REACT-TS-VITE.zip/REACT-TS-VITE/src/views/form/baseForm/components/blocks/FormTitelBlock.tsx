/* eslint-disable prettier/prettier */
import ChoosePeople from '@/components/choose/ChoosePeople';
import { UserOutlined } from '@ant-design/icons';
import { Button, Card, Col, Input, Row, Space } from 'antd';
import React, { useState } from 'react';
import TiggerChoose from '../formFields/TrggerChoose';
import FormFiledSet from '../FormFiledSet';
import FormItem from '../FormItem';
import './FormTitle.less';

interface props {
  title: string;
  procInstId?: string;
  activityName?: string;
  procStatus?: string;
  approver?: string;
}

const FormTitelBlock: React.FC<props> = (props) => {
  const [forwardUser, SetforwardUser] = useState<Array<string>>([]);

  return (
    <div className="formtile">
      <Row justify="space-around" align="middle">
        <Col>
          <span className="height120">{props.title}</span>
        </Col>
      </Row>
      <Row className="folio">
        <Col span={23}>电子流程编号:{props.procInstId}</Col>
      </Row>
      <FormFiledSet cols={4} className="baseinfo">
        <FormItem label="当前环节" className="currentActivity">
          {props.activityName}
        </FormItem>
        <FormItem label="当前状态">{props.procStatus}</FormItem>
        <FormItem label="当前处理人">{props.approver}</FormItem>
        <FormItem
          name="forwardUser"
          label=""
          labelCol={{ span: 3 }}
          wrapperCol={{ span: 21 }}
        >
          <Input.Group compact>
            <TiggerChoose
              style={{ width: 'calc(100% - 65px)' }}
              size="small"
              icon={UserOutlined}
              placeholder="请选择人员"
              multiple={true}
              modal={ChoosePeople}
              onFinish={(value: any) => {
                const names: string[] = [];
                const keys: string[] = [];
                value.forEach((record: any) => {
                  names.push(record.name.first);
                  keys.push(record.id);
                });
                SetforwardUser(names);
              }}
              value={forwardUser.join(',')}
            />
            <Button type="primary" size="small" style={{ height: '26px' }}>
              转发
            </Button>
          </Input.Group>
        </FormItem>
      </FormFiledSet>
    </div>
  );
};

export default FormTitelBlock;
