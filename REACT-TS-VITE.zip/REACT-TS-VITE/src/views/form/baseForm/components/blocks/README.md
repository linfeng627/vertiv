# 可复用的组件封装

---

## 封装我们第一个扩展板块

有这样一组表单字段，在多个表单中重复出现。我们可以将它封装为可复用板块。

进入`@/views/form/components/blocks`目录，创建`XxxBlock.tsx`新板块文件。

```sh
src
└── views
    └── form
        └── components
            └── blocks
                └── XxxBlock.tsx
                └── Xxx2Block.tsx
```

我们可以在 FormBlock 中插入任何表单元素。

### 与表单通用，我们创建一个空板块

- 它需要一个板块标题名`header: 'XXX板块'`，用于展示自己的与众不同。
- 需要一个唯一的板块样式名`const blockClassName = 'form-approval-comments-block';`，保证样式不会互相污染。
- 自定义板块内嵌`FormBlock`基础板块来使用，内置了等宽布局。
- cpProps 用于在板块内部赋固定值，这些值需要传递给`FormBlock`。

```tsx
//#region 导入
import { FC } from 'react';
import { useTranslation } from 'react-i18next';

import FormBlock, { FormPanelProps } from './FormBlock';
//#endregion

/**
 * Xxx板块
 * @param props 表单板块属性
 * @returns 返回板块组件
 */
const XxxBlock: FC<FormPanelProps> = (props) => {
  // 板块标题
  const blockTitle = 'XXX板块';
  // 板块样式名
  const blockClassName = 'form-xxx-block';

  // 定义此板块默认设置
  const cpProps: FormPanelProps = {
    ...props,
    header: blockTitle, // 板块标题名
    className: (props.className ?? '') + ' ' + blockClassName,
  };

  return (
    <FormBlock {...cpProps}>
      {/* 如使用插槽，可以插入 {cpProps.children} */}
    </FormBlock>
  );
};
export default XxxBlock;
```

使用板块

```tsx
<XxxBlock>...</XxxBlock>
```

### 修改表单板块中字段列数

板块默认一行显示两列。我们如何让板块每行显示 1 列？
配置`cols`属性：值为列数，1~4 之间，可选，默认为 2。

```tsx
...
const cpProps: FormPanelProps = {
  ...
  cols: 1, //一行一列
};
...
```

注：这列占满整行。多列时等分显示

### 板块不可折叠

配置`collapsible`属性：默认`header`，不可折叠`disabled`，可选。

```tsx
...
const cpProps: FormPanelProps = {
  ...
  collapsible: 'disabled', //设置不可折叠
};
...
```

---

## 自定义板块追加属性

需继承`FormPanelProps`扩展组件属性接口

```tsx
...
/** 组件属性 */
interface Props extends FormPanelProps {
  /** 最大文本长度 */
  maxLength?: number;
}

...
const XxxBlock: FC<Props> = (props) => {
  ...
  // props.maxLength
  ...
};
...
```

使用板块

```tsx
<XxxBlock maxLength={3}>...</XxxBlock>
```

---

[返回表单开发](/src/views/form/README.md)
