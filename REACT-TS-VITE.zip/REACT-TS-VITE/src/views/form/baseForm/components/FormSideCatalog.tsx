//#region 导入
import { Anchor } from 'antd';
import { Children, FC, isValidElement, ReactNode } from 'react';
// import { useTranslation } from 'react-i18next';
import './FormSideCatalog.less';
const { Link } = Anchor;
//#endregion

// /** 锚点类型 */
// interface anchorType {
//   /** 锚点 */
//   id: string;
//   /** 锚点标题 */
//   title: string;
// }

/** 组件属性 */
interface Props {
  /** 传入所有表单板块（方案一） */
  anchorList: ReactNode;
  /** 传入所有需要显示的锚点数组（方案二） */
  // anchorList: anchorType[];
}

/**
 * 表单快捷目录
 *
 * FormBlock里没有key，不显示
 * @param param0 组件属性
 * @returns 返回表单快捷目录
 */
const FormSideCatalog: FC<Props> = ({ anchorList }) => {
  // const { t } = useTranslation();
  const handleClick = (
    e: React.MouseEvent<HTMLElement>,
    // link: {
    //   title: React.ReactNode;
    //   href: string;
    // },
  ) => {
    // 阻止浏览器默认事件，点击锚点不记录历史
    e.preventDefault();
    // console.log(link);
  };

  return (
    <div className="nbl-affix form-Side-catalog">
      <Anchor
        affix={false}
        onClick={handleClick}
        className="form-Side"
        offsetTop={60}
      >
        {Children.map(anchorList, (anchor: any) => {
          if (!anchor || !isValidElement(anchor)) {
            return null;
          }
          const p = anchor.props! as any;

          //FormBlock
          return anchor.key && p.header ? (
            <Link href={`#${anchor.key}`} title={p.header}></Link>
          ) : null;
        })}
      </Anchor>
    </div>
  );
};
export default FormSideCatalog;
