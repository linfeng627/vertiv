//#region 导入
import {
  Children,
  cloneElement,
  FC,
  isValidElement,
  PropsWithChildren,
  ReactNode,
  useEffect,
} from 'react';
// import { useTranslation } from 'react-i18next';
import { Collapse, Form } from 'antd';
import FormSideCatalog from './FormSideCatalog';
import { useFormData } from '../services/formService';
import { useFormContext } from '../stores/formContext';
import { ItemStatusFN, Rule, ValidateMessages } from '../stores/formStore';
//#endregion

/**
 * 获取子组件集（批量配置板块固定属性）
 * @param children 子组件集
 * @param keys 返回的子组件key
 * @returns 返回新子组件集
 */
function getChildren(children: ReactNode, keys: string[]) {
  //, headers: string[]
  const newChildren: ReactNode[] = [];
  Children.forEach(children, (child: any) => {
    if (!child || !isValidElement(child)) {
      return null;
    }

    const key: string = (child.key ?? Math.random()).toString();
    // 获取关键字列表
    keys.push(key);

    // 批量设置固定值
    const props = {
      // 传入ID用于快捷目录组件（FormSideCatalog）寻找板块锚点
      id: key,
      key: key,
    };
    newChildren.push(cloneElement(child, props));
  });

  return newChildren;
}

/** 组件属性 */
interface Props {
  baseUrl?: string;
  /** 板块集自定义样式 */
  className?: string;
  // /** 插槽 */
  // children: ReactNode; // PropsWithChildren<Props>
  /**
   * 表单项状态覆盖规则（由下至上覆盖）
   * 1. 全局规则：调用FormItemDisable方法
   * 2. 本表单项规则：实例化时配置属性statusFN
   * 3. 本表单项强制配置：实例化时配置属性disabled, hidden
   * 4. 输入框实例化时自行配置的属性
   */
  statusConfig?: ItemStatusFN;
  rules?: [
    {
      key: 'string';
      rules: Rule[];
    },
  ];
  validateMessages?: ValidateMessages;
}

/**
 * 表单板块集
 * - block/*
 * - 板块快捷导航FormSideCatalog
 * 
 * 初始化板块集中所有子板块属性
 * 1. 添加Collapse.Panel需要的`defaultActiveKey`
 * 2. 添加基础板块样式`form-block`
 * 3. 传入初始值`initialValues`。[待处理]数据响应式绑定问题

 * @param props 组件初始化属性
 * @returns
 */
const FormBlockSet: FC<PropsWithChildren<Props>> = (props) => {
  // 板块Key数组
  const keys: string[] = [];
  // const headers: string[] = [];

  /**
   * 修改所有block样式名
   * @param children 子容器
   * @returns 增加`form-block`样式名
   */
  const { formSet, formData } = useFormData();
  //通过上下文获取表单form对象
  const form = useFormContext();

  // const [FormDisabled, setFormDisabled] = useState<boolean>(true);

  // 将表单实例数据填充到表单中
  useEffect(() => {
    // 填充表单数据
    form.setFieldsValue(formData);
  }, [form, formData]);

  // 计算cloumn布局跨度
  // const labelColSpan = formSet?.labelColSpan ?? 5;
  // const fieldlayout = {
  //   labelCol: { span: labelColSpan },
  //   wrapperCol: { span: 24 - labelColSpan },
  // };

  const fieldlayout = {
    // labelCol: { flex: '120px' },
    wrapperCol: { flex: 1 },
  };

  /**
   * 启用快捷目录
   * @returns 是否启用
   */
  function enableFormSideCatalog(): boolean {
    return (
      // formSet.enableFormSideCatalog未配置，默认为启用
      (formSet.enableFormSideCatalog == undefined ||
        // formSet.enableFormSideCatalog为启用
        formSet.enableFormSideCatalog) as boolean
    );
  }

  return (
    <Form
      {...fieldlayout}
      form={form}
      name="basicForm"
      validateMessages={props.validateMessages}
      // onValuesChange={(changedValues: any, values: any) => {
      //   // 表单数据变更时触发
      // }}
    >
      <Collapse
        defaultActiveKey={keys}
        className={`form-data ${props.className}`}
        expandIconPosition="end"
      >
        {getChildren(props.children, keys)}
        {enableFormSideCatalog() ? (
          <FormSideCatalog anchorList={props.children}></FormSideCatalog>
        ) : null}
      </Collapse>
    </Form>
  );
};

export default FormBlockSet;
// </Form.Provider>
