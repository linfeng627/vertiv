//#region 导入
import { Children, FC, PropsWithChildren } from 'react';
// import { useTranslation } from 'react-i18next';

import { Divider, Row, Col } from 'antd';
import './FormFiledSet.less';
//#endregion

/** 组件属性 */
interface Props {
  /** 板块标题 */
  title?: string;
  /** 字段列列数，自动覆盖span.colSpan设置 */
  cols?: number;
  /** 插槽 */
  // children?: ReactNode;
  /** 样式名 */
  className?: string;
  /** 占一行 */
  fill?: boolean;
  /** 跨列 */
  crossCol?: number;
}

/**
 * 表单字段集，默认两列等分布局
 *
 * 一般用于对表单板块中字段分组显示。
 * @param params 组件属性
 * @returns 返回字段集
 */
const FormFiledSet: FC<PropsWithChildren<Props>> = ({
  title,
  cols,
  children,
  className,
}) => {
  // const { t } = useTranslation();

  //默认一行两列
  cols = cols ?? 2;
  const colLayout = {
    span: 24 / cols,
  };
  return (
    <div className={`form-field-set ${className ?? ''}`}>
      {title && title.length > 0 && (
        <Divider orientation="left" orientationMargin="0">
          {title}
        </Divider>
      )}
      <Row gutter={24}>
        {Children.map(children, (child: any) => {
          if (!child) {
            return null;
          }

          // FormItem强制定义了跨列，则按FormItem为准
          let span = colLayout.span;

          // 因子组件类型不可预知。如报错，则放弃跨列。
          try {
            if (child.props.fill) {
              span = 24;
            } else if (child.props.crossCol != undefined) {
              span = span * child.props.crossCol;
            }
          } catch {
            console.log('此组件不适用跨列');
          }
          return <Col span={span}>{child}</Col>;
        })}
      </Row>
    </div>
  );
};
export default FormFiledSet;
