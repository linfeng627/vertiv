//#region Row
import { FC } from 'react';
import { Form } from 'antd';
import { EditableContext } from './FormEditorTable';

/** 表格行属性 */
// interface EditableRowProps {
//   index: number;
// }

/**
 * 自定义可编辑表格行组件
 * @param props 行属性
 * @returns 返回表格行组件
 */
const EditableRow: FC = ({ ...props }) => {
  const [editorForm] = Form.useForm();

  return (
    <Form form={editorForm} component={false} name="basicFormEditorTable">
      <EditableContext.Provider value={editorForm}>
        <tr {...props} />
      </EditableContext.Provider>
    </Form>
  );
};
export default EditableRow;
//#endregion
