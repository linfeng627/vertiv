//#region 导入
import { createContext, FC, useEffect, useState } from 'react';

import { Button, FormInstance, Popconfirm, TableProps } from 'antd';
import FormTable, { FormTableProps } from './FormTable';
import EditableCell from './TableCell';
import EditableRow from './TableRow';

import { JsonStore } from '@/utils';
import './FormEditorTable.less';
//#endregion

/**
 * 可编辑表格需求列表：
 * 1. 列配置传入。
 * 2. 列配置中添加editor属性，类型ReactNode。切换逻辑封装到此组件内。
 * 3. 增加添加按钮
 */

/** 编辑单元格上下文 */
export const EditableContext = createContext<FormInstance<any> | null>(null);

//#region Table
/** 添加事件 */
export interface TableBeforeAddEvent<T> {
  /** 新行默认值 */
  record: T; // | T[];
  /** 所有记录 */
  records: T[];
}
/** 添加句柄 */
export type TableBeforeAddHandle<T> = (
  event: TableBeforeAddEvent<T>,
) => false | T;

/** 从antd的table结构解构出colmns类型 */
type TableColumnsType<T> = Exclude<TableProps<T>['columns'], undefined>;
// 在原有类型中追加新属性
type TableColumnsExType<T> = (TableColumnsType<T>[number] & {
  editable?: boolean;
  dataIndex: string;
})[];
type TableRowSelectionType<T> = Exclude<
  TableProps<T>['rowSelection'],
  undefined
>;
/**
 * 列配置类型
 * @returns
 * - rowSelection 行选择列
 * - columns 通用列、操作列
 */
type ColumnsConfig<T> = (columns: TableColumnsType<T>) => {
  /** 行选择列 */
  rowSelection?: TableRowSelectionType<T>;
  /** 通用列、操作列 */
  columns: TableColumnsType<T>;
};

/** 新增记录配置 */
interface recordCreatorProps<T> {
  position?: 'top' | 'bottom';
  record?: () => T; // | T[];
}

/** 删除记录配置 */
type recordDeleteProps<T> = (record: T, records: T[]) => T[];

/** 组件属性 */
export interface FormEditorTableProps<T = JsonStore> extends FormTableProps<T> {
  // 其它配置-------------------
  className?: string;
  // 表格属性配置-------------------
  /** 唯一键 */
  // indexKey: string;
  /** 表格列配置 */
  columns: TableColumnsType<T>;
  /** 是否启用添加 */
  enableAdd?: boolean | recordCreatorProps<T>;
  /** 是否启用编辑 */
  editable?: boolean;
  /** 是否启用删除 */
  enableDelete?: boolean | recordDeleteProps<T>;
  disabled?: boolean;
  hidden?: boolean;
  // 表格事件配置-------------------
  /**
   * 添加记录前事件，定义新增记录数据后返回
   * @param newRecord 新增记录
   * @param records 所有记录
   * @return
   * - 当返回return false时，中断添加操作
   * - 当返回具体数据，则覆盖默认添加数据
   */
  onBeforeAdd?: TableBeforeAddHandle<T>;
  /**
   * 添加记录
   * @param records 所有记录
   */
  onAdd?: (event: { records: T[] }) => void;
  onBeforeDelete?: (event: { record: T; records: T[] }) => false | void;
}

/**
 * 可编辑表格
 * @param props 组件属性（默认数据value类型为JsonStore，可通过泛型传入）
 * @returns 返回本组件
 */
const FormEditorTable = <T extends object>(props: FormEditorTableProps<T>) => {
  //获取泛型定义的数据类型
  /** 记录类型 */
  type recordType = T;
  /** 记录集类型 */
  type recordsType = T[];

  // 多语言
  //   const { t } = useTranslation();

  // 表格数据状态
  const [dataSource, setDataSource] = useState<recordsType>(props.value || []);

  // 更新初始化数据
  useEffect(() => {
    const data = props.value || [];
    setDataSource(data);
  }, [props.value]);

  //#region 事件逻辑
  // 添加行逻辑
  const handleAdd = () => {
    try {
      console.group('可编辑表格-添加新行');
      let newRecords: recordsType = [];
      // 判断是否有onBeforeAdd
      if (props.onBeforeAdd) {
        // 调用onBeforeAdd事件，获取自定义新行数据
        const record = props.onBeforeAdd({
          record: addConfig.record ? addConfig.record() : ({} as recordType),
          records: dataSource,
        });
        // 将返回数据插入新行
        if (record !== false) {
          newRecords = [...dataSource, record];
        } else {
          // onBeforeAdd返回false中断添加记录操作
          return;
        }
      } else {
        // 没有绑定onBeforeAdd事件，直接插入空行
        newRecords = [...dataSource, {} as recordType];
      }
      // 保存修改结果
      saveData(newRecords);
      // 添加新行完成后，调用onAdd
      if (props.onAdd) {
        props.onAdd({ records: newRecords });
      }
    } finally {
      console.groupEnd();
    }
  };

  // 删除行逻辑
  const handleDelete = (record: recordType) => {
    try {
      console.group('可编辑表格-删除新行');
      if (
        props.onBeforeDelete &&
        props.onBeforeDelete({
          record: record,
          records: dataSource,
        }) === false
      ) {
        // onBeforeDelete返回false中断添加记录操作
        return;
      }

      //删除记录
      const newRecords = dataSource.filter((item) => item != record);

      // 保存修改结果
      saveData(newRecords);
    } finally {
      console.groupEnd();
    }
  };

  /**
   * 修改单元格数据数据
   * @param record 更新后记录
   * @param oldRecord 原记录
   */
  const handleCellSave = (record: recordType, oldRecord: recordType) => {
    try {
      console.group('可编辑表格-修改单元格值');
      const newData = [...dataSource];
      const index = newData.findIndex((item) => {
        if (item == oldRecord) {
          return true;
        }
      });
      const item = newData[index];
      newData.splice(index, 1, {
        ...item,
        ...record,
      });
      saveData(newData);
    } finally {
      console.groupEnd();
    }
  };
  //#endregion

  // 保存数据修改
  const saveData = (records: recordsType) => {
    console.log('可编辑表格-数据被修改');

    setDataSource(records);
    if (props.onChange) {
      props.onChange(records);
    }
  };

  //初始化配置
  function InitConfig() {
    if (props.enableAdd == undefined || props.enableAdd === true) {
      addConfig = {
        position: 'top',
      };
    } else if (props.enableAdd !== false) {
      addConfig = props.enableAdd;
    }
  }

  /**
   * 根据配置生成添加记录按钮
   * @param position 按钮生成位置 'top' | 'bottom'
   * @returns 根据配置生成按钮
   */
  const AddButton: FC<{ position: 'top' | 'bottom' }> = ({ position }) => {
    if (props.disabled) {
      return null;
    }
    return props.enableAdd !== false && addConfig.position == position ? (
      <Button
        onClick={() => handleAdd()}
        type="primary"
        style={{ marginBottom: 16 }}
      >
        添加
      </Button>
    ) : null;
  };

  // 添加按钮配置
  let addConfig: recordCreatorProps<recordType>;
  InitConfig();

  /**
   * 获取列配置
   * @param columns 默认列配置
   * @returns 自定义列配置，包含行选择列
   */
  const colConfig: ColumnsConfig<recordType> = (columns) => {
    const operation: TableColumnsExType<recordType> = [];
    if (!props.disabled && props.enableDelete !== false) {
      operation[0] = {
        title: '操作',
        dataIndex: 'operation',
        width: 80,
        // 渲染删除按钮
        render: (_, record, _index) =>
          dataSource.length >= 1 ? (
            <Popconfirm
              title="确定删除?"
              onConfirm={() => handleDelete(record)}
            >
              <a>删除</a>
            </Popconfirm>
          ) : null,
      };
    }
    const newColumns: TableColumnsExType<recordType> = [
      ...(columns as TableColumnsExType<recordType>),
      // 配置操作按钮列
      ...operation,
    ];

    return {
      // 设置行选择列
      rowSelection: {
        type: 'checkbox',
        onChange: (selectedRowKeys: React.Key[], selectedRows: recordsType) => {
          console.log(
            `selectedRowKeys: ${selectedRowKeys}`,
            'selectedRows: ',
            selectedRows,
          );
        },
      },
      // 扩展columns自定义属性
      columns: newColumns.map((col) => {
        if (
          props.disabled ||
          props.editable === false ||
          col.editable !== true
        ) {
          return col;
        }
        return {
          ...col,
          onCell: (record: recordType) => ({
            record,
            editable: col.editable,
            dataIndex: col.dataIndex,
            title: col.title,
            handleCellSave,
          }),
        };
      }) as TableColumnsType<recordType>,
    };
  };

  // 重构表格主体
  const components = {
    body: {
      row: EditableRow,
      cell: EditableCell<recordType>,
    },
  };

  return (
    <div className={`nbl-editor-table ${props.className ?? ''}`}>
      <AddButton position="top" />
      <FormTable<recordType>
        {...(colConfig(props.columns) as FormTableProps<recordType>)}
        components={props.disabled ? undefined : components}
        dataSource={dataSource}
        rowClassName={(_, index) => `editable-row editable-row-${index}`}
        pagination={props.pagination ?? false}
      />
      <AddButton position="bottom" />
    </div>
  );
};
export default FormEditorTable;
//#endregion
