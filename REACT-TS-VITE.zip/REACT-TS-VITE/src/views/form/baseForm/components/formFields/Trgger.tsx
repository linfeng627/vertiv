//#region 导入
import { FC, useRef } from 'react';
import { SettingOutlined } from '@ant-design/icons';
import { Input, InputProps, InputRef } from 'antd';
import React from 'react';
// import { useTranslation } from 'react-i18next';
//#endregion

/** 组件属性 */
export interface TiggerProps
  extends Omit<InputProps, 'addonAfter' | 'onClick'> {
  /** 触发事件 */
  // onTigger: () => void;
  onTigger: (input: InputRef | null) => void;
  /** 自定义触发按钮icon */
  icon?: React.ComponentType<any>;
}
/**
 * 触发器输入框
 * @param props 组件属性
 * @returns 返回本组件
 */
const Tigger: FC<TiggerProps> = ({ onTigger, ...props }) => {
  // 多语言
  //   const { t } = useTranslation();

  // 输入框对象
  const inputRef = useRef<InputRef>(null);

  // 点击后触发
  const handleClick = () => {
    if (!props.disabled) {
      onTigger(inputRef.current);
    }
  };
  const Icon = props.icon ? props.icon : SettingOutlined;
  return (
    <Input
      ref={inputRef}
      onFocus={(e) => {
        e.target.blur();
      }}
      {...props}
      className={`nbl-tigger ${props.className ?? ''}`}
      //   ref={ref as React.Ref<HTMLInputElement>}
      addonAfter={
        // 禁用时不显示触发按钮
        props.disabled !== true ? (
          <Icon disabled={props.disabled} onClick={handleClick} />
        ) : null
      }
      onClick={handleClick}
      allowClear
    />
  );
};
export default Tigger;
