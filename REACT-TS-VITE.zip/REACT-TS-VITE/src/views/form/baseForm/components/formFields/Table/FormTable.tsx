//#region 导入
import { useEffect, useState } from 'react';
import { Table, TableProps } from 'antd';
import { JsonStore } from '@/utils';
import { FormItemBaseProps } from '@/stores';
//#endregion

/** 从antd的table结构出colmns类型 */
// type TableColumnsType<T> = Exclude<TableProps<T>['columns'], undefined>;
type TablePropsTypes<T> = Omit<TableProps<T>, 'onChange'>;

// type TablePropsTypesRE<T> = Required<TablePropsTypes<T>>;

/** 组件属性 */
export interface FormTableProps<T = JsonStore>
  extends FormItemBaseProps<T[]>,
    TablePropsTypes<T> {}

/**
 * 表单表格组件(只读)
 * @param props 组件属性
 * @returns 返回表格
 */
const FormTable = <T extends object>(props: FormTableProps<T>) => {
  //获取泛型定义的数据类型
  /** 记录类型 */
  type recordType = T;
  /** 记录集类型 */
  type recordsType = T[];

  const [dataSource, setDataSource] = useState<recordsType>(props.value || []);

  // 更新初始化数据
  useEffect(() => {
    const data = props.value || [];
    setDataSource(data);
  }, [props.value]);

  return (
    <Table<recordType>
      {...(props as TableProps<recordType>)}
      dataSource={props.dataSource ?? dataSource}
      pagination={props.pagination ?? false}
    />
  );
};

export default FormTable;

// import Table from './Table';
// import EditorTable from './EditorTable';

// // 内联子组件类型约束
// type InternalTable = typeof Table;
// interface TableInterface extends InternalTable {
//   /** 可编辑表格 */
//   EditorTable: typeof EditorTable;
// }

// // 配置内联子组件
// /** 表单表格 */
// const FormTable = Table as TableInterface;
// FormTable.EditorTable = EditorTable;

// export default FormTable;
