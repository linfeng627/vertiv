//#region Cell
import {
  KeyboardEventHandler,
  PropsWithChildren,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import { Form, Input, InputRef } from 'antd';
import { EditableContext } from './FormEditorTable';

/** 表格列属性 */
interface EditableCellProps<T> {
  title: React.ReactNode;
  /** 是否启用编辑 */
  editable: boolean;
  dataIndex: keyof T;
  record: T;
  /** 单元格存行编辑 */
  handleCellSave: (record: T, oldRecord: T) => void;
}

/**
 * 自定义可编辑表格列组件
 * @param props 列属性
 * @returns 返回表格列组件
 */
const EditableCell = <T extends object>({
  title,
  editable,
  children,
  dataIndex,
  record,
  handleCellSave,
  ...restProps
}: PropsWithChildren<EditableCellProps<T>>) => {
  // 编辑状态
  const [editing, setEditing] = useState(false);
  // 编辑框引用
  const inputRef = useRef<InputRef>(null);
  // 编辑框上下文
  const editorForm = useContext(EditableContext)!;

  //进入编辑状态，编辑框获取焦点
  useEffect(() => {
    if (editing) {
      inputRef.current!.focus();
    }
  }, [editing]);

  // 切换编辑状态，保存修改值
  const toggleEdit = () => {
    setEditing(!editing);
    editorForm.setFieldsValue({ [dataIndex]: record[dataIndex] });
  };
  // 保存数据变更（按回车后、或则编辑框失去焦点）
  const save = async () => {
    try {
      // 获取修改后的值
      const values = await editorForm.validateFields();

      toggleEdit();
      // 将表格中修改过的新值覆盖旧值
      handleCellSave({ ...record, ...values }, record);
    } catch (errInfo) {
      console.log('保存失败:', errInfo);
    }
  };
  // 放弃变更数据（按Esc后）
  const escape: KeyboardEventHandler<HTMLInputElement> = async (event) => {
    try {
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        toggleEdit();
      }
    } catch (errInfo) {
      console.log('保存失败:', errInfo);
    }
  };
  let childNode = children;

  /**
   * - 编辑状态，显示编辑输入框，监听onPressEnter和onBlur事件，完成编辑
   * - 非编辑状态监听onClick事件，切换监听状态
   */
  if (editable) {
    childNode = editing ? (
      <Form.Item
        className={`editable-cell editable-cell-${dataIndex.toString()}`}
        style={{ margin: 0 }}
        name={dataIndex.toString()}
        rules={[
          {
            required: true,
            message: `${title}必填。`,
          },
        ]}
      >
        <Input
          ref={inputRef}
          onPressEnter={save}
          onBlur={save}
          onKeyUp={escape}
        />
      </Form.Item>
    ) : (
      <div
        className={`editable-cell-value-wrap editable-cell-${dataIndex.toString()}`}
        style={{ paddingRight: 24 }}
        onClick={toggleEdit}
      >
        {children}
      </div>
    );
  }

  return <td {...restProps}>{childNode}</td>;
};
export default EditableCell;
//#endregion
