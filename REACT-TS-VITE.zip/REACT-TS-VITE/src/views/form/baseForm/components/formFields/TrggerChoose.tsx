//#region 导入
import ChoosePopup from '@/components/choose/ChoosePopup';
import { useChooseModal } from '@/services/chooseModal';
import { InputRef } from 'antd';
import { FC } from 'react';
import Tigger, { TiggerProps } from './Trgger';
// import { useTranslation } from 'react-i18next';
//#endregion

/** 组件属性 */
export interface TiggerChooseProps extends Omit<TiggerProps, 'onTigger'> {
  /** 赋初值 */
  onTigger?: (input: InputRef | null, open: (value?: any) => void) => void;
  /** 获取返回值 */
  onFinish: (value: any) => void;
  /** 是否多选 */
  multiple?: boolean;
  /** 弹窗组件 */
  modal?: any;
  /** 弹窗属性 */
  config?: Record<string, any>;
}

/**
 * 通用弹窗组件触发器
 * @param props 组件属性
 * @returns 返回本组件
 */
const TiggerChoose: FC<TiggerChooseProps> = ({
  onFinish,
  multiple,
  modal = ChoosePopup,
  config,
  // onOk,
  // onCancel,
  ...props
}) => {
  // 多语言
  //   const { t } = useTranslation();

  const handleClick = (input: InputRef | null) => {
    if (props.onTigger) {
      props.onTigger(input, open);
    } else {
      open();
    }
  };
  const [open, ChooseModal] = useChooseModal(modal);
  return (
    <>
      <ChooseModal
        {...config}
        multiple={multiple ?? false}
        onFinish={onFinish}
      />
      <Tigger {...props} onTigger={handleClick} />
    </>
  );
};
export default TiggerChoose;
