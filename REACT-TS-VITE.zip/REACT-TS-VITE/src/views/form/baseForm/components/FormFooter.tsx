import { Layout } from 'antd';
import { FC, PropsWithChildren } from 'react';
// import { useFormData } from '../services/formService';
// import { useTranslation } from 'react-i18next';

// interface Props {
//   /** 插槽 */
//   children?: ReactNode;
// }

/**
 * 表单头（可以插入操作按钮）
 * @param params
 * @returns
 */
const FormFooter: FC<PropsWithChildren> = ({ children }) => {
  // const { t } = useTranslation();
  // const { formSet } = useFormData();

  return (
    <Layout.Footer className="nbl-main-footer form-footer">
      {/* 居中表尾部 */}
      <div className="form-footer-container">{children}</div>
    </Layout.Footer>
  );
};
export default FormFooter;
