import { Layout } from 'antd';
import { FC, PropsWithChildren, ReactNode } from 'react';
import { useFormData } from '../services/formService';
// import { useTranslation } from 'react-i18next';

// interface Props {
//   /** 插槽 */
//   children?: ReactNode;
// }

/**
 * 表单头（可以插入操作按钮）
 * @param params
 * @returns
 */
const FormHeader: FC<PropsWithChildren> = ({ children }) => {
  // const { t } = useTranslation();
  const { formSet } = useFormData();

  return (
    <Layout.Header className="nbl-main-header form-header">
      {/* 居中表头 */}
      <div className="form-header-container">
        <a href="form" className="nbl-logo">
          <img src="/logo.png" className="logo" alt="NBL logo" />
          <h1>{formSet.header}</h1>
        </a>
        {children}
      </div>
    </Layout.Header>
  );
};
export default FormHeader;
