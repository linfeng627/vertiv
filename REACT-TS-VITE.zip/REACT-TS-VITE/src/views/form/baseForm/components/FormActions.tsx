//#region 导入
import { FC } from 'react';
// import { useTranslation } from 'react-i18next';

import { Button, Dropdown, Menu, MenuProps, Space } from 'antd';
import { styleStr2Json } from '@/utils';
import { MenuItem, SlotPosition } from '@/stores';
import { useFormData } from '../services/formService';
import './FormActions.less';
//#endregion

//#region 类型声明
/** 操作类型声明 */
export interface FormActionType {
  /** 操作显示名 */
  text: string;
  /** 操作标识 */
  action: string;
  /** 操作描述 */
  description?: string;
  /** 自定义样式名 */
  className?: string;
  /** 自定义样式 */
  style?: string;
  // type?: ButtonType;
  /** 折叠按钮 */
  collapsed?: boolean;
}

/**
 * 操作列表定位声明
 * - `'top'` 顶部
 * - `'bottom'` 底部
 */

export type ActionsPosition = SlotPosition;

/** 操作事件 */
export interface ActionEvent {
  /** 操作标识 */
  key: string;
  /** 操作目标 */
  currentTarget: EventTarget;
}

/** 操作事件句柄 */
export type ActionEventHandle = (e: ActionEvent) => void | boolean;
//#endregion

interface Props {
  /**
   * 执行操作事件
   * 参数e包含可以解构出key和currentTarget
   * @example
   * const handleActionClick = (e: ActionEvent) => {
   *   console.log(`key: ${e.key}`);
   * };
   */
  onAction?: ActionEventHandle;
  /** 样式名 */
  className?: string;
}

/**
 * 表单操作按钮集组件
 * @returns 返回所有可操作按钮
 */
const FormActions: FC<Props> = ({ onAction, className }) => {
  // const { t } = useTranslation();

  // 获取读取表单配置信息
  const { formSet } = useFormData();

  /**
   * 执行操作
   * @param e 事件对象
   */
  const actionEventHandle = (e: ActionEvent) => {
    if (onAction) {
      onAction(e);
    }
  };

  // 主要操作按钮事件
  const handleActionClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    const button = e.currentTarget;
    actionEventHandle({
      key: button.name,
      currentTarget: button,
    });
  };
  // 更多操作按钮事件
  const handleMoreActionsClick: MenuProps['onClick'] = (e) => {
    // 抛出事件
    actionEventHandle({
      key: e.key,
      currentTarget: e.domEvent.currentTarget,
    });
  };
  // 加载更多操作菜单（显示所有collapsed=true的按钮）
  const moreBtns = (): JSX.Element => {
    return (
      <Menu
        onClick={handleMoreActionsClick}
        items={formSet.actions?.map<MenuItem>((action) => {
          if (action.collapsed) {
            return {
              label: action.text,
              key: action.action,
            } as MenuItem;
          }
          return null;
        })}
      />
    );
  };

  return (
    <div className={`form-actions ${className ?? ''}`}>
      {/* 加载操作按钮（显示所有collapsed != true的按钮） */}
      {formSet.actions?.map((action) => {
        if (!action.collapsed) {
          return (
            <Button
              key={action.action}
              className={`action-${action.action} ${action.className ?? ''}`}
              style={action.style ? styleStr2Json(action.style) : undefined}
              onClick={handleActionClick}
              name={action.action}
            >
              {action.text}
            </Button>
          );
        }
      })}
      {/* 加载更多操作菜单（显示所有collapsed = true的按钮） */}
      <Dropdown overlay={moreBtns} overlayClassName="form-actions-more-overlay">
        <Button>
          <Space>更多操作...</Space>
        </Button>
      </Dropdown>
    </div>
  );
};
export default FormActions;
