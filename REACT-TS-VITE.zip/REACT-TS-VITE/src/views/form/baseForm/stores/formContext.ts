import { createContext, useContext } from 'react';
import { Form, FormInstance } from 'antd';
import { FormDataType } from './formStore';

/**
 * 创建表单内容主体上下文
 */
export const FormBodyContext = createContext<FormInstance<FormDataType> | null>(
  null,
);

/**
 * 获取表单内容主体上下文
 * @returns 返回表单上下文
 */
export function useFormContext() {
  return useContext(FormBodyContext) as FormInstance<FormDataType>;
}

/**
 * 获取表单内容主体实例对象
 * @returns 返回表单实例对象
 */
export function useFormBody() {
  return Form.useForm<FormDataType>();
}
