import { NamePath } from '@/stores';
import { FormItemProps, FormProps } from 'antd';
import { ActionsPosition, FormActionType } from '../components/FormActions';

/** 所有表单相关ID */
export interface FormIds {
  formId?: string;
  sn?: string;
  destInstId?: string;
  procInstId?: string;
}

/**
 * 表单视图状态约束
 * - `'launch'` 发起视图
 * - `'approval'` 审批视图
 * - `'view'` 查看视图
 * - `'print'` 打印视图
 * - `任意字符串` 自定义视图
 */
export type FormViewStatus = 'launch' | 'approval' | 'view' | 'print' | string;

/**
 * 表单项状态
 */
export interface ItemStatus {
  /** 是否禁用 */
  disabled?: boolean;
  /** 是否显示 */
  hidden?: boolean;
}
/**
 * 获取表单项是否禁用
 * @return
 * - `disabled` 禁用
 * - `hidden` 隐藏
 */
export type FormItemStatusFN = (
  /** 当前表单状态 */
  status: CurrViewStatus,
  /** 自定义表单项状态 */
  fn?: ItemStatusFN,
) => ItemStatus;

/** 表单项规则 */
export type Rule = Exclude<FormItemProps['rules'], undefined>[number];
/** 验证 */
export type ValidateMessages = Exclude<
  FormProps['validateMessages'],
  undefined
>;

/**
 * 计算表单项状态
 */
export type ItemStatusFN = (
  /** 当前表单状态 */
  status: CurrViewStatus,
  /** 表单项状态 */
  itemStatus: ItemStatus,
  /** 数据项路径 */
  name?: NamePath,
) => ItemStatus;

/** 当前视图状态 */
export interface CurrViewStatus {
  /**
   * 表单视图状态约束
   * - `'launch'` 发起视图
   * - `'approval'` 审批视图
   * - `'view'` 查看视图
   * - `'print'` 打印视图
   * - `任意字符串` 自定义视图
   */
  formViewStatus: FormViewStatus;
  /** 当前处理环节 */
  currentStage?: string;
}
export interface ApprovalCommentConfig {
  comment: string;
}
/** 表单配置定义 */
export interface FormSetConfig extends CurrViewStatus {
  /** 表单定义号 */
  formId?: string;
  /** 任务号 */
  sn?: string;
  /** 任务实例号 */
  destInstId?: string;
  /** 流程实例号 */
  procInstId?: string;

  /** 视图状态 继承自 CurrViewStatus */

  /** 表单标题 */
  header: string;
  /** 操作列表定位 */
  actionPosition?: ActionsPosition;
  /** 表单操作行为列表 */
  actions?: FormActionType[];
  /** 表单组件树结构 */
  formCompTree?: FormCompTree;
  /**
   * @deprecated 将于下个版本被弃用。单字段标签跨度，建议使用表单样式定义。
   */
  labelColSpan?: number;
  /** 启用流转记录 */
  enableProcInstLogs?: boolean;
  /** 启用快捷目录 */
  enableFormSideCatalog?: boolean;
}

/** 表单组件树结构 */
export type FormCompTree = Record<string, any>; //json结构数据，后期可收束类型

/**
 * 表单实例数据定义
 *
 * 临时存放了审批意见，提交时会自动清除
 * @example
 * {
 *   approvalComment: {
 *     comment: string
 *     ...
 *   }
 * }
 */
export type FormDataType = any; //json结构数据，临时存放审批意见

/** 完整表单信息 */
export interface FormInfo<T = FormDataType> {
  /** 表单配置定义 */
  formSet: FormSetConfig;
  /** 表单实例数据定义 */
  formData: T;
}

/**
 * - `'data':` T default FormInfo
 * - `'code':` http status code
 * - `'message':` response message
 */
export interface ApiResponseModel<T = FormInfo> {
  data: T;
  code: number;
  message: string;
}
