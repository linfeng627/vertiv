//#region 导入
import { FC, useState } from 'react';
// import { useTranslation } from 'react-i18next';

import {
  Button,
  DatePicker,
  Input,
  InputNumber,
  Layout,
  Modal,
  Radio,
  Table,
} from 'antd';

import FormBlock from '@/views/form/baseForm/components/blocks/FormBlock';
import FormBlockSet from '@/views/form/baseForm/components/FormBlockSet';
import FormFiledSet from '@/views/form/baseForm/components/FormFiledSet';
import FormItem from '@/views/form/baseForm/components/FormItem';
// import { useFormData } from '@/views/form/baseForm/services/formService';

import ApplicationInformationBlock from '@/views/form/components/blocks/ApplicationInformationBlock';
import XApprovalCommentsBlock from '@/views/form/components/blocks/XApprovalCommentsBlock';

// import ChargeDetailsBlock from '../components/blocks/ChargeDetailsBlock';

import Tigger from '@/views/form/baseForm/components/formFields/Trgger';
import ChoosePeople from '@/components/choose/ChoosePeople';
import ChooseDept from '@/components/choose/ChooseDept';

import { useFormContext } from '@/views/form/baseForm/stores/formContext';
import { DeptDataNode } from '@/stores/dept';

import styles from './TandEView.module.less';
import ApprovalHistoryBlock from '../components/blocks/ApprovalHistoryBlock';
import { useFormData } from '../baseForm/services/formService';
import { useChooseModal } from '@/services/chooseModal';
// import ChoosePosition from '@/components/choose/ChoosePosition';
import ChargeDetailsBlock from '../components/blocks/ChargeDetailsBlock';
import TiggerChoose from '../baseForm/components/formFields/TrggerChoose';
//#endregion

/**
 * tANde
 * @returns 返回表单
 */
const TandEView: FC = () => {
  // 多语言
  // const { t } = useTranslation();

  // 表单配置与数据
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { formSet, formData } = useFormData();

  // 通过上下文获取表单form对象
  const form = useFormContext();

  // 创建弹窗容器
  const [open, ChoosePopup] = useChooseModal();
  // 人员选择
  const handlePeopleFinish = (value: any) => {
    const names: string[] = [];
    const keys: string[] = [];
    value.forEach((record: any) => {
      names.push(record.name.first);
      keys.push(record.id);
    });
    form.setFieldValue('rrxzk', names.join(', '));
    form.setFieldValue('rrxzkUserId', keys.join(', '));
    form.validateFields(['rrxzk']);
  };
  //部门选择
  const handleDeptFinish = (value: any) => {
    const names: string[] = [];
    const keys: string[] = [];

    value.forEach((record: any) => {
      names.push(record.title);
      keys.push(record.key);
    });
    // 多选部门名
    form.setFieldValue('bmxzk', names.join(', '));
    // 多选部门ID
    form.setFieldValue('bmxzkDeptId', keys.join(', '));
    form.validateFields(['bmxzk']);
  };
  const handleDeptTigger = (inputRef: any, open: any) => {
    // 拼装已选部门数据结构
    const depts: DeptDataNode[] = [];

    if (inputRef?.input?.value) {
      const names = ((form.getFieldValue('bmxzk') ?? '') as string).split(', ');
      const keys = ((form.getFieldValue('bmxzkDeptId') ?? '') as string).split(
        ', ',
      );
      names.forEach((name, i) => {
        depts.push({
          title: name,
          key: keys[i],
        });
      });
    }

    //打开回显数据
    open(depts);
  };

  const [topen, setTopen] = useState(false);

  return (
    <FormBlockSet className={styles['demo-form']}>
      <FormBlock header="测试" cols={1} key={'testBlock'}>
        <Modal
          centered
          open={topen}
          width={600}
          title={'tttt'}
          onOk={() => setTopen(false)}
          onCancel={() => setTopen(false)}
        >
          <Layout style={{ background: 'transparent' }}>
            <Layout.Sider width={200}>344</Layout.Sider>
            <Layout.Content>
              <Table
                scroll={{ y: '180px' }}
                columns={[
                  {
                    title: '姓名',
                    dataIndex: 'name',
                    key: 'name',
                    width: '30%',
                  },
                  {
                    title: '金额',
                    dataIndex: 'amount',
                    key: 'amount',
                  },
                  {
                    title: '描述',
                    dataIndex: 'desc',
                    key: 'desc',
                    width: '30%',
                  },
                ]}
                dataSource={[
                  { key: '1', name: 'afdafadf', amount: 0, desc: 'adaf' },
                  { key: '21', name: 'afdafadf', amount: 0, desc: 'adaf' },
                  { key: '31', name: 'afdafadf', amount: 0, desc: 'adaf' },
                  { key: '41', name: 'afdafadf', amount: 0, desc: 'adaf' },
                  { key: '51', name: 'afdafadf', amount: 0, desc: 'adaf' },
                  { key: '61', name: 'afdafadf', amount: 0, desc: 'adaf' },
                  { key: '71', name: 'afdafadf', amount: 0, desc: 'adaf' },
                  { key: '81', name: 'afdafadf', amount: 0, desc: 'adaf' },
                ]}
                pagination={{
                  pageSize: 20,
                  showQuickJumper: false,
                  showSizeChanger: false,
                  total: 100,
                }}
              />
            </Layout.Content>
          </Layout>
        </Modal>
        <Button onClick={() => setTopen(true)}>打开</Button>
      </FormBlock>
      <FormBlock hidden={!topen} header="隐藏板块" key={'models'}>
        <ChoosePopup
          title="弹窗12"
          width={500}
          height={500}
          onFinish={(value, flag) => {
            if (flag) {
              form.setFieldValue(flag, value.name);
              form.validateFields([flag]);
            }

            console.log(value, flag);
          }}
        >
          <FormItem name="name" label="输入框1" rules={[{ required: true }]}>
            <Input />
          </FormItem>
          <FormItem name="name2" label="输入框2">
            <Input />
          </FormItem>
        </ChoosePopup>
      </FormBlock>
      <ApplicationInformationBlock
        header="申请信息"
        key="applicationInformationBlock"
      />
      <FormBlock key="gyxzkBlock" header="选择框" className="gyxzk-block">
        <FormItem label="部门选择框" name="bmxzk">
          <TiggerChoose
            placeholder="请选择部门"
            multiple={true}
            modal={ChooseDept}
            onFinish={handleDeptFinish}
            onTigger={handleDeptTigger}
            config={{
              height: 300,
              width: 500,
            }}
          />
        </FormItem>
        <FormItem label="人员选择框" labelCol={{ flex: '140px' }} name="rrxzk">
          <TiggerChoose
            placeholder="请选择人员"
            multiple={true}
            modal={ChoosePeople}
            onFinish={handlePeopleFinish}
          />
        </FormItem>
        <FormItem label="共用选择框1" name="gyxzk1">
          <Tigger
            placeholder="请选择"
            onTigger={(inputRef) => {
              open({ name: inputRef?.input?.value }, 'gyxzk1'); // 打开赋上次选择值
            }}
          />
        </FormItem>
        <FormItem
          noStyle
          shouldUpdate={(prevValues, currentValues) =>
            prevValues.gyxzk1 !== currentValues.gyxzk1
          }
        >
          {({ getFieldValue }) =>
            getFieldValue('gyxzk1') ? (
              <FormItem label="共用选择框2" name="gyxzk2">
                <Tigger
                  placeholder="请选择"
                  onTigger={() => {
                    open(null, 'gyxzk2'); //每次打开清空弹窗数据
                  }}
                />
              </FormItem>
            ) : null
          }
        </FormItem>
      </FormBlock>
      <FormBlock key="repairBlock" header="维修申请" className="repair-block">
        <FormFiledSet title="基本信息" fill>
          <FormItem label="资产编号" required>
            <Input.Group compact>
              <FormItem
                name="zcbh"
                style={{ width: 'calc(100% - 200px)', marginBottom: 0 }}
                rules={[
                  {
                    required: true,
                    message: '请选择资产编号',
                  },
                ]}
              >
                <Input />
              </FormItem>
              <Button
                type="primary"
                style={{ width: 100 }}
                onClick={() => {
                  form.setFieldValue('zcbh', 'S1123345R');
                  form.setFieldValue('zcmc', '服务器');
                  form.validateFields(['zcbh']);
                }}
              >
                有编号
              </Button>
              <Button
                type="primary"
                style={{ width: 100 }}
                onClick={() => {
                  form.setFieldValue('zcbh', '无编号');
                  form.setFieldValue('zcmc', '水管');
                  form.validateFields(['zcbh']);
                }}
              >
                无编号
              </Button>
            </Input.Group>
          </FormItem>
          <FormItem name="zcmc" label="资产名称">
            <Input />
          </FormItem>
          <FormItem
            name="bmmc"
            label="部门名称"
            rules={[
              {
                required: true,
                message: '请选择部门',
              },
            ]}
            statusConfig={(status, itemStatus) => {
              if (form.getFieldValue('zcmc')) {
                itemStatus.disabled = true;
              } else {
                itemStatus.disabled = false;
              }
              return itemStatus;
            }}
          >
            <Input />
          </FormItem>
          <FormItem name="bmbm" label="部门编码">
            <Input />
          </FormItem>
          <FormItem name="shrq" label="损害日期">
            <DatePicker />
          </FormItem>
          <FormItem name="zcqyrq" label="资产启用日期">
            <DatePicker />
          </FormItem>
          <FormItem name="zxxjqk" label="自行询价情况" fill>
            <Input.TextArea rows={4} />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet title="审核信息" fill cols={1}>
          <FormItem name="bmjl" label="部门经理">
            <Input />
          </FormItem>
          <FormItem name="wxjkr" label="维修接口人">
            <Input />
          </FormItem>
        </FormFiledSet>
        <FormFiledSet fill />
        <FormItem name="sffxpg" label="是否风险评估" crossCol={2}>
          <Radio.Group>
            <Radio value={1}>是</Radio>
            <Radio value={2}>否</Radio>
          </Radio.Group>
        </FormItem>
        <FormItem name="yz" label="原值">
          <InputNumber
            formatter={(value) =>
              `￥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
            }
            parser={(value) => value!.replace(/￥\s?|(,*)/g, '')}
          />
        </FormItem>
        <FormItem name="jz" label="净值">
          <InputNumber
            formatter={(value) =>
              `￥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
            }
            parser={(value) => value!.replace(/￥\s?|(,*)/g, '')}
          />
        </FormItem>
      </FormBlock>
      <ChargeDetailsBlock key="fysqBlock" header="费用明细" />
      <ApprovalHistoryBlock
        header="审批历史记录"
        key="approvalHistoryBlock"
        cols={1}
      />
      <XApprovalCommentsBlock header="审批意见" key="approvalCommentsBlock" />
    </FormBlockSet>
  );
};
export default TandEView;
