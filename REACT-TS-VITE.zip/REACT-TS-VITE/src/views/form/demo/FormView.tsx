//#region 导入
import { FC } from 'react';
// import { useTranslation } from 'react-i18next';

import FormBlock from '@/views/form/baseForm/components/blocks/FormBlock';
import FormBlockSet from '@/views/form/baseForm/components/FormBlockSet';
import FormItem from '@/views/form/baseForm/components/FormItem';
import { useFormData } from '@/views/form/baseForm/services/formService';

import { Button, Input } from 'antd';
import ApplicationInformationBlock from '@/views/form/components/blocks/ApplicationInformationBlock';
import ChargeDetailsBlock from '@/views/form/components/blocks/ChargeDetailsBlock';
import ApprovalCommentsBlock from '@/views/form/baseForm/components/blocks/ApprovalCommentsBlock';

import styles from './FormView.module.less';
//#endregion

/**
 * 表单主体
 * 按状态分：发起、审批、查看
 * - 表单板块集
 *   - 表单板块
 *     - 表单项
 *       - 表单组件组
 * @returns 返回表单主体
 */
const FormView: FC = () => {
  // const { t } = useTranslation();
  const { formSet } = useFormData();

  return (
    <FormBlockSet className={styles['demo-form']}>
      <FormBlock
        key="sjsmBlock"
        header="填表说明"
        className="form-4444"
        collapsible="disabled"
        cols={1}
      >
        <ul>
          <li>formId: {formSet.formId}</li>
          <li>sn: {formSet.sn}</li>
          <li>procInstId: {formSet.procInstId}</li>
        </ul>
      </FormBlock>
      <ApplicationInformationBlock
        key="applicationInformationBlock"
        header="申请人信息"
      />
      <FormBlock key="bdxxBlock" header="表单信息">
        <FormItem name="desp" label="事由" fill={true}>
          <Input />
        </FormItem>
        <FormItem label="业务需要">
          <Input.Group compact>
            <FormItem name="desp" style={{ width: 'calc(100% - 100px)' }}>
              <Input />
            </FormItem>
            <Button type="primary" style={{ width: 100 }}>
              Submit
            </Button>
          </Input.Group>
        </FormItem>
      </FormBlock>
      <ChargeDetailsBlock key="fysqBlock" header="费用明细" />
      <ApprovalCommentsBlock key="approvalCommentsBlock" header="审批意见" />
    </FormBlockSet>
  );
};
export default FormView;
