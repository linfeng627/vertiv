//#region 导入
import { FC } from 'react';
import { Form, Input } from 'antd';
import FormBlockSet from '@/views/form/baseForm/components/FormBlockSet';
import FormBlock from '@/views/form/baseForm/components/blocks/FormBlock';
// import { useTranslation } from 'react-i18next';

// import { useFormData } from './services/formService';
//#endregion

/**
 * 申请表单2
 * @returns 返回表单
 */
const Form2View: FC = () => {
  // 多语言
  // const { t } = useTranslation();

  // 表单配置与数据
  // const { formSet, formData } = useFormData();

  return (
    <FormBlockSet className="form2-form">
      <FormBlock key="xxxBlock" header="申请人信息" className="xxx-block">
        <Form.Item name="usname" label="申请人">
          <Input />
        </Form.Item>
        <Form.Item name="usdept" label="申请部门">
          <Input />
        </Form.Item>
      </FormBlock>
    </FormBlockSet>
  );
};
export default Form2View;
