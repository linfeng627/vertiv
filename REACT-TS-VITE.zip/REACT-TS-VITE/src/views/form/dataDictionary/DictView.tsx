import { useChooseModal } from '@/services/chooseModal';
import {
  DictDataType,
  getDictItems,
} from '@/services/manager/DataDictionaryService';
import { GetDictTree } from '@/services/user';
import {
  Button,
  Checkbox,
  Empty,
  Form,
  FormInstance,
  Input,
  InputRef,
  Layout,
  Popconfirm,
  Space,
  Table,
  Tree,
  TreeSelect,
} from 'antd';
import { DataNode, DirectoryTreeProps } from 'antd/lib/tree';
import React, { FC, useContext, useEffect, useRef, useState } from 'react';

import './Dictview.less';

const { Sider, Content } = Layout;
const { DirectoryTree } = Tree;
const { Search } = Input;

interface Item {
  key: string;
  name: string;
  age: string;
  address: string;
}

interface EditableRowProps {
  index: number;
}

interface EditableCellProps {
  title: React.ReactNode;
  editable: boolean;
  children: React.ReactNode;
  dataIndex: keyof Item;
  record: Item;
  handleSave: (record: Item) => void;
}

const EditableContext = React.createContext<FormInstance<any> | null>(null);

const EditableRow: React.FC<EditableRowProps> = ({ index, ...props }) => {
  const [form] = Form.useForm();
  return (
    <Form form={form} component={false}>
      <EditableContext.Provider value={form}>
        <tr {...props} />
      </EditableContext.Provider>
    </Form>
  );
};

const EditableCell: React.FC<EditableCellProps> = ({
  title,
  editable,
  children,
  dataIndex,
  record,
  handleSave,
  ...restProps
}) => {
  const [editing, setEditing] = useState(false);
  const inputRef = useRef<InputRef>(null);
  const form = useContext(EditableContext)!;

  useEffect(() => {
    if (editing) {
      inputRef.current!.focus();
    }
  }, [editing]);

  const toggleEdit = () => {
    setEditing(!editing);
    form.setFieldsValue({ [dataIndex]: record[dataIndex] });
  };

  const save = async () => {
    try {
      const values = await form.validateFields();
      console.log('Save data...');
      toggleEdit();
      handleSave({ ...record, ...values });
    } catch (errInfo) {
      console.log('Save failed:', errInfo);
    }
  };

  let childNode = children;

  if (editable) {
    childNode = editing ? (
      <Form.Item
        style={{ margin: 0 }}
        name={dataIndex}
        rules={[
          {
            required: true,
            message: `${title} is required.`,
          },
        ]}
      >
        <Input ref={inputRef} onPressEnter={save} onBlur={save} />
      </Form.Item>
    ) : (
      <div
        className="editable-cell-value-wrap"
        style={{ paddingRight: 24 }}
        onClick={toggleEdit}
      >
        {children}
      </div>
    );
  }

  return <td {...restProps}>{childNode}</td>;
};

type EditableTableProps = Parameters<typeof Table>[0];

type ColumnTypes = Exclude<EditableTableProps['columns'], undefined>;

/** 数据字典视图页 */
const DataDictionaryView: FC = () => {
  /**tree 数据源 */
  const [treeData, SettreeData] = useState<Array<DataNode>>([]);
  useEffect(() => {
    GetDictTree().then((res) => {
      console.log(res);
      SettreeData(res.data);
    });
  }, []);

  const [currentKey, SetcurrentKey] = useState(false);
  const onSelect: DirectoryTreeProps['onSelect'] = (keys, info) => {
    console.log('Trigger Select', keys, info);
    SetcurrentKey(true);
    getDictItems('').then((res) => {
      console.log(res.data);
      setDataSource(res.data);
    });
  };

  const onExpand: DirectoryTreeProps['onExpand'] = (keys, info) => {
    console.log('Trigger Expand', keys, info);
  };

  /**树控件搜索事件 */
  const onSearchHandle = () => {
    //const { value } = e.target;
    // const newExpandedKeys = dataList
    //   .map((item) => {
    //     if (item.title.indexOf(value) > -1) {
    //       return getParentKey(item.key, defaultData);
    //     }
    //     return null;
    //   })
    //   .filter((item, i, self) => item && self.indexOf(item) === i);
    // setExpandedKeys(newExpandedKeys);
    // setSearchValue(value);
    // setAutoExpandParent(true);
    //console.log(value);
  };

  /**table 数据源 */
  const [dataSource, setDataSource] = useState<DictDataType[]>([]);
  useEffect(() => {
    getDictItems('').then((res) => {
      console.log(res.data);
      setDataSource(res.data);
    });
  }, []);
  const defaultColumns: (ColumnTypes[number] & {
    editable?: boolean;
    dataIndex: string;
  })[] = [
    {
      title: 'itemKey',
      dataIndex: 'itemKey',
      // width: '30%',
      // editable: true,
    },
    {
      title: 'itemName',
      dataIndex: 'itemName',
    },
    {
      title: 'itemValue',
      dataIndex: 'itemValue',
    },
    {
      title: 'startTime',
      dataIndex: 'startTime',
    },
    {
      title: 'endTime',
      dataIndex: 'endTime',
    },
    {
      title: 'remark',
      dataIndex: 'remark',
    },
    {
      title: 'operation',
      dataIndex: 'operation',
      render: (record: { key: React.Key }) =>
        dataSource.length >= 1 ? (
          <Popconfirm
            title="Sure to delete?"
            onConfirm={() => handleDelete(record.key)}
          >
            <Button.Group>
              <Space>
                <Button type="primary" size="small" danger>
                  Delete
                </Button>
                <Button type="primary" size="small">
                  Edit
                </Button>
              </Space>
            </Button.Group>
          </Popconfirm>
        ) : null,
    },
  ];

  const columns = defaultColumns.map((col) => {
    if (!col.editable) {
      return col;
    }
    return {
      ...col,
      onCell: (record: DictDataType) => ({
        record,
        editable: col.editable,
        dataIndex: col.dataIndex,
        title: col.title,
        handleSave,
      }),
    };
  });

  const handleSave = (row: DictDataType) => {
    const newData = [...dataSource];
    const index = newData.findIndex((item) => row.key === item.key);
    const item = newData[index];
    newData.splice(index, 1, {
      ...item,
      ...row,
    });
    setDataSource(newData);
  };

  const handleDelete = (key: React.Key) => {
    const newData = dataSource.filter((item) => item.key !== key);
    setDataSource(newData);
  };

  const [count, setCount] = useState(dataSource.length);
  const addDictHandle = () => {
    const newData: DictDataType = {
      key: count,
      itemKey: `Edward King ${count}`,
      itemName: `London, Park Lane no. ${count}`,
      itemValue: '32',
      startTime: '',
      endTime: '',
      remark: `London, Park Lane no. ${count}`,
    };
    setDataSource([...dataSource, newData]);
    setCount(count + 1);
  };

  const components = {
    body: {
      row: EditableRow,
      cell: EditableCell,
    },
  };

  // 创建弹窗容器
  const [openAddTreeModal, AddTreeDataPopup] = useChooseModal();
  const [form] = Form.useForm();
  const [value, setValue] = useState<string | undefined>(undefined);
  const layout = {
    labelCol: { span: 4 },
    wrapperCol: { span: 20 },
  };
  const tailLayout = {
    wrapperCol: { offset: 18, span: 6 },
  };
  const onFinish = (values: any) => {
    console.log(values);
  };

  const [isRootDir, SetIsRootDir] = useState<boolean>(false);

  return (
    <Layout>
      <Sider
        width={250}
        style={{
          paddingLeft: 10,
          paddingRight: 10,
          borderRight: '5px solid #d4d4d4',
        }}
      >
        <Search
          style={{ paddingTop: 10, paddingBottom: 10 }}
          placeholder="Search"
          onChange={onSearchHandle}
        />
        <Button.Group>
          <Button
            type="primary"
            size="small"
            onClick={() => openAddTreeModal()}
          >
            新增节点
          </Button>
          <AddTreeDataPopup
            title="新增节点"
            onFinish={(record: any) => {
              form.validateFields();
              debugger;
              console.log(record);
              return false;
            }}
            width={500}
            footer={null}
          >
            <Form
              {...layout}
              form={form}
              name="control-hooks"
              onFinish={onFinish}
            >
              <Form.Item
                name="itemName"
                label="节点名"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name="itemCode"
                label="节点Code"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                name="parentId"
                label="父目录"
                rules={[{ required: true }]}
              >
                <TreeSelect
                  showSearch
                  value={value}
                  style={{ width: '100%' }}
                  dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                  placeholder="Please select"
                  allowClear
                  treeDefaultExpandAll
                  onChange={(newValue: string) => {
                    setValue(newValue);
                    debugger;
                    //form.setFieldValue('parentId', newValue);
                  }}
                  treeData={treeData}
                />
              </Form.Item>
              <Form.Item
                noStyle
                shouldUpdate={(prevValues, currentValues) =>
                  prevValues.gender !== currentValues.gender
                }
              >
                {({ getFieldValue }) =>
                  getFieldValue('gender') === 'other' ? (
                    <Form.Item
                      name="customizeGender"
                      label="Customize Gender"
                      rules={[{ required: true }]}
                    >
                      <Input />
                    </Form.Item>
                  ) : null
                }
              </Form.Item>
              <Form.Item name="parentId2" label="是否根节点">
                <Checkbox
                  checked={isRootDir}
                  onChange={(e) => {
                    SetIsRootDir(e.target.checked);
                    const parentId = isRootDir
                      ? '00000000-0000-0000-0000-000000000000'
                      : form.getFieldValue('parentId');
                    form.setFieldValue('parentId', parentId);
                  }}
                >
                  是
                </Checkbox>
              </Form.Item>
              <Form.Item {...tailLayout}>
                <Button
                  type="primary"
                  size="small"
                  onClick={() => {
                    form.validateFields().then((res) => console.log(res));
                    debugger;
                  }}
                >
                  Submit
                </Button>
                {/* <Button htmlType="button" onClick={this.onReset}>
                  Reset
                </Button>
                <Button type="link" htmlType="button" onClick={this.onFill}>
                  Fill form
                </Button> */}
              </Form.Item>
            </Form>
          </AddTreeDataPopup>
        </Button.Group>
        <DirectoryTree
          multiple
          className="dictTree"
          defaultExpandAll
          onSelect={onSelect}
          onExpand={onExpand}
          treeData={treeData}
        />
      </Sider>
      <Layout>
        <Content style={{ padding: 10 }}>
          {currentKey ? (
            <div>
              <Button.Group>
                <Space>
                  <Button
                    onClick={addDictHandle}
                    type="primary"
                    size="small"
                    style={{ marginBottom: 16 }}
                  >
                    Add a row
                  </Button>
                </Space>
              </Button.Group>
              <Table
                scroll={{ x: 1000 }}
                size="small"
                components={components}
                rowClassName={() => 'editable-row'}
                bordered
                dataSource={dataSource}
                columns={columns as ColumnTypes}
              />
            </div>
          ) : (
            <Empty />
          )}
        </Content>
      </Layout>
    </Layout>
  );
};

export default DataDictionaryView;
