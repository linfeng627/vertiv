//#region 导入
import { FC, PropsWithChildren } from 'react';
import { FormItemBaseProps } from '@/stores';
//#endregion

/** 组件属性 */
interface Props extends PropsWithChildren<FormItemBaseProps> {
  /**  */
  xxx: string;
}

/**
 * 表单内使用带子容器插槽的第三方组件实例
 * @param props 组件属性
 * @returns 返回本组件
 */
const ChildrenField: FC<Props> = (props) => {
  return <div>{props.children}</div>;
};
export default ChildrenField;

// interface Props extends FormItemBaseProps {
//   /**  */
//   xxx: string;
// }

// const ChildrenField2: FC<PropsWithChildren<Props>> = (props) => {
//   return <div>{props.children}</div>;
// };
// export default ChildrenField2;
