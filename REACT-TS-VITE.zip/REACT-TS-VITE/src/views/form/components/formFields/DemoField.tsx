//#region 导入
import { FC } from 'react';
import { FormItemBaseProps } from '@/stores';
//#endregion

/** 组件属性 */
interface Props extends FormItemBaseProps {
  /**  */
  xxx: string;
}

/**
 * 表单内使用第三方组件实例
 * @param props 组件属性
 * @returns 返回本组件
 */
const DemoFiled: FC<Props> = (props) => {
  return <div>{props.xxx}</div>;
};
export default DemoFiled;
