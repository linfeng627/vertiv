//#region 导入
import ChoosePeople from '@/components/choose/ChoosePeople';
import { UserDataType } from '@/stores/user';
import { EllipsisOutlined } from '@ant-design/icons';
import { FC } from 'react';
// import { useTranslation } from 'react-i18next';

import ApprovalCommentsBlock, {
  ApprovalCommentsProps,
} from '../../baseForm/components/blocks/ApprovalCommentsBlock';
import TiggerChoose from '../../baseForm/components/formFields/TrggerChoose';
import FormItem from '../../baseForm/components/FormItem';
import { useFormContext } from '../../baseForm/stores/formContext';
//#endregion

/**
 * 审批意见板块(项目改造)
 * @param props 表单板块属性
 * @returns 返回组件
 */
const XApprovalCommentsBlock: FC<ApprovalCommentsProps> = (props) => {
  // 通过上下文获取表单form对象
  const form = useFormContext();

  // 操作选人弹窗
  const handlePeopleFinish = (data: UserDataType[]) => {
    const names: string[] = [];
    data.forEach((record) => {
      names.push(record.name.first);
    });
    form.setFieldValue(['approvalComment', 'cc'], names.join(', '));
    form.validateFields(['approvalComment', 'cc']);
  };

  // 扩展原有审批意见，在底部增加审批抄送人
  return (
    <ApprovalCommentsBlock {...props} cols={2}>
      <FormItem
        label="抄送人"
        name={['approvalComment', 'cc']}
        rules={[
          {
            required: true,
            message: '请选择抄送人',
          },
        ]}
      >
        <TiggerChoose
          placeholder="请选择人员"
          icon={EllipsisOutlined}
          multiple={true}
          modal={ChoosePeople}
          onFinish={handlePeopleFinish}
        />
      </FormItem>
    </ApprovalCommentsBlock>
  );
};

export default XApprovalCommentsBlock;
