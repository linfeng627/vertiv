import { Button, Form, Input, Modal, Radio, Table } from 'antd';
import React, { useState } from 'react';
import FormBlockSet from '../../baseForm/components/FormBlockSet';
import FormTable from '../../baseForm/components/formFields/Table/FormTable';
import FormFiledSet from '../../baseForm/components/FormFiledSet';
import FormItem from '../../baseForm/components/FormItem';
import ResizeObserver from 'rc-resize-observer';

interface Values {
  title: string;
  description: string;
  modifier: string;
}

interface CollectionCreateFormProps {
  title?: string;
  width?: number;
  open: boolean;
  onCreate: (values: Values) => void;
  onCancel: () => void;
}

const XAssetDetaislModal: React.FC<CollectionCreateFormProps> = ({
  title,
  width,
  open,
  onCreate,
  onCancel,
}) => {
  const tableHeader = [
    {
      title: '序号',
      dataIndex: 'num',
      key: 'num',
      width: '6%',
    },
    {
      title: '工号',
      dataIndex: 'jobnumber',
      key: 'jobnumber',
      width: '6%',
    },
    {
      title: '使用人',
      dataIndex: 'username',
      key: 'username',
      width: '6%',
    },
    {
      title: '资产编号',
      dataIndex: 'assetcode',
      key: 'assetcode',
      width: '6%',
    },
    {
      title: '资产名称',
      dataIndex: 'assetname',
      key: 'assetname',
      width: '6%',
    },
    {
      title: '附属物品',
      dataIndex: 'attachedItems',
      key: 'attachedItems',
      width: '6%',
    },
    {
      title: '计量属性',
      dataIndex: 'meterproperty',
      key: 'meterproperty',
      width: '6%',
    },
    {
      title: '公司段',
      dataIndex: 'company',
      key: 'company',
      width: '6%',
    },
    {
      title: '使用部门',
      dataIndex: 'useDept',
      key: 'useDept',
      width: '6%',
    },
    {
      title: '使用编号',
      dataIndex: 'useNumber',
      key: 'useNumber',
      width: '6%',
    },
    {
      title: '城市',
      dataIndex: 'city',
      key: 'city',
      width: '6%',
    },
    {
      title: '位置',
      dataIndex: 'address',
      key: 'address',
      width: '6%',
    },
    {
      title: '产品段',
      dataIndex: 'product',
      key: 'product',
      width: '6%',
    },
    {
      title: '海关属性',
      dataIndex: 'customs',
      key: 'customs',
      width: '6%',
    },
    {
      title: '启动日期',
      dataIndex: 'startDate',
      key: 'startDate',
      width: '6%',
    },
  ];
  const tableDataSource = [{}];
  return (
    <FormBlockSet>
      <FormFiledSet cols={3}>
        <FormItem label="工号">
          <Input></Input>
        </FormItem>
        <FormItem label="资产编号">
          <Input></Input>
        </FormItem>
      </FormFiledSet>
      <FormFiledSet cols={3}>
        <FormItem label="使用人">
          <Input></Input>
        </FormItem>
        <FormItem label="资产名称">
          <Input></Input>
        </FormItem>
        <FormItem name="name2" label="">
          <Button size="small" type="primary">
            查询
          </Button>
        </FormItem>
      </FormFiledSet>
      <FormFiledSet cols={24}>
        <ResizeObserver onResize={() => 1000}>
          <Table
            className="virtual-table"
            columns={tableHeader}
            dataSource={tableDataSource}
          ></Table>
        </ResizeObserver>
      </FormFiledSet>
    </FormBlockSet>
  );
};

export default XAssetDetaislModal;
