//#region 导入
import { FC } from 'react';
// import { useTranslation } from 'react-i18next';

import { Input } from 'antd';
import FormBlock, {
  FormPanelProps,
} from '../../baseForm/components/blocks/FormBlock';
import FormFiledSet from '../../baseForm/components/FormFiledSet';
import FormItem from '../../baseForm/components/FormItem';

import ChooseDept from '@/components/choose/ChooseDept';
import { DeptDataNode } from '@/stores/dept';
import { useFormContext } from '../../baseForm/stores/formContext';
import { EllipsisOutlined } from '@ant-design/icons';
// import { isLaunchView } from '../../baseForm/services/formService';
import TiggerChoose from '../../baseForm/components/formFields/TrggerChoose';
import ChoosePeople from '@/components/choose/ChoosePeople';
//#endregion

/**
 * 申请人信息板块
 * @param props 表单板块类型
 * @returns
 */
const ApplicationInformationBlock: FC<FormPanelProps> = (props) => {
  // 板块标题
  const blockTitle = '申请信息';
  // 板块样式名
  const blockClassName = 'form-application-information-block';

  const cpProps: FormPanelProps = {
    collapsible: 'disabled',
    ...props,
    header: blockTitle,
    className: (props.className ?? '') + ' ' + blockClassName,
    cols: 1,
  };
  //通过上下文获取表单form对象
  const form = useFormContext();

  const handlePeopleFinish = (value: any[]) => {
    if (value.length) {
      form.setFieldValue('proxy', value[0].name.first);
    } else {
      form.setFieldValue('proxy', '');
    }
    form.validateFields(['proxy']);
  };
  const handleDeptFinish = (value: any) => {
    const names: string[] = [];
    const keys: string[] = [];

    console.log('dept:', value);
    value.forEach((record: any) => {
      names.push(record.title);
      keys.push(record.key);
    });
    // 多选部门名
    form.setFieldValue('proxyDept', names.join(', '));
    // 多选部门ID
    form.setFieldValue('proxyDeptId', keys.join(', '));
    form.validateFields(['proxyDept']);
  };
  const handleDeptTigger = (inputRef: any, open: any) => {
    // 拼装已选部门数据结构
    const depts: DeptDataNode[] = [];

    if (inputRef?.input?.value) {
      const names = ((form.getFieldValue('proxyDept') ?? '') as string).split(
        ', ',
      );
      const keys = ((form.getFieldValue('proxyDeptId') ?? '') as string).split(
        ', ',
      );
      names.forEach((name, i) => {
        depts.push({
          title: name,
          key: keys[i],
        });
      });
    }

    //打开回显数据
    open(depts);
  };

  return (
    <FormBlock {...cpProps}>
      <FormFiledSet title="发起人信息">
        <FormItem name="userName" label="填写人">
          <Input disabled />
        </FormItem>
        <FormItem
          name="email"
          label="E-mail"
          // rules={[
          //   {
          //     type: 'email',
          //     message: '这是无效Email！',
          //   },
          //   {
          //     required: true,
          //     message: '请输入你的Email！',
          //   },
          // ]}
        >
          <Input disabled />
        </FormItem>
      </FormFiledSet>
      <FormFiledSet title="申请人信息">
        <FormItem
          name="proxy"
          label="申请人"
          // statusConfig={(status, itemStatus) => {
          //   if (!isLaunchView(status.formViewStatus)) {
          //     itemStatus.disabled = true;
          //   }
          //   return itemStatus;
          // }}
          // rules={[
          //   {
          //     required: true,
          //     message: '请选择申请人',
          //   },
          // ]}
        >
          <TiggerChoose
            placeholder="请选择人员"
            icon={EllipsisOutlined}
            modal={ChoosePeople}
            onFinish={handlePeopleFinish}
          />
        </FormItem>
        <FormItem
          name="proxyDept"
          label="申请部门"
          // rules={[
          //   {
          //     required: true,
          //     message: '请选择申请部门',
          //   },
          // ]}
        >
          <TiggerChoose
            placeholder="请选择部门"
            icon={EllipsisOutlined}
            modal={ChooseDept}
            onFinish={handleDeptFinish}
            onTigger={handleDeptTigger}
          />
        </FormItem>
      </FormFiledSet>
    </FormBlock>
  );
};

export default ApplicationInformationBlock;
