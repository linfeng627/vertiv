//#region 导入
import { FC } from 'react';
// import { useTranslation } from 'react-i18next';
import FormBlock, {
  FormPanelProps,
} from '../../baseForm/components/blocks/FormBlock';
import FormEditorTable from '../../baseForm/components/formFields/Table/FormEditorTable';
import { Guid } from '@/utils';
import { useFormData } from '../../baseForm/services/formService';
import FormItem from '../../baseForm/components/FormItem';
import FormTable from '../../baseForm/components/formFields/Table/FormTable';
import FormRowEditorTable from '../../baseForm/components/formFields/Table/FormRowEditorTable';
import { Input, InputNumber } from 'antd';
import FormFiledSet from '../../baseForm/components/FormFiledSet';
// import { PaginationRsp } from '@/stores';
//#endregion

interface XTableData {
  key: string;
  name: string;
  amount: number;
  desc: string;
}

/**
 * 费用明细
 * @param props 组件属性
 * @returns 返回组件
 */
const ChargeDetailsBlock: FC<FormPanelProps> = (props) => {
  const { formSet } = useFormData();
  //获取板块列配置
  const columns = formSet.formCompTree!.tables;

  //板块默认单行
  const cpProps = {
    header: '申请费用',
    ...props,
    cols: 1,
  };
  // const [dataSource, setDataSource] = useState(null);
  // const [pagination, setPagination] = useState<PaginationRsp>({
  //   pageNum: 1,
  //   totle: 35,
  //   pageSize: 10,
  // });
  // load
  return (
    <FormBlock {...cpProps}>
      <FormFiledSet title="行编辑表格" cols={1}>
        <FormItem noStyle name="tables">
          <FormRowEditorTable<XTableData>
            // disabled={true}
            scroll={{ y: '180px' }}
            // multiple={true}
            columns={formSet.formCompTree!.tables}
            pagination={{
              pageSize: 20,
              showQuickJumper: false,
              showSizeChanger: false,
              total: 100,
            }}
            items={
              <>
                <FormItem name="key" label="ID">
                  <Input />
                </FormItem>
                <FormItem name="name" label="姓名">
                  <Input />
                </FormItem>
                <FormItem name="amount" label="金额">
                  <InputNumber />
                </FormItem>
                <FormItem name="desc" label="描述">
                  <Input />
                </FormItem>
              </>
            }
          />
        </FormItem>
      </FormFiledSet>
      {/* noStyle不显示字段label，将tables数据传递到可编辑表格中 */}
      <FormFiledSet title="单元格编辑表格" cols={1}>
        <FormItem noStyle name="tables">
          <FormEditorTable
            columns={columns}
            onBeforeAdd={({ records }) => {
              console.log('onBeforeAdd');
              // 唯一索引键
              const indexKey = Guid();
              // 新记录
              const newRecord = {
                key: indexKey,
                name: `Fangle`,
                amount: 10000,
                desc: `吃喝玩乐: ${records.length}`,
              };
              console.log('Key： ', indexKey);

              return newRecord;
            }}
            onAdd={(e) => {
              console.log('onAdd', e);
              e;
            }}
            pagination={false}
          />
        </FormItem>
      </FormFiledSet>
      <FormFiledSet title="只读表格" cols={1}>
        <FormItem noStyle name="tables">
          <FormTable columns={columns} />
        </FormItem>
      </FormFiledSet>
    </FormBlock>
  );
};

export default ChargeDetailsBlock;
