//#region 导入
import { UploadOutlined } from '@ant-design/icons';
import { Button, Popconfirm, Space, Upload, UploadProps } from 'antd';
import { ColumnsType } from 'antd/lib/table';
import axios from 'axios';
import { FC, useEffect, useState } from 'react';
import { Attachment } from '../../assetManagement/transferView/CapitalTransferModel';
import FormTable from '../../baseForm/components/formFields/Table/FormTable';
import FormFiledSet from '../../baseForm/components/FormFiledSet';
import FormItem from '../../baseForm/components/FormItem';

//#endregion

/**
 * 附件列表
 * @param props 表单板块属性
 * @returns 返回组件
 */
const XAttachmentBlock: FC<{ procInstId?: number }> = (procInstId) => {
  // // const [fileList, setFileList] = useState<Attachment[]>([]);

  const handleChange: UploadProps['onChange'] = (info) => {
    debugger;
    let newFileList = [...info.fileList];
    newFileList = newFileList.slice(-2);
    newFileList = newFileList.map((file) => {
      if (file.response) {
        file.url = file.response.url;
        // file.fileSize = file.response.url;
        // file.fileType = file.response.url;
        // file.date = file.response.url;
        // file.fileName = file.response.url;
        // file.activityName = file.response.url;
        // file.userName = file.response.url;
      }
      return file;
    });
    // TODO...
    //setFileList(newFileList);
  };
  const fileUploadprops: UploadProps = {
    action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    onChange: handleChange,
    multiple: true,
  };

  const attachmentListHeader: ColumnsType<Attachment> = [
    {
      title: '文件名',
      dataIndex: 'fileName',
      key: 'fileName',
    },
    {
      title: '文件大小',
      dataIndex: 'fileSize',
      key: 'fileSize',
      width: '120px',
    },
    {
      title: '文件类型',
      dataIndex: 'fileType',
      key: 'fileType',
      width: '120px',
    },
    {
      title: '上传时间',
      dataIndex: 'date',
      key: 'date',
      width: '170px',
    },
    {
      title: '上传节点',
      dataIndex: 'activityName',
      key: 'activityName',
    },
    {
      title: '上传人',
      dataIndex: 'userName',
      key: 'userName',
      width: '130px',
    },
    {
      title: '操作',
      key: 'action',
      render: (record) => (
        <Space size="middle">
          <Popconfirm
            title="确认删除？"
            onConfirm={() => confirm(record)}
            onOpenChange={() => console.log('open change')}
          >
            <Button size="small" type="default" danger>
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];
  const confirm = (row: Attachment) =>
    new Promise((resolve) => {
      console.log(row.fileName);
      setTimeout(() => resolve(null), 3000);
    });

  const [attachmentList, SetAttachmentList] = useState([]);
  useEffect(() => {
    axios
      .get('/api/AttachmentList', { params: { procInstId: procInstId } })
      .then((res) => {
        SetAttachmentList(res.data.data);
        console.log(res.data.data);
      });
  }, []);

  return (
    <div key="gujbnvghmfg">
      <FormFiledSet cols={1}>
        <FormItem>
          <Upload
            {...fileUploadprops}
            // fileList={attachmentList}
            // listType="text"
            // itemRender={() => {
            //   return (
            //     <FormItem>
            //       <FormTable
            //         key="mnksdjfl"
            //         columns={attachmentListHeader}
            //         dataSource={attachmentList}
            //       ></FormTable>
            //     </FormItem>
            //   );
            // }}
            onRemove={(record) => console.log(record.fileName)}
          >
            <Button icon={<UploadOutlined />}>点击上传附件</Button>
          </Upload>
        </FormItem>
        <FormItem>
          <FormTable
            key="mnksdjfl"
            columns={attachmentListHeader}
            dataSource={attachmentList}
          ></FormTable>
        </FormItem>
      </FormFiledSet>
    </div>
  );
};
export default XAttachmentBlock;
