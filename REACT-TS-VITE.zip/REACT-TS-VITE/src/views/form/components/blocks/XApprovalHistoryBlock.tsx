//#region 导入
import axios from 'axios';
import { FC, useEffect, useState } from 'react';
import FormTable from '../../baseForm/components/formFields/Table/FormTable';
import FormFiledSet from '../../baseForm/components/FormFiledSet';
import FormItem from '../../baseForm/components/FormItem';

//#endregion

/**
 * 审批历史记录
 * @param props 表单板块属性
 * @returns 返回组件
 */
const XApprovalHistoryBlock: FC<{ procInstId?: number }> = (procInstId) => {
  const approvalHistoryHeader = [
    {
      title: '审批节点',
      dataIndex: 'activityName',
      key: 'activityName',
    },
    {
      title: '审批人',
      dataIndex: 'approver',
      key: 'approver',
      width: '130px',
    },
    {
      title: '审批日期',
      dataIndex: 'date',
      key: 'date',
      width: '170px',
    },
    {
      title: '审批意见',
      dataIndex: 'action',
      key: 'action',
      width: '90px',
    },
    {
      title: '备注说明',
      dataIndex: 'reamrk',
      key: 'reamrk',
    },
  ];

  const [approvalHistory, SetapprovalHistory] = useState([]);
  useEffect(() => {
    axios
      .get('/api/ApprovalHistory', { params: { procInstId: procInstId } })
      .then((res) => {
        SetapprovalHistory(res.data.data);
        console.log(res.data.data);
      });
  }, []);

  return (
    <>
      <FormFiledSet cols={1}>
        <FormItem>
          <FormTable
            columns={approvalHistoryHeader}
            dataSource={approvalHistory}
          ></FormTable>
        </FormItem>
      </FormFiledSet>
    </>
  );
};
export default XApprovalHistoryBlock;
