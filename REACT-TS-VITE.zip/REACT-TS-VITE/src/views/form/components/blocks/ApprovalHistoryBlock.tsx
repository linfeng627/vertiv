//#region 导入
import { FC } from 'react';

import FormBlock, {
  FormPanelProps,
} from '@/views/form/baseForm/components/blocks/FormBlock';
import { useFormData } from '@/views/form/baseForm/services/formService';
import ApprovalHistory from '@/components/ApprovalHistory';

//#endregion

/**
 * 审批历史记录
 * @param props 表单板块属性
 * @returns 返回组件
 */
const ApprovalHistoryBlock: FC<FormPanelProps> = (props) => {
  // 多语言
  // const { t } = useTranslation();

  // 板块样式名
  const blockClassName = 'form--block';

  // 定义此板块默认设置
  const cpProps: FormPanelProps = {
    ...props,
    className: (props.className ?? '') + ' ' + blockClassName,
  };
  const { formSet } = useFormData();

  return formSet.procInstId ? (
    <FormBlock {...cpProps} collapsible="disabled">
      <ApprovalHistory procInstId={formSet.procInstId}></ApprovalHistory>
    </FormBlock>
  ) : null;
};
export default ApprovalHistoryBlock;
