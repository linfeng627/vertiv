# 表单开发

![Form](/assets/Form.png)

### 表单组件关系图

```text
router/index.tsx
FormLayout.tsx ➜ FormHeader.tsx ➜ FormActions.tsx
               ➜ XxxView.tsx ➜ FormBlockSet.tsx ➜ FormBlock.tsx ➜ FormFiledSet.tsx ➜ FormItem.tsx ➜ 表单项组件
                                                                   ➜ FormItem.tsx ➜ 表单项组件
                                                  ➜ FormSideCatalog.tsx
               ➜ ProcInstLogs.tsx ➜ ApprovalHistory.tsx
               ➜ ChoosePeople.tsx
               ➜ ChooseDept.tsx
```

### 组件列表

**路由设置**

```text
router/index.tsx ➜ 多表单路由
```

**表单通用组件**

```text
FormLayout.tsx ➜ 表单主体布局组件
FormHeader.tsx ➜ 表单头组件（表单标题，居顶显示表单操作按钮）
FormFooter.tsx ➜ 表单尾组件（居底显示表单操作按钮）
FormActions.tsx ➜ 表单操作行为组件（提交表单操作）
FormBlockSet.tsx ➜ 表单板块集组件（维持表单数据及上下文状态）
FormBlock.tsx ➜ 表单板块组件（表单板块，自动行列布局）
FormFiledSet.tsx ➜ 表单字段集组件（表单项分组展示，自动行列布局）
FormItem.tsx ➜ 表单项（表单项标签名，绑定数据字段，根据表单状态改变表单项禁用、隐藏状态）
ProcInstLogs.tsx ➜ 流转记录组件
```

**表单板块通用组件**

```text
ApprovalHistory.tsx ➜ 审批历史记录组件
ApprovalCommentsBlock.tsx ➜ 审批意见板块
```

**表单项通用组件**

```text
FormTable.tsx ➜ 表格组件
FormEditorTable.tsx ➜ 编辑表格组件
Tigger ➜ 触发器输入框（用于点击触发onTigger事件）
ChoosePeople.tsx ➜ 选人组件
ChooseDept.tsx ➜ 选部门组件
```

**用例部分**

```text
FormView.tsx ➜ 表单Dome用例
ApplicationInformationBlock.tsx ➜ 申请信息板块
```

---

## 快速开始

### 我们来创建第一个表单：维修申请

1. 进入`@/views/form`目录。
2. 创建`repair`维修分类目录。
3. 创建`RepairRequestView.tsx`维修申请表单。
4. 创建`RepairRequestView.module.less`同名的样式文件，注意后缀`.module.less`。

```sh
src
└── views
    └── form
        └── baseForm ➜ 基础组件目录（勿动）
        └── components ➜ 项目通用组件
            └── blocks ➜ 项目通用板块
        └── repair ➜ 维修分类目录
            └── RepairRequestView.tsx ➜ 维修申请表单
            └── RepairRequestView.module.less ➜ 维修申请表单样式文件
```

### 1. 定义表单样式文件

- 输入`formStyleTemplate`用户代码片段，快速创建[空表单样式模板](/.vscode/空表单样式模板.code-snippets)。
- 表单样式名`repair-form`（必须全小写，多词组使用`-`分隔，`-form`结尾）。
- 如复用已有样式文件，可以跳过此步，在代码中导入即可。

```less
// 以下最外两层样式嵌套为固定格式
// 导出组件主样式（样式名在编译时替换为唯一key，防止污染）
// :global后定义的样式都不会被替换为唯一key
.repair-form {
  :global {
    // 以下样式为自定义样式
  }
}
```

### 2. 一步一步绘制表单

#### 2.1. 首先创建一个空 维修申请表单 代码

**推荐：** 当完成`2.1. 创建空表单`后，可以先执行`3. 挂载、激活表单`。之后回来继续绘制表单时，就可以实时看到界面效果了。

- 输入`formTemplate`用户代码片段，快速创建[空表单模板](/.vscode/空表单模板.code-snippets)。
- 表单组件名`RepairRequestView`（必须首字母大写，并遵守驼峰命名规则，`View`结尾）。
- 表单样式名`className={styles['repair-form']}`要与样式文件中定义的一致。

```tsx
//#region 导入
import { FC } from 'react';
import { useTranslation } from 'react-i18next';

import FormBlock from '@/views/form/baseForm/components/blocks/FormBlock';
import FormBlockSet from '@/views/form/baseForm/components/FormBlockSet';
import FormFiledSet from '@/views/form/baseForm/components/FormFiledSet';
import FormItem from '@/views/form/baseForm/components/FormItem';
import { useFormData } from '@/views/form/baseForm/services/formService';

import styles from './RepairRequestView.module.less';
//#endregion

/**
 * 维修申请表单
 * @returns 返回表单
 */
const RepairRequestView: FC = () => {
  const { t } = useTranslation();

  // 表单配置与数据
  const { formSet, formData } = useFormData();

  return (
    <FormBlockSet className={styles['repair-form']}>
      {/* 此处插入多个板块内容 */}
    </FormBlockSet>
  );
};
export default RepairRequestView;
```

#### 2.2. 添加必要板块（申请信息板块、审批意见板块）

规划整体通用板块，将表单通用布局布置完成

- 添加常用板块（`申请信息板块`，`审批意见板块`）。
- 这些板块一般在项目中复用，独立封装为[项目通用组件]()。
- 每个板块都必须有唯一键`key`（通常与组件名相同，首字母小写）。
  如申请信息板块`key="applicationInformationBlock"`。

```tsx
...
import ApplicationInformationBlock from '@/views/form/components/blocks/ApplicationInformationBlock';
import XApprovalCommentsBlock from '@/views/form/components/blocks/XApprovalCommentsBlock';
...
<FormBlockSet ...>
  {/* 申请信息板块 */}
  <ApplicationInformationBlock header="申请信息" key="applicationInformationBlock" />
  {/* 审批意见板块 */}
  <XApprovalCommentsBlock header="审批意见" key="approvalCommentsBlock" />
  </FormBlockSet>
</FormBlockSet>
...
```

#### 2.3. 添加维修申请板块

细分下表单中基础信息的大类、审批的不同阶段。合理建立自定义板块来分割相关性不高的业务字段组。

- 在`FormBlockSet`组件中，输入`insertFormBlock`用户代码片段，快速自定义[插入表单板块](/.vscode/插入表单板块.code-snippets)。
- 配置板块标题`header="维修申请"`.
- 配置板块样式`className="repair-block"`.

```tsx
...
{/* 维修申请板块 */}
<FormBlock key="repairBlock" header="维修申请" className="repair-block">
</FormBlock>
{/* 审批意见板块 */}
...
```

#### 2.4. 维修申请板块中分两部分业务数据集（基本信息字段集，审核信息字段集）

当一组相关数据过多时，可以通过字段集的形式将数据进行包装，以提高用户阅读体验。

- 在`FormBlock`组件中，输入`insertFormFieldSet`用户代码片段，快速[插入自定义表单字段集](/.vscode/插入表单字段集.code-snippets)。
- 配置程序集标题`title="基本信息"`
- 规划整体板块，快速搭建板块布局

```tsx
...
{/* 维修申请板块 */}
<FormBlock ...>
  <FormFiledSet title="基本信息">
  </FormFiledSet>
  <FormFiledSet title="审核信息">
  </FormFiledSet>
</FormBlock>
...
```

#### 2.5. 填充维修申请板块业务字段

此步骤只要按设计稿迅速堆砌业务字段，使用近似的基础输入组件保证数据可以回显即可，后期再变更。

- **仅保证：** 字段在合理的（板块、字段集）位置、字段间排序正确、字段名`name`正确、字段标签`label`正确。
- **推荐：** 此步骤后，即已将表单业务数据确定下来了，可以通知后端开发人员同步数据首发及对接。

**业务数据格式**

```text
数据类型
{
  zcbh: '',
  ...
  shrq: '2022-10-10 10:20:30',
  ...
  zxxjqk: '',
  ...
  sffxpg: 1,
  ...
  yz: 1000,
  ...
  obj: {
    aa: ''
  },
  tables: [{
    bb: ''
  }]
}
```

- 在`FormBlock`、`FormFiledSet`组件中，输入`insertFormField`用户代码片段，快速[插入表单字段](/.vscode/插入表单字段.code-snippets)。
- 每个`FormItem`字段必须有`name`唯一键属性，用于和表单实例业务数据对应，可与上面的`业务数据格式`对比。
- 在与后端交互的数据时，时间类型转换为字符串、单选复选类型转化为数字。

```tsx
...
import { DatePicker, Input, InputNumber, Radio } from 'antd';
...
<FormFiledSet title="基本信息">
  <FormItem name="zcbh" label="资产编号">
    <Input />
  </FormItem>
  <FormItem name="zcmc" label="资产名称">
    <Input />
  </FormItem>
  <FormItem name="bmmc" label="部门名称">
    <Input />
  </FormItem>
  <FormItem name="bmbm" label="部门编码">
    <Input />
  </FormItem>
  <FormItem name="shrq" label="损害日期">
    <DatePicker />
  </FormItem>
  <FormItem name="zcqyrq" label="资产启用日期">
    <DatePicker />
  </FormItem>
  <FormItem name="zxxjqk" label="自行询价情况">
    <Input.TextArea rows={4} />
  </FormItem>
</FormFiledSet>
<FormFiledSet title="审核信息">
  <FormItem name="bmjl" label="部门经理">
    <Input />
  </FormItem>
  <FormItem name="wxjkr" label="维修接口人">
    <Input />
  </FormItem>
</FormFiledSet>
<FormItem name="sffxpg" label="是否风险评估">
  <Radio.Group>
    <Radio value={1}>是</Radio>
    <Radio value={2}>否</Radio>
  </Radio.Group>
</FormItem>
<FormItem name="yz" label="原值">
  <InputNumber />
</FormItem>
<FormItem name="jz" label="净值">
  <InputNumber />
</FormItem>
...
```

##### -------------这里有些重点知识-------------

**属性 name 的使用**

`name`的属性类型为`string | NamePath[]`。

- 即可以使用字符串对应数据源第一层数据

  ```tsx
  {
    zcbh: 'fangle',
    tables: [{
      bb: ''
    }]
  }

  // 数据与表单字段对应

  <FormItem name="zcbh"></FormItem>
  <FormItem name="tables"></FormItem>
  ```

- 也可以通过字符串数组对应多层级数据

  ```tsx
  {
    obj: {
      aa: 'fangle';
    }
  }

  // 数据与表单字段对应

  <FormItem name={['obj', 'aa']}></FormItem>;
  ```

**自动绑定 与 手动绑定 数据区别**

- 再强调一次！！！所有`FormItem`中子组件数据通过`FormItem`的 neme 属性绑定的，都不要配置`value`属性的具体值。

- 除非某些数据不需要提交到后端，仅在前端动态显示，如合计值。
- `FormItem`内仅包含一个子组件，这是 Ant Design 底层逻辑。需要多个可以参考`2.7.2.`用例定义。

```tsx
// 手动绑定数据，不与后端交互，不用配置name属性
// 需要显示的数据直接赋值输入框value属性
<FormItem label="原值">
  <InputNumber value={12345} />
</FormItem>
```

#### 2.6. 调整布局

目前界面显得很凌乱，我们要进行一次整体上的调整。优化字段的行、跨列等布局。使其更复合原型。

- `cols={1}`：`板块FormBlock`、`字段集FormFiledSet`容器组件上定义，容器内一行列数。
- `fill`： 当前`字段FormItem`、`字段集FormFiledSet`子组件占一行.
- `crossCol={2}`：当前`字段FormItem`、`字段集FormFiledSet`子组件跨列显示。
- `<FormFiledSet fill />`：特殊用法，可以作为分隔符使用。

```tsx
...
<FormFiledSet title="基本信息" fill>
...
  <FormItem name="zxxjqk" label="自行询价情况" fill>
  ...
<FormFiledSet title="审核信息" fill cols={1}>
...
</FormFiledSet>
<FormFiledSet fill />
<FormItem name="sffxpg" label="是否风险评估" crossCol={2}>
...
```

#### 2.7. 业务字段细节调整

将基础输入框改为原型对应的输入框或其它组件。

##### 2.7.1. 批量修改选择类组件

将选人、组织、公司、岗位等，统一替换为触发器输入框

```tsx
...
import { FC, useState } from 'react';
import { useFormContext } from '@/views/form/baseForm/stores/formContext';
import { UserDataType } from '@/stores/user';
import { DeptDataNode } from '@/stores/dept';

import Tigger from '@/views/form/baseForm/components/formFields/Trgger';
import ChoosePeople from '@/components/choose/ChoosePeople';
import ChooseDept from '@/components/choose/ChooseDept';
...
// 通过上下文获取表单form对象
const form = useFormContext();

// 操作部门弹窗
const [openDept, setOpenDept] = useState(false);
const onDeptOpen = () => {
  setOpenDept(true);
};
const onDeptCancel = () => {
  setOpenDept(false);
};
const onDeptChange = (data: DeptDataNode) => {
  form.setFieldValue('bmmc', data.title);
  form.validateFields(['bmmc']);
};

// 操作选人弹窗
const [openPeople, setOpenPeople] = useState(false);
const onPeopleOpen = () => {
  setOpenPeople(true);
};
const onPeopleCancel = () => {
  setOpenPeople(false);
};
const onPeopleChange = (data: UserDataType) => {
  const names: string[] = [];
  data.forEach((record) => {
    names.push(record.name.first);
  });
  form.setFieldValue('wxjkr', names.join(', '));
  form.validateFields(['wxjkr']);
};
...
<FormItem name="bmmc" label="部门名称">
  <Tigger placeholder="请选择部门" onTigger={onDeptOpen} />
</FormItem>
<ChooseDept open={openDept} onChange={onDeptChange} onCancel={onDeptCancel} crossCol={0} />
...
<FormItem name="wxjkr" label="维修接口人">
  <Tigger placeholder="请选择人员" onTigger={onPeopleOpen} />
</FormItem>
<ChoosePeople open={openPeople} onChange={onPeopleChange} onCancel={onPeopleCancel} crossCol={0} />
...
```

##### 2.7.2. 将 资产编号 组件改为组件组

- 修改`资产编号`字段，增加`有编号`、`无编号`选择按钮。
- 点击后弹出物料选择窗口。

Ant Design 在配置复合组件组时有点复杂，规则如下

- `FormItem`内仅有一个子组件，通过`Input.Group`扩展。
- 最外层的`FormItem`无需配置`name`
- 内部层`FormItem`配置`name="zcbh"`

```tsx
...
<FormItem label="资产编号">
  <Input.Group compact>
    <FormItem name="zcbh" style={{ width: 'calc(100% - 200px)' }}>
      <Input />
    </FormItem>
    <Button type="primary" style={{ width: 100 }}>
      有编号
    </Button>
    <Button type="primary" style={{ width: 100 }}>
      无编号
    </Button>
  </Input.Group>
</FormItem>
...
```

##### 2.7.3. 金额相关数字输入框，改为货币型输入框

```tsx
...
<FormItem name="yz" label="原值">
  <InputNumber
    formatter={(value) =>
      `￥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
    parser={(value) => value!.replace(/￥\s?|(,*)/g, '')}
  />
</FormItem>
<FormItem name="jz" label="净值">
  <InputNumber
    formatter={(value) =>
      `￥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
    parser={(value) => value!.replace(/￥\s?|(,*)/g, '')}
  />
</FormItem>
...
```

#### 2.8. 表单提交校验规则

界面完成后，对于表单必填项等进行调整，达到预期的业务数据完整性。

- 在`FormItem`中直接加`required`，仅用于显示必填信号，不作为验证规则。
- 在`FormItem`中配置`rules`验证规则，才会执行验证校验。

```tsx
...
<FormItem label="资产编号" required>
  <Input.Group compact>
    <FormItem
      name="zcbh"
      style={{ width: 'calc(100% - 200px)', marginBottom: 0 }}
      rules={[
        {
          required: true,
          message: '请选择资产编号',
        },
      ]}
    >
...
<FormItem
  name="bmmc"
  label="部门名称"
  rules={[
    {
      required: true,
      message: '请选择部门',
    },
  ]}
>
...
```

**显示更丰富的字段组件**

参考`Ant Design UI库`([https://ant.design/components/overview-cn/](https://ant.design/components/overview-cn/))

### 3. 至此我们的新表单就开发完成了，最后把表单挂在到路由上

打开`router/index.tsx`表单路由配置文件([@/router/index.tsx](/src/router/index.tsx))

#### 3.1. 挂载维修申请表单到维修分类中

先将做好的维修申请表单，挂载到懒加载目录列表中。

- `repairViews` 挂载维修分类表单目录
- `RepairRequest` 表单别名，用于路由加载时使用
- `lazy` 懒加载表单，对应实际表单组件

```tsx
...
/** 维修分类 */
const repairViews: LazyFormViews = {
  RepairRequest: lazy(() => import('@/views/form/repair/RepairRequestView')),
};
...
```

#### 3.2. 将维修表单注册到 repair/RepairRequest 路由中

将懒加载目录注册到指定路由节点中

- `path: 'repair/:formName',` 用于定义多级路由名。可任意字符串，大小写敏感
- `views={repairViews}` 挂载的表单列表

```tsx
...
id: 'formRoot', // id用于在上下文间获取loader方法返回的数据，见const { formSet, formData } = useFormData();
loader: formLoader,
errorElement: <ErrorView title="表单路由异常" />,
path: '/',
children: [
  {
    path: 'repair/:formName',
    element: <FormRouterIndex views={repairViews} />,
  },
  ...
```

---

### 4. 使用表单

**通过以下地址打开我们之前创建的`维修申请`表单**

- 新发起表单： [http://localhost:281/repair/RepairRequest](http://localhost:281/repair/RepairRequest)
- 查看表单： [http:/localhost:281/repair/RepairRequest/?procInstId=xxx](http://localhost:281/repair/RepairRequest/?procInstId=xxx)
- 审批表单： [http:/localhost:281/repair/RepairRequest/?sn=xxx&procInstId=xxx](http://localhost:281/repair/RepairRequest/?sn=xxx&procInstId=xxx)

**注：表单路由名大小写敏感。form/xxx <> form/Xxx**

---

## 4. 现在能跑表单？不！我们还要考虑几个问题

- 表单数据哪来？
- 表单操作怎么执行？
- 审批历史记录数据哪来？
- 平台基础数据如何对接？

### 现在我们准备一些服务端 API

这些都是[表单通用 API](/src/tests/test.http)，通过不同`请求参数`获取后台业务数据，以下是接口定义。

#### 4.1. 根据 ID 获取表单配置和数据

通过以下 4 个 ID 的不同组合来获取`表单配置`和`表单数据`。

- 新发起页面，仅通过 formId (或表单二级路由名)来获取表单初始值。
- 审批页面，通过 sn 来获取审批任务表单副本数据。
- 查看历史表单页面，通过传 procInstId 来获取。
- 希望查询更精确的历史数据，需要联合 destInstId、sn。

```http
###region 获取表单数据
GET http://xxx/api/form/
// request data:
  ?formId=xxx
  &sn=
  &destInstId=
  &procInstId=

// response data:
//   参见: @/views/form/stores/formStore.ts下的FormInfo类型定义
###endregion
```

打开`formService.ts`这个表单业务逻辑文件([@/views/form/services/formService.ts](/src/views/form/services/formService.ts))

需要在`LoadFormData`中写入异步服务端请求。

```ts
...
export const LoadFormData = async (url: URL) => {
  //所有表单相关id
  const ids = {
    formId: url.searchParams.get('formId') ?? '',
    sn: url.searchParams.get('sn') ?? '',
    destInstId: url.searchParams.get('destInstId') ?? '',
    procInstId: url.searchParams.get('procInstId') ?? '',
  };
  /* 这里写入异步服务端数据请求，并返回 */
  /**
   * 获取表单配置与数据异步服务端数据请求
   * 如，同意、拒绝等
   * GET http://xxx/form
   * request data
   * {
   *   formId,
   *   sn,
   *   destInstId,
   *   procInstId,
   * }
   * response data
   * {
   *   formSet: {
   *     formId,
   *     sn,
   *     destInstId,
   *     procInstId,
   *     formViewStatus: 'launch',
   *   }
   *   formData: {
   *     usname: 'fangle',
   *     usemail: 'xxx@xxx.com',
   *     usphone: '13917629685',
   *   }
   * }
   */
  return ...
};
...
```

`formSet`表单数据格式中`表单配置部分`，[参见 formStore.ts 文件中的`FormSetConfig`类型定义](/src/views/form/baseForm/stores/formStore.ts)。
| 属性名 | 描述|数据类型|注意事项|
|---|---|---|---|
|formId |表单定义号 |`string`|根据实际情况必选|
|sn |任务号 |`string`|根据实际情况必选|
|destInstId |任务实例号| `string`|根据实际情况必选|
|procInstId |流程实例号 |`string`|根据实际情况必选|
|formViewStatus|表单视图状态<br>- `'launch'` 发起视图<br>- `'approval'` 审批视图<br>- `'view'` 查看视图<br>- `'print'` 打印视图<br>- `任意字符串` 自定义视图|`FormViewStatus`|`必要参数`|
|currentStage?| 当前处理环节| `string`||
|header?|表单标题|`string`| |
|actionPosition? |操作列表显示位置<br>- `'top'` 居顶<br>- `'bottom'` 居底| `ActionsPosition`|默认值`top`|
|actions? |当前步骤可操作的所有行为 |`FormActionType[]`| |
|formCompTree? |表单组件树结构 |`FormCompTree`|存放表格的列配置定义，参考`ChargeDetailsBlock`用例。|
|enableProcInstLogs? |启用流转记录 |`boolean`|默认值`true`|

#### 4.2. 执行表单`通用`、`自定义`操作行为

所有表单的 action 的执行逻辑都在后台处理，前端只需要抛出当前表单业务数据，并接收成功或失败。

```http
###region 执行action
POST http://xxx/api/form/action HTTP/1.1
content-type: application/json
// request data:
{
    "formId",
    "sn",
    "destInstId",
    "procInstId",
    "action": "",
    "formdata": {},
    "comment": {}
}

// response data:
//   成功、失败
###endregion
```

打开`formService.ts`这个表单业务逻辑文件([@/views/form/services/formService.ts](/src/views/form/services/formService.ts))

需要在`executeFormAction`中写入异步服务端请求。

```ts
...
export const executeFormAction = async (action: string, formData: FormInfo) => {
  switch (action) {
    case 'xxx':
      /* 表单自定义的操作可以在这里请求不同服务端API */
      break;
    default:
      /**
       * 所有表单通用ACTION异步服务端数据请求
       * 如，同意、拒绝等
       * POST http://xxx/form/action
       * request data
       * {
       *   action,
       *   formdata: formData.formData,
       * }
       */
      break;
  }
};
...
```

#### 4.3. 获取审批历史记录

通过流程实例号（procInstId），来获取流程实例的流转记录。

```http
###region 获取审批历史记录
GET http://xxx/api/form/approvalHistory
// request data:
  ?procInstId=xxx

// response data:
//   参见: @/stores/approvalHistory.ts下的ApprovalHistoryType类型定义
###endregion
```

打开`approvalHistory.ts`这个业务逻辑文件([@/services/approvalHistory.ts](/src/services/approvalHistory.ts))

需要在`getApprovalHistory`中写入异步服务端请求。

```ts
...
export const getApprovalHistory = async (procInstId: string) => {
  /**
   * 审批历史记录异步服务端请求
   * GET http://xxx/form/approvalHistory
   * request data
   * {
   *   procInstId,
   * }
   */
};
...
```

#### 4.4. 获取组织树

获取组织树

```http
###region 获取审批历史记录
GET http://xxx/api/organization/
// request data: 可选
  ?pid=xxx

// response data:
//   参见: @/stores/dept.ts下的DeptDataNode类型定义
###endregion
```

打开`dept.ts`这个业务逻辑文件([@/services/dept.ts](/src/services/dept.ts))

需要在`getApprovalHistory`中写入异步服务端请求。

```ts
...
export const getDepts = async (procInstId: string) => {
  // 异步调用后台接口
};
...
```

#### 4.5. 获取人员列表

根据部门获取人员列表

```http
###region 获取人员列表
GET http://xxx/api/user/
// request data: 可选
  ?deptId=xxx

// response data:
//   参见: @/stores/user.ts下的UserDataType类型定义
###endregion
```

打开`user.ts`这个业务逻辑文件([@/services/user.ts](/src/services/user.ts))

需要在`getUsersByDept`中写入异步服务端请求。

```ts
...
export const getUsersByDept = async (deptId: string | number) => {
  // 异步调用后台接口
};
...
```

---

## 更丰富的表单

### 自定义主题

参见[样式修改](/docs/theme.md)

### 业务需要代申请，如何处理？

**将表单中申请人替换为`人员选择`**

```tsx
...
// 人员选择
import ChoosePeople from '@/components/choose/ChoosePeople';
import { UserDataType } from '@/stores/user';
...
const XxxView: FC = () => {
  ...
  // 通过上下文获取表单form对象
  const form = useFormContext();
  // 操作弹窗
  const [openPeople, setOpenPeople] = useState(false);
  const onPeopleOpen = () => {
    setOpenPeople(true);
  };
  const onPeopleCancel = () => {
    setOpenPeople(false);
  };
  const onPeopleOk = (data: UserDataType) => {
    const names: string[] = [];
    data.forEach((record) => {
      names.push(record.name.first);
    });
    form.setFieldValue('usname', names.join(', '));
    form.validateFields(['usname']);
  };
  ...
  return (
    <FormBlock ...>
      ...
      <FormItem
        name="usname"
        label="申请人"
        rules={[
          {
            required: true,
            message: '请选择人员',
          },
        ]}
      >
        <Tigger placeholder="请选择人员" onTigger={onPeopleOpen} />
      </FormItem>
      ...
      <ChoosePeople open={openPeople} onOk={onPeopleOk} onCancel={onPeopleCancel}></ChoosePeople>
    </FormBlock>
  );
  ...
};
...
```

**再将申请部门替换为`部门选择`**

```tsx
...
// 部门选择
import ChooseDept from '@/components/choose/ChooseDept';
import { DeptDataNode } from '@/stores/deps';
...
const XxxView: FC = () => {
  ...
  // 通过上下文获取表单form对象
  const form = useFormContext();
  // 操作弹窗
  const [openDept, setOpenDept] = useState(false);
  const onDeptOpen = () => {
    setOpenDept(true);
  };
  const onDeptCancel = () => {
    setOpenDept(false);
  };
  const onDeptOk = (data: DeptDataNode) => {
    form.setFieldValue('usdept', data.name.first);
    form.validateFields(['usdept']);
  };
  ...
  return (
    <FormBlock ...>
      ...
      <FormItem
        name="usdept"
        label="申请部门"
        rules={[
          {
            required: true,
            message: '请选择部门',
          },
        ]}
      >
        <Tigger placeholder="请选择部门" onTigger={onDeptOpen} />
      </FormItem>
      ...
      <ChooseDept open={openDept} onOk={onDeptOk} onCancel={onDeptCancel}></ChooseDept>
    </FormBlock>
  );
  ...
};
...
```

### 优化界面，分组信息

一个板块信息量过大的优化处理方案：

- 拆分成多个板块（Block）显示。（推荐）
  多组关联不强的重要数据。
- 板块内分成多个字段集（FieldSet）显示。
  多组关联性强的重要数据。

  ```tsx
  // 代申请
  ...
  <FormBlock ...>
    <FormFiledSet title="发起人信息">
      <FormItem ...>
      ...
      </FormItem>
    </FormFiledSet>
    <FormFiledSet title="申请人信息">
      <FormItem ...>
      ...
      </FormItem>
    </FormFiledSet>
  </FormBlock>
  ...
  ```

- 通过标签页切分显示。（不建议）
  多组关联不强且不重要非必填数据。

如表单整体信息量过大，需要考虑是否是一支流程或一个表单应该承受的！

---

## 高阶场景

### 泛型组件

当组件被引用前不确定数据类型时，可以使用泛型组件，延迟事件数据类型推断。

此时不能使用`FC`来定义组件

```tsx
interface Props<T> {
  items: T[];
}

const Components = <T extends object>({ items }: Props<T>) => {
  return <></>;
};
```

```tsx
<Components<string> items=['a','b'] />
```

### 非表单组件如何与数据绑定

**方案一：在板块中，自行通过监听生命周期或事件操作数据**

参考之后章节：[操作其它板块数据]()

**方案二：二次封装组件，使其支持表单自动赋值与取值**

只要封装两个组件属性即可：

```tsx
...
interface Props {
  /** form.item组件写表格数据 */
  value?: string;
  /** form.item组件读表格数据 */
  onChange?: (value: string) => void;
}
...
```

**高阶用例：**
可编辑表格（泛型组件），表单可以自动读写数据

```tsx
...
import { JsonStore } from '@/utils';
...
interface Props<T = JsonStore> {
  /** form.item组件写表格数据 */
  value?: T[];
  /** form.item组件读表格数据 */
  onChange?: (value: T[]) => void;
  ...
}
...
const FormEditorTable = <T extends object>(props: Props<T>) => {
  ...
  // 表格数据状态
  const [dataSource, setDataSource] = useState(props.value);
  return (
    <>
      <Button
        onClick={() => {
          ...
          const newData = [{ a: 1, ... }];
          setDataSource(newData);
          if (props.onChange) {
            props.onChange(newData);
          }
          ...
        }}
      >
        变更
      </Button>
      <Table dataSource={dataSource} columns={columns} pagination={false} />
    </>
  );
};
...
```

方案一：数据格式为默认`JsonStore`数组

```tsx
<Form.Item noStyle name="tables">
  <FormEditorTable columns={columns}></FormEditorTable>
</Form.Item>
```

方案 2：数据格式为指定类型`iUser`数组

```ts
interface iUser {
  id: string;
  name: string;
}
```

```tsx
<Form.Item noStyle name="tables">
  <FormEditorTable<iUser> columns={columns}></FormEditorTable>
</Form.Item>
```

### 操作其它板块数据

表单组件使用`useFormContext()`获取表单对象

```tsx
...
import { useFormContext } from '@/layouts/form/FormLayout';
import { useFormData } from './services/formService';
...
const XxxView: FC = () => {
  ...
  // 获取表单初始值
  const { formSet, formData } = useFormData();

  // 获取表单form对象
  const form = useFormContext();

  // 获取表单最新值
  const currFormData = form.getFieldsValue();
  ...
  return (
    <FormBlockSet ...>

    </FormBlockSet>
  );
};
...
```

板块组件使用`Form.useFormInstance()`获取表单对象

```tsx
...
import { useFormData } from './services/formService';
...
const XxxBlock: FC<FormPanelProps> = (props) => {
  ...
  // 获取表单初始值
  const { formSet, formData } = useFormData();

  // 获取表单form对象
  const form = useFormContext();

  // 获取表单最新值
  const currFormData = form.getFieldsValue();
  ...
  return (
    <FormBlock ...>

    </FormBlock>
  );
};
...
```

### 可复用板块封装

如一组相同字段在多处表单中出现，可以通过封装板块（Block）的方式复用。

参见[可复用的组件封装](./components/blocks/README.md)说明

---

[返回主页](/README.md)
