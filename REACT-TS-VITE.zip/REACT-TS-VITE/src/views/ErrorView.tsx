import { FC } from 'react';
import { useRouteError } from 'react-router-dom';

declare interface RouteErrorEvent extends ErrorEvent {
  readonly statusText: string;
}

const ErrorView: FC<{ title?: string }> = ({ title }) => {
  const error = useRouteError() as RouteErrorEvent;
  if (error) console.error(error);

  return (
    <div id="error-view">
      <h1>{title ?? '错误'}!</h1>
      <p>Sorry, an unexpected error has occurred.</p>
      <p>
        <i>{error ? error.statusText || error.message : ''}</i>
      </p>
    </div>
  );
};
export default ErrorView;
