import { FC } from 'react';
import { useTranslation } from 'react-i18next';

/**
 * 关于页面
 * @returns 返回页面
 */
const AboutView: FC = () => {
  // 多语言
  const { t } = useTranslation();

  return (
    <div>
      <h3>{t('about.content')}</h3>
      <div>关于页面</div>
    </div>
  );
};
export default AboutView;
