import LocalStorage from '@/utils/localStore';
import { Button } from 'antd';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';

interface Props {
  /**
   * 是否显示第三方登录验证板块
   */
  thirdPartyAuth: boolean;
}
/**
 * 登录页面
 * @param thirdPartyAuth 是否启用第三方登录验
 * @returns 返回登录页面
 */
const LoginView: FC<Props> = ({ thirdPartyAuth }) => {
  // 多语言
  const { t } = useTranslation();
  // const [count, setCount] = useState(0);
  const handleLogin = async () => {
    // [待处理]登录并保存token
    // const response = await login();

    const response = {
      token: 'fangjing24@gmail.com',
    };
    // 存储 token, 过期时间 10000 秒
    await LocalStorage.set('token', response.token, 10000);
    window.history.back();
  };

  return (
    <div>
      <h3>{t('login.content')}</h3>
      {/* <Button onClick={() => setCount((count) => count + 1)}>
        count is {count}
      </Button> */}
      <Button type="primary" onClick={handleLogin}>
        登录(有效期10000秒)
      </Button>

      <div>
        {thirdPartyAuth ? '启用第三方登录验证' : '不启用第三方登录验证'}
      </div>
    </div>
  );
};
export default LoginView;
