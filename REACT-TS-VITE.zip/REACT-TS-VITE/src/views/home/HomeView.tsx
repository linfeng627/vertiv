import { FC } from 'react';
import { useTranslation } from 'react-i18next';

/**
 * 演示页面
 * @returns 返回演示页面
 */
const HomeView: FC = () => {
  // 多语言
  const { t } = useTranslation();

  return (
    <div>
      <h3>{t('home.content')}</h3>
      <div>主页</div>
    </div>
  );
};
export default HomeView;
