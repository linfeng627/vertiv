# 样式规范

## Ant Design 变量参考

**基础颜色变量参考**

[~antd\es\style\color\colors.less](https://github.com/ant-design/ant-design/blob/master/components/style/color/colors.less)

**变量名参考**

[~antd\es\style\themes\default.less](https://github.com/ant-design/ant-design/blob/master/components/style/themes/default.less)

**变量修改**

[`antd.reset.less`存放修改 antd 全局变量](/src/assets/styles/antd.reset.less)

```less
// [antd.reset.less]
// 替换ant所有样式前缀为nbl
@ant-prefix: nbl;
```

## LESS Module/CSS Module（防样式污染）

需要防止组件样式污染的场景中，可以使用`LESS Module`模式。

- 样式文件名以`.module.[css|less|scss]`结尾。
- 编译时自动将文件中`样式名`按规则替换为`唯一Key`。
  - 也可以在样式中使用`:global`伪类来指定部分样式不被替换样式名。
- 样式模块默认名导入后，通过默认名引出样式名。

### 启用 LESS Module，定义替换规则

```ts
// [vite.config.ts]
...
css: {
  // CSS模块化文件以.module.[css|less|scss]结尾
  modules: {
    /**
     * 样式名替换规则
     * 参数：
     * [name]：less模块名
     * [local]：替换的样式名
     * [hash:base64:5]：5位随机hash值
     *
     * 用例：替换FormView.module.less文件中.demo-form样式名位唯一键
     * 规则：[name]__[local]___[hash:base64:5]
     * 结果：FormView-module__demo-form___MJy-e
     */
    generateScopedName: '[name]__[local]___[hash:base64:5]',
    hashPrefix: 'prefix',
  },
  ...
},
...
```

### 使用 LESS Module

```less
// [FormView.module.less]
// 使用LESS Module防止样式污染，通过两层固定格式定义。
// 第一层定义组件主样式（主样式名在编译时自动按规则替换为唯一key）
.demo-form {
  // 第二层使用:global伪样式，用以确保其内所有样式名不会被自动替换
  :global {
    // 以上为[固定格式]
    // 以下样式为自定义样式
    ...
    color: red;
    .form-4444 {
      color: black;
    }
  }
}
```

```tsx
// [FormView.tsx]
// 样式模块默认导入
import styles from './FormView.module.less';
...
// 可通过智能感知`styles.`选择主样式。样式名带非字符会自动使用[]引用。
<div className={styles['demo-form']}>
  <div className="form-4444">
    123
  </div>
</div>
...
```

### 编译后结果

```html
// [FormView.html]
<style>
  .FormView-module__demo-form___MJy-e {
    color: red;
  }
  .FormView-module__demo-form___MJy-e .form-4444 {
    color: black;
  }
</style>
...
<div class="FormView-module__demo-form___MJy-e">
  <div class="form-4444">123</div>
</div>
...
```

---

[返回表单开发](/docs/theme.md)
