import { FC } from 'react';

// 可根据环境变量的配置来决定是否倒导入mock数据
import '@/mock/mockData';
import RouterIndex from '@/router/index';

// 应用样式，放在最后，防止被插件样式污染
import '@/App.less';

import { ConfigProvider } from 'antd';
/**
 * @description 将 vite 的原始环境变量转成正确的类型
 * @param env 原始的 vite 环境变量
 * @returns 转换成正确类型的 vite 环境变量
 */
export const useEnv = (env: ImportMetaEnv): ImportMetaEnv => {
  const ret: any = {};

  for (const envKey of Object.keys(env)) {
    let envValue = env[envKey];

    // 转成正确的布尔类型
    envValue =
      envValue === 'true' ? true : envValue === 'false' ? false : envValue;

    // VITE_PORT 转成 number
    if (envKey === 'VITE_PORT') {
      envValue = parseInt(envValue);
    }

    ret[envKey] = envValue;
  }

  return ret;
};

const App: FC = () => {
  // vite Environment Variables环境变量-定义全局常量替换方式
  // https://cn.vitejs.dev/config/shared-options.html#define
  // console.log('appName:', appName);

  // prefixCls="nbl" 修改antd组件样式前缀
  // autoInsertSpaceInButton={false} 去除在两个中文字间添加空格
  return (
    <div className="App">
      <ConfigProvider prefixCls="nbl" autoInsertSpaceInButton={false}>
        <RouterIndex />
      </ConfigProvider>
    </div>
  );
};

export default App;

// import { FC, useEffect, useState } from 'react';
// import reactLogo from '@/assets/react.svg';
// import antdLogo from '@/assets/antd.svg';
// import '@/App.less';

// import RouterList from '@/router/index';
// import { BrowserRouter as Router, Link } from 'react-router-dom';

// import i18n, { type elocaleType, elLangs } from '@/utils/i18n';
// import moment from 'moment';
// import { useTranslation } from 'react-i18next';
// import { ConfigProvider } from 'antd';

// const App: FC = () => {
//   //#region 使用多语言
//   //代码可能还需要简化
//   const { t } = useTranslation();
//   const [language, setLanguage] = useState('');
//   const [locale, setLocale] = useState<elocaleType>();
//   const changeLanguage = (lang: string) => {
//     moment.locale(lang);
//     setLanguage(lang);
//     setLocale(elLangs[lang]);
//     i18n.changeLanguage(lang);
//   };
//   useEffect(() => {
//     const lang = localStorage.getItem('i18nextLng');
//     if (lang) {
//       changeLanguage(lang.toLocaleLowerCase());
//     }
//   }, []);
//   //#endregion

//   return (
//     <div className="App">
//       <ConfigProvider locale={locale}>
//         <Router>
//           <nav className="mainNav">
//             <Link to="/login">{t('login.title')}</Link>
//             <Link to="/">{t('about.title')}</Link>
//             <a href="/form" target="_blank">
//               表单
//             </a>
//             {/* <Link to="/form" target="_blank">
//               表单
//             </Link> */}
//             <select
//               value={language}
//               onChange={(e) => changeLanguage(e.target.value)}
//             >
//               <option value="zh-cn">简体中文</option>
//               <option value="en-us">English</option>
//             </select>
//           </nav>
//           <div>
//             <a href="https://vitejs.dev" target="_blank" rel="noreferrer">
//               <img src="/vite.svg" className="logo" alt="Vite logo" />
//             </a>
//             <a href="https://reactjs.org" target="_blank" rel="noreferrer">
//               <img src={reactLogo} className="logo react" alt="React logo" />
//             </a>
//             <a href="https://ant.design" target="_blank" rel="noreferrer">
//               <img src={antdLogo} className="logo" alt="Ant Design logo" />
//             </a>
//           </div>
//           <h1>Vite + React + Ant Design</h1>
//           <RouterList />
//         </Router>
//       </ConfigProvider>
//     </div>
//   );
// };

// export default App;
