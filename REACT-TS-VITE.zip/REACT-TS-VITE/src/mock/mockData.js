import Mock from 'mockjs';

/**
 *人员数据
 */
export const userlist = Mock.mock(/\/api\/userlist/, 'get', {
  'data|1-10': [
    {
      id: '@guid',
      gender: '@pick(["male","female","secret"])',
      name: {
        first: '@first',
        last: '@last',
      },
      date: '@datetime',
      cname: '@cname',
      address: '@url',
      picture: {
        large: '@image',
        medium: '@image',
        thumbnail: '@image',
      },
      email: '@email',
      text: Mock.Random.cword(5, 20),
    },
  ],
  code: 200,
  message: '请求数据成功',
});

/**
 * 部门数据
 */
export const deptlist = Mock.mock(/\/api\/deptlist/, 'get', {
  'data|1-10': [
    {
      title: Mock.Random.cword(3, 8),
      key: '@guid',
      'isLeaf|1': true,
      'children|1-10': {
        title: Mock.Random.cword(3, 8),
        key: '@guid',
        'isLeaf|1-2': true,
      },
    },
  ],
  code: 200,
  message: '请求数据成功',
});

/**
 * 资产明细
 */
export const assetDetailList = Mock.mock(/\/api\/getAssetDetails/, 'get', {
  'data|1-10': [
    {
      key: '@guid',
      /**序号 */
      num: '@guid',
      /**资产编号 */
      code: '@string("upper", 5)',
      /**资产名称 */
      name: '@ctitle(3, 5)',
      /**使用人姓名 */
      username: '@cname',
      /**使用人工号 */
      usercode: '@string("upper", 5)',
      /**部门名称 */
      deptname: '@cword(2,5)',
      /**部门代码 */
      deptcode: '@string("upper", 3)',
      /**附属物品 */
      attachedItems: '@cword(2,5)',
      /**存放位置 */
      address: '@county(true)',
      /**产品段 */
      productname: '@string("upper", 3)',
    },
  ],
  code: 200,
  message: '请求数据成功',
});

/**
 * 资产转移电子流
 */
export const getFormData = Mock.mock(
  /\/api\/CapitalTransfer\/GetFormData/,
  'get',
  {
    data: {
      formSet: {
        formId: '@integer(10000, 999999)',
        procInstId: '@datetime("yyyyMMddHHmmss")',
        // activityName: '@cword(3, 8)',
        activityName: '000',
        procStatus: '@pick(["Start", "草稿", "审批中", "已完成"])',
        approver: '@integer(10000, 999999)  @cname',
      },
      formData: {
        computerOrSoftware: Mock.Random.boolean(),
        companyType: 'Closed', //Mock.Random.upper(Mock.Random.string(3)),
        outDept: {
          /**使用人ID */
          userID: '@name',
          /**部门名称(大部门) */
          deptName: '@cword(3)',
          /**部门编码 */
          deptCode: '@string("upper",5)',
          /**部门名称(小部门) */
          deptName2: '@cword(2,5)',
          /**转移原因 */
          leaveTransfer: Mock.Random.boolean(),
          /**PC数据清理确认 */
          pCDataClear: '@cword(8,15)',
          /**转出部门一级资产管理员 */
          firstAdmin: '@cname',
          /**转出部门主管 */
          manager: '@cname',
          /**转出资产所缺配件 */
          sparepart: '@cword(5,10)',
        },
        inputDept: {
          /**使用人ID */
          userID: '@name',
          /**部门名称(大部门) */
          deptName: '@cword(3)',
          /**部门编码 */
          deptCode: '@string("upper",5)',
          /**部门名称(小部门) */
          deptName2: '@cword(2,5)',
          /**转入部门一级资产管理员 */
          firstAdmin: '@cname',
        },
        'assetDetail|1-10': [
          {
            key: '@guid',
            /**序号 */
            num: '@increment',
            /**资产编号 */
            code: '@string("upper", 5)',
            /**资产名称 */
            name: '@ctitle(3, 5)',
            /**使用人姓名 */
            username: '@cname',
            /**使用人工号 */
            usercode: '@string("upper", 5)',
            /**部门名称 */
            deptname: '@cword(2,5)',
            /**部门代码 */
            deptcode: '@string("upper", 3)',
            /**附属物品 */
            attachedItems: '@cword(2,5)',
            /**存放位置 */
            address: '@county(true)',
            /**产品段 */
            productname: '@string("upper", 3)',
          },
        ],
        capitalTransferRemark: '@ctitle(20,50)',
        'uploadFiles|1-5': [
          {
            uid: '@id',
            name: '@ctitle(5)',
            size: '@integer(50, 1000)',
            status: '@pick(["上传成功", "上传失败"])',
            url: '@url',
          },
        ],
      },
    },
    code: 200,
    message: '请求数据成功',
  },
);

/**
 * 获取表单审批历史记录
 */
export const getApprovalHistory = Mock.mock(/\/api\/ApprovalHistory/, 'get', {
  'data|2-10': [
    {
      key: '@guid',
      activityName: '@cword(3, 8)',
      approver: '@integer(10000, 999999)  @cname',
      action: '@pick(["提交", "同意", "退回", "作废"])',
      date: '@datetime("yyyy-MM-dd HH:mm:ss")',
      reamrk: '@ctitle(10,30)',
    },
  ],
  code: 200,
  message: '请求数据成功',
});

/**
 * 获取附件列表
 */
export const getAttachmentList = Mock.mock(/\/api\/AttachmentList/, 'get', {
  'data|2-10': [
    {
      uid: '@id',
      key: '@guid',
      fileName: '@cword(5, 15)',
      fileSize: '@integer(10000, 999) @pick(["kb", "MB"])',
      fileType: '@pick(["doc", "pdf", "xls", "ppt"])',
      date: '@datetime("yyyy-MM-dd HH:mm:ss")',
      activityName: '@cword(3, 8)',
      userName: '@integer(10000, 999999)  @cname',
    },
  ],
  code: 200,
  message: '请求数据成功',
});

/**
 * 获取数据字典树数据
 */
export const getDictionaryList = Mock.mock(
  /\/api\/DataDictionary\/GetDictTree/,
  'get',
  {
    'data|2-10': [
      {
        key: '@guid',
        title: '@ctitle(3,7)',
        isLeaf: '@pick(true,false)',
        'children|1-5': [
          {
            key: '@guid',
            title: '@ctitle(3,7)',
            isLeaf: '@pick(true,false)',
          },
        ],
      },
    ],
    code: 200,
    message: '请求数据成功',
  },
);

/**
 * 获取数据字典项
 */
export const getDictItems = Mock.mock(
  /\/api\/DataDictionary\/GetDictItems/,
  'get',
  {
    'data|5-35': [
      {
        key: '@guid',
        itemKey: '@string("upper",5)',
        itemValue: '@word(3(3,10)',
        itemName: '@name',
        remark: '@ctitle(5,20)',
        startTime: '@datetime("yyyy-MM-dd HH:mm:ss")',
        endTime: '@datetime("yyyy-MM-dd HH:mm:ss")',
      },
    ],
    code: 200,
    message: '请求数据成功',
  },
);
