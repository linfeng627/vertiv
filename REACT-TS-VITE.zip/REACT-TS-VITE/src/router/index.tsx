//#region 导入
import { FC, lazy, Suspense } from 'react';
import {
  createBrowserRouter,
  createHashRouter,
  RouteObject,
  RouterProvider,
} from 'react-router-dom';

import { loader as formLoader } from '@/views/form/baseForm/services/formService';
import FormRouterIndex, { LazyFormViews } from './formRouter';

const MainLayout = lazy(() => import('@/layouts/main/MainLayout'));
const HomeView = lazy(() => import('@/views/home/HomeView'));
const AboutView = lazy(() => import('@/views/AboutView'));
const ErrorView = lazy(() => import('@/views/ErrorView'));
const LoginView = lazy(() => import('@/views/LoginView'));

//#endregion

//#region 表单列表分组
/** demo类 */
const demoViews: LazyFormViews = {
  FormView: lazy(() => import('@/views/form/demo/FormView')),
  Form2View: lazy(() => import('@/views/form/demo/Form2View')),
};
/** 差旅类 */
const tripViews: LazyFormViews = {
  TandEView: lazy(() => import('@/views/form/trip/TandEView')),
};

/** 资产管理 */
const assetManagementViews: LazyFormViews = {
  TransferView: lazy(
    () =>
      import('@/views/form/assetManagement/transferView/CapitalTransferView'),
  ),
  CompensateView: lazy(
    () =>
      import(
        '@/views/form/assetManagement/compensateView/CapitalCompensateView'
      ),
  ),
  ScrapView: lazy(
    () => import('@/views/form/assetManagement/scrapView/CapitalScrapView'),
  ),
  RepairView: lazy(
    () => import('@/views/form/assetManagement/repairView/CapitalRepairView'),
  ),
};
/** 数据字典 */
const dataDictManagementViews: LazyFormViews = {
  DictView: lazy(() => import('@/views/form/dataDictionary/DictView')),
};
//#endregion

/**
 * 根据环境变量定义，配置路由模式
 *
 * 路由模式：HTML5（{webroot}/xxx/yyy） or HASH（{webroot}/#xxx/yyy）
 */
function createRouter(props: RouteObject[]) {
  if (import.meta.env.VITE_APP_HISTORY_MODEL == 'HTML5') {
    return createBrowserRouter(props);
  } else {
    return createHashRouter(props);
  }
}
/**
 * 定义嵌套路由表
 */
const router = createRouter([
  //#region 其它路由
  {
    path: 'login',
    errorElement: <ErrorView title="登录异常" />,
    element: <LoginView thirdPartyAuth={false} />,
  },
  {
    id: 'mainRoot',
    path: '/',
    errorElement: <ErrorView title="平台异常" />,
    element: <MainLayout />,
    children: [
      {
        children: [
          {
            index: true,
            element: <HomeView />,
          },
          {
            path: 'about',
            element: <AboutView />,
          },
        ],
      },
    ],
  },
  //#endregion
  //#region 表单路由多级分组
  {
    id: 'formRoot', // id用于在上下文间获取loader方法返回的数据，见const { formSet, formData } = useFormData();
    loader: formLoader,
    errorElement: <ErrorView title="表单路由异常" />,
    path: '/',
    children: [
      {
        path: 'form/demo/:formName',
        element: <FormRouterIndex views={demoViews} />,
      },
      {
        path: 'trip/:formName',
        element: <FormRouterIndex views={tripViews} />,
      },
      {
        path: 'form/assetManagement/:formName',
        element: <FormRouterIndex views={assetManagementViews} />,
      },
      {
        path: 'Management/:formName',
        element: <FormRouterIndex views={dataDictManagementViews} />,
      },
    ],
  },
  //#endregion
]);

/**
 * 路由配置
 * 根据一级路由，进入不同Layout
 * / -> MainLayout
 * @returns 路由列表页面
 */
const RouterIndex: FC = () => {
  return (
    <Suspense fallback={<div className="nbl-loading">Loading...</div>}>
      <RouterProvider router={router} />
    </Suspense>
  );
};
export default RouterIndex;
