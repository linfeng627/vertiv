//#region 导入
import { FC, LazyExoticComponent } from 'react';
import { useParams } from 'react-router-dom';
import FormLayout from '@/layouts/form/FormLayout';

/** 懒加载表单视图列表类型 */
export type LazyFormViews = Record<string, LazyExoticComponent<FC>>;

/** 组件属性 */
interface Props {
  /** 懒加载表单视图列表 */
  views: LazyFormViews;
}
/**
 * 表单路由
 * @returns 返回表单主布局
 */
const FormRouterIndex: FC<Props> = ({ views }) => {
  //获取路由表单名
  const { formName } = useParams();

  const ShowView = views[formName ?? ''];

  // 通过二级路由加载表单主体部分
  return (
    <FormLayout>
      <ShowView />
    </FormLayout>
  );
};
export default FormRouterIndex;
