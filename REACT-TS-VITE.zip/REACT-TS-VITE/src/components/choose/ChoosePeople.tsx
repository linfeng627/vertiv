//#region 导入
import {
  forwardRef,
  Key,
  memo,
  ReactElement,
  useCallback,
  useEffect,
  useState,
} from 'react';
import { getDepts } from '@/services/dept';
import { getUsersByDept } from '@/services/user';
import { DeptDataNode } from '@/stores/dept';
import { UserDataType } from '@/stores/user';
import { Avatar, Layout, Table, TableProps, Tree } from 'antd';

import './ChoosePeople.less';
import { ChooseModalProps, MFC } from '@/stores/chooseModal';
import { useForwardedRef } from '@/services/chooseModal';
import BaseModel from './BaseModel';
import { PaginationRsp } from '@/stores';
//#endregion

interface ModalFormProps extends ChooseModalProps {
  /** 是否可多选，默认false */
  multiple?: boolean;
  /** 已选择列表 */
  selectedRowKeys?: React.Key[];
  // 数据行关键字
  rowKey?: string;
  /** 自定义人员列表渲染 */
  userListRender?: (text: any, record: UserDataType) => JSX.Element;
}
/**
 * 人员选择框
 * @param props
 * @param modalInstance
 * @returns
 */
const ChoosePeople: MFC<UserDataType, ModalFormProps> = (
  { height, ...props },
  modalInstance,
) => {
  //获取继承的BaseModel组件ref（需转换ref类型）
  const modalRef = useForwardedRef(modalInstance);
  //默认高度
  if (!height) {
    height = '300px';
  } else if (typeof height == 'number') {
    height = height.toString() + 'px';
  }
  const {
    // 是否支持多选
    multiple = false,
    // 唯一键
    rowKey = ['name', 'first'],
  } = props;
  // 分页条数
  const pageSize = 4;
  // 组织树数据
  const [deptTreeData, setDeptTreeData] = useState<DeptDataNode[]>([]);
  // 用户列表数据
  const [usersData, setUsersData] = useState<UserDataType[]>([]);
  // 用户列表分页
  const [pagination, setPagination] = useState<PaginationRsp>({
    pageNum: 1,
    total: 0,
    pageSize: pageSize,
  });
  // 组织选择
  const [selectedDept, setSelectedDept] = useState<Key[]>([]);

  // 获取选中人员列表
  const [selectedList, setSelectedList] = useState<UserDataType[]>([]);

  function getValue() {
    return selectedList;
  }
  const setValue = (value: any) => {
    setSelectedList(value);
  };
  const resetFields = () => {
    setSelectedDept([]);
    setSelectedList([]);
    setUsersData([]);
    setPagination({
      pageNum: 1,
      total: 0,
      pageSize: pageSize,
    });
  };

  //#region 组件内部逻辑
  //#region 组织业务逻辑

  //获取所选部门人员数据
  const handleSelectDept = (selectedKeys: Key[]) => {
    setSelectedDept(selectedKeys);
    loadUsers(selectedKeys[0].toString(), 1);
  };
  const loadUsers = useCallback((deptId: string, pageNum: number) => {
    getUsersByDept(deptId, pageNum, pageSize).then((res) => {
      console.log(res);
      const users = Array.isArray(res.data) ? res.data : [res.data];
      setUsersData(users);
      setPagination(res.pageInfo);
    });
  }, []);
  // 选择部门、分页变化时，重新获取数据
  // useEffect(() => {
  //   loadUsers(pagination);
  // }, [loadUsers, pagination, selectedDept]);

  // 初始化组织数据
  useEffect(() => {
    getDepts().then((res) => {
      setDeptTreeData(res);
    });
  }, []);
  //#endregion

  //#region 人员业务逻辑
  // 人员表格列配置
  const columns: TableProps<UserDataType>['columns'] = [
    {
      // title: '姓名',
      dataIndex: rowKey,
      render:
        props.userListRender ??
        ((text: any, record: UserDataType) => (
          <div className="nbl-choose-people-item-meta">
            <div className="nbl-choose-people-item-meta-avatar">
              <Avatar
                src={record.picture.large}
                className={'nbl-avatar-circle nbl-avatar-image'}
              />
            </div>
            <div className="nbl-list-item-meta-content">
              <h4 className="nbl-list-item-meta-title">{text}</h4>
              <div className="nbl-list-item-meta-description">
                {record.email}
              </div>
            </div>
          </div>
        )),
    },
  ];
  const pageChange = useCallback(
    (page: number, _pageSize: number) => {
      setPagination({
        ...pagination,
        pageNum: page,
      });
      loadUsers(selectedDept[0].toString(), page);
    },
    [loadUsers, pagination, selectedDept],
  );
  const rowSelection: TableProps<UserDataType>['rowSelection'] = {
    type: multiple ? 'checkbox' : 'radio',
    onChange(selectedRowKeys, selectedRows) {
      setSelectedList(selectedRows);
      console.log(
        `selectedRowKeys: ${selectedRowKeys}`,
        'selectedRows: ',
        selectedRows,
      );
    },
    onSelect(record, selected, selectedRows) {
      console.log(record, selected, selectedRows);
    },
    onSelectAll(selected, selectedRows, changeRows) {
      console.log(selected, selectedRows, changeRows);
    },
  };
  //#endregion
  //#endregion
  return (
    <BaseModel
      className="nbl-choose-people"
      destroyOnClose
      ref={modalRef}
      width={500}
      {...props}
      title="人员选择"
      onChange={setValue}
      onGetValue={getValue}
      onReset={resetFields}
    >
      <Layout>
        <Layout.Sider
          width={150}
          style={{
            height: height,
            overflow: 'auto',
          }}
        >
          <Tree treeData={deptTreeData} onSelect={handleSelectDept} />
        </Layout.Sider>
        <Layout.Content>
          <Table
            scroll={{ y: `calc(${height} - 36px)` }}
            rowKey={props.rowKey ?? 'id'}
            rowSelection={rowSelection}
            columns={columns}
            dataSource={usersData}
            showHeader={false}
            bordered={false}
            pagination={{
              style: { margin: 0, marginTop: '4px' },
              hideOnSinglePage: true,
              // showSizeChanger: true,
              // defaultPageSize: 3,
              // showQuickJumper: true,
              pageSize: pagination.pageSize,
              current: pagination.pageNum,
              total: pagination.total,
              onChange: pageChange,
            }}
          />
        </Layout.Content>
      </Layout>
    </BaseModel>
  ) as ReactElement;
};
ChoosePeople.typeName = 'ChooseModal';

/** 人员选择框 */
export default memo(forwardRef(ChoosePeople));
