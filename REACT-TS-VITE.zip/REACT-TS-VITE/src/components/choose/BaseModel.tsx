import { useResetModalOnCloseModal } from '@/services/chooseModal';
import { MFC } from '@/stores/chooseModal';
import { Modal } from 'antd';
import {
  forwardRef,
  memo,
  useCallback,
  useImperativeHandle,
  useState,
} from 'react';
import { createPortal } from 'react-dom';

/**
 * 空的Model
 * 没有数据维护
 * 非只读框，不建议直接使用，用于二次封装
 *
 * @param props
 * @param modalInstance
 * @returns
 */

const BaseModel: MFC = (props, modalInstance) => {
  const { title = '弹窗' } = props;
  const [open, setOpen] = useState(false);
  // const [loading, setLoading] = useState(false);

  const handleReset = () => {
    if (props.onReset) {
      props.onReset();
    }
  };

  // 弹窗-确定操作
  const handleOk = () => {
    handleFinish(); // 不启用Form，手动验证，手动触发确认操作
  };

  //#region 需要暴露的内部方法实体
  // 设值
  const setValue = useCallback(
    (value: any) => {
      if (props.onChange) {
        props.onChange(value);
      }
    },
    [props],
  );
  // 取值
  const getValue = useCallback(() => {
    if (props.onGetValue) {
      return props.onGetValue();
    }
  }, [props]);

  // 打开窗体（赋初值）
  const handleOpen = useCallback(
    (value?: any) => {
      if (value != undefined) {
        setValue(value);
      }
      setOpen(true);
    },
    [setValue],
  );
  // 取消操作（关闭窗体）
  const handleCancel = useCallback(() => {
    setOpen(false);
  }, []);
  // 确认操作
  const handleFinish = () => {
    if (props.onFinish) {
      // 返回false中止
      if (props.onFinish(getValue()) === false) {
        return;
      }
    }
    handleCancel();
  };
  //#endregion

  //重置数据
  useResetModalOnCloseModal({
    reset: handleReset,
    open,
  });

  // 通过Ref对外暴露属性和方法
  useImperativeHandle(
    modalInstance,
    () => ({
      open: handleOpen,
      close: handleCancel,
      getValue: getValue,
    }),
    [handleOpen, handleCancel, getValue],
  );

  /** 弹窗渲染到外部与root同级的div#modal-root中 */
  const modalRoot = document.getElementById('modal-root') as HTMLElement;

  /**
   * ReactDOM.createPortal用于将ReactElement绘制到指定元素中，且事件传递关系不变。
   */
  return createPortal(
    <Modal
      // confirmLoading={loading}
      cancelText="取消"
      okText="确定"
      width={400}
      title={title}
      {...props}
      bodyStyle={{
        padding: '10px',
        minHeight: props.height ?? 'auto',
        maxHeight: props.height ?? 'auto',
        ...props.bodyStyle,
      }}
      className={`nbl-choose nbl-choose-pupup ${props.className}`}
      open={open}
      onOk={handleOk}
      onCancel={handleCancel}
    >
      {props.children}
    </Modal>,
    modalRoot,
  );
};
BaseModel.typeName = 'ChooseModal';
export default memo(forwardRef(BaseModel));
