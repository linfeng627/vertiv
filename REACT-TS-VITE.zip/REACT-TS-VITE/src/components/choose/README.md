# 模式弹窗结构

```text
BaseModel.tsx ➜ ChoosePopup.tsx  ➜ 基于Form获取数据的模式窗体
              ➜ ChooseDept.tsx
              ➜ ChoosePeople.tsx
```

```text
BaseModel.tsx ➜ 基于子维护数据的模式窗体
ChoosePopup.tsx ➜ 基于Form获取数据的模式窗体
ChooseDept.tsx ➜
ChoosePeople.tsx ➜
```
