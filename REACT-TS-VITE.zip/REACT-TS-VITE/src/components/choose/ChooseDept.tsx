//#region 导入
import {
  forwardRef,
  Key,
  memo,
  ReactElement,
  useEffect,
  useState,
} from 'react';
import { getDepts } from '@/services/dept';
import { DeptDataNode } from '@/stores/dept';
import { UserDataType } from '@/stores/user';
import { Layout, Tree, TreeProps } from 'antd';

import './ChoosePeople.less';
import { ChooseModalProps, MFC } from '@/stores/chooseModal';
import { useForwardedRef } from '@/services/chooseModal';
import BaseModel from './BaseModel';
//#endregion

interface ModalFormProps extends ChooseModalProps {
  /** 是否可多选，默认false */
  multiple?: boolean;
  // 数据行关键字
  rowKey?: string;
  width?: string | number;
  height?: string | number;
}
/**
 * 人员选择框
 * @param props
 * @param modalInstance
 * @returns
 */
const ChooseDept: MFC<UserDataType, ModalFormProps> = (
  { height, ...props },
  modalInstance,
) => {
  //获取继承的BaseModel组件ref（需转换ref类型）
  const modalRef = useForwardedRef(modalInstance);

  //默认高度
  if (!height) {
    height = '300px';
  } else if (typeof height == 'number') {
    height = height.toString() + 'px';
  }

  const {
    // 是否支持多选
    multiple = false,
    // 唯一键
    rowKey = 'key',
  } = props;

  // 组织树数据
  const [deptTreeData, setDeptTreeData] = useState<DeptDataNode[]>([]);

  const [checkedKeys, setCheckedKeys] = useState<{
    checked: Key[];
    halfChecked: Key[];
  }>();
  const [selectedKeys, setSelectedKeys] = useState<Key[]>([]);
  const [selectedList, setSelectedList] = useState<DeptDataNode[]>([]);

  function getValue() {
    return selectedList;
  }

  const setValue = (value: any) => {
    setSelectedList(value);
    const keys: string[] = [];
    value.forEach((record: any) => {
      keys.push(record[rowKey]);
    });

    setCheckedKeys({
      checked: keys,
      halfChecked: [],
    } as {
      checked: Key[];
      halfChecked: Key[];
    });
  };

  const resetFields = () => {
    setSelectedList([]);
    setSelectedKeys([]);
    setCheckedKeys({
      checked: [],
      halfChecked: [],
    } as {
      checked: Key[];
      halfChecked: Key[];
    });
  };

  useEffect(() => {
    console.log('selectedList变化');
  }, [selectedList]);

  const handleCheck: TreeProps<DeptDataNode>['onCheck'] = (
    checkedKeys,
    info,
  ) => {
    if (multiple) {
      setSelectedList(info.checkedNodes);
    }
    setCheckedKeys(
      checkedKeys as {
        checked: Key[];
        halfChecked: Key[];
      },
    );
    console.log('onCheck', checkedKeys, info);
  };
  const handleSelect: TreeProps<DeptDataNode>['onSelect'] = (
    selectedKeys,
    info,
  ) => {
    if (!multiple) {
      setSelectedList(info.selectedNodes);
    }
    setSelectedKeys(selectedKeys);
    console.log('onSelect', selectedKeys);
  };
  //#region 组件内部逻辑
  //#region 组织业务逻辑
  // 初始化组织数据
  useEffect(() => {
    getDepts().then((res) => {
      setDeptTreeData(res);
    });
  }, []);
  //#endregion

  return (
    <BaseModel
      className="nbl-choose-people"
      destroyOnClose
      ref={modalRef}
      width={500}
      {...props}
      title="部门选择"
      // onFinish={handleFinish}
      onChange={setValue}
      onGetValue={getValue}
      onReset={resetFields}
    >
      <Layout>
        <Layout.Content
          style={{
            height: height,
            overflow: 'auto',
          }}
        >
          <Tree
            checkable={multiple}
            checkStrictly={true}
            checkedKeys={checkedKeys}
            selectedKeys={selectedKeys}
            treeData={deptTreeData}
            onCheck={handleCheck}
            onSelect={handleSelect}
          />
        </Layout.Content>
      </Layout>
    </BaseModel>
  ) as ReactElement;
};
ChooseDept.typeName = 'ChooseModal';
/** 部门选择框 */
export default memo(forwardRef(ChooseDept));
