//#region 导入
import { useForwardedRef } from '@/services/chooseModal';
import { MFC } from '@/stores/chooseModal';
import { Form } from 'antd';
import { forwardRef, memo, ReactElement } from 'react';
import BaseModel from './BaseModel';
//#endregion

/**
 *
 * @param props
 * @param modalInstance
 * @returns
 */
const ChoosePosition: MFC = (props, modalInstance) => {
  const [form] = Form.useForm();
  const { labelCol = { span: '4' } } = props;

  //获取继承的BaseModel组件ref（需转换ref类型）
  const modalRef = useForwardedRef(modalInstance);

  // 弹窗-确定操作
  const handleFinish = () => {
    form.submit();
    return false;
  };
  const handleFormFinish = () => {
    if (props.onFinish) {
      // 返回false中止
      if (props.onFinish(getValue()) === false) {
        return;
      }
    }
    modalRef.current?.close();
  };
  function getValue() {
    return form.getFieldsValue();
  }
  const setValue = (value: any) => {
    form.setFieldsValue(value);
  };

  const resetFields = () => {
    form.resetFields();
  };
  return (
    <BaseModel
      ref={modalRef}
      {...props}
      onFinish={handleFinish}
      onChange={setValue}
      onGetValue={getValue}
      onReset={resetFields}
    >
      <Form
        form={form}
        labelCol={labelCol}
        name="chooseModalForm"
        onFinish={handleFormFinish}
      >
        {props.children}
      </Form>
    </BaseModel>
  ) as ReactElement;
};
ChoosePosition.typeName = 'ChooseModal';

export default memo(forwardRef(ChoosePosition));
