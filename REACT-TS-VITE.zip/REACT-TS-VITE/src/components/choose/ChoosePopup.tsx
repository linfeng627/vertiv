//#region 导入
import { useForwardedRef } from '@/services/chooseModal';
import { MFC } from '@/stores/chooseModal';
import { Form } from 'antd';
import { forwardRef, memo, ReactElement } from 'react';
import BaseModel from './BaseModel';
//#endregion

/**
 * 选择容器窗体（初次封装，目标将操作内置，通过ref对外暴露）
 * @param props Modal组件属性
 * @param modalInstance Modal实例
 * @returns 返回选择容器窗体
 * @example
 * const popup = useRef<ChooseModalInstance>(null);
 * function open() {
 *   popup.current!.open();
 * }
 * ...
 * <ChoosePopup ref={popup} onFinish={(value) => console.log(value)} />
 * <Button onClick={() => {open(null)}}>不回显值</Button>
 */
const ChoosePopup: MFC = (props, modalInstance) => {
  const [form] = Form.useForm();
  const { labelCol = { span: '4' } } = props;

  //获取继承的BaseModel组件ref（需转换ref类型）
  const modalRef = useForwardedRef(modalInstance);

  // 弹窗-确定操作
  const handleFinish = () => {
    form.submit();
    return false;
  };
  const handleFormFinish = () => {
    if (props.onFinish) {
      // 返回false中止
      if (props.onFinish(getValue()) === false) {
        return;
      }
    }
    modalRef.current?.close();
  };
  function getValue() {
    return form.getFieldsValue();
  }
  const setValue = (value: any) => {
    form.setFieldsValue(value);
  };

  const resetFields = () => {
    form.resetFields();
  };
  return (
    <BaseModel
      className="nbl-choose-popup"
      ref={modalRef}
      {...props}
      onFinish={handleFinish}
      onChange={setValue}
      onGetValue={getValue}
      onReset={resetFields}
    >
      <Form
        form={form}
        labelCol={labelCol}
        name="chooseModalForm"
        onFinish={handleFormFinish}
      >
        {props.children}
      </Form>
    </BaseModel>
  ) as ReactElement;
};
ChoosePopup.typeName = 'ChooseModal';

export default memo(forwardRef(ChoosePopup));

// //#region 导入
// import {
//   forwardRef,
//   memo,
//   useCallback,
//   useImperativeHandle,
//   useState,
// } from 'react';
// import { createPortal } from 'react-dom';
// import { MFC } from '@/stores/chooseModal';
// import { useResetModalOnCloseModal } from '@/services/chooseModal';
// import { Form, Modal } from 'antd';
// //#endregion

// /**
//  * 选择容器窗体（初次封装，目标将操作内置，通过ref对外暴露）
//  * @param props Modal组件属性
//  * @param modalInstance Modal实例
//  * @returns 返回选择容器窗体
//  * @example
//  * const popup = useRef<ChooseModalInstance>(null);
//  * function open() {
//  *   popup.current!.open();
//  * }
//  * ...
//  * <ChoosePopup ref={popup} onFinish={(value) => console.log(value)} />
//  * <Button onClick={() => {open(null)}}>不回显值</Button>
//  */
// const ChoosePopup: MFC = (props, modalInstance) => {
//   // 是否启用form
//   const enableForm = props.enableForm == undefined || props.enableForm;
//   // 创建表单组件实例(react hooks必须在顶层，所以使用条件包裹“启用form”这句代码，否则报错)
//   const [form] = Form.useForm();

//   const [open, setOpen] = useState(false);
//   // const [loading, setLoading] = useState(false);

//   const handleReset = () => {
//     form.resetFields();
//   };

//   // 弹窗-确定操作
//   const handleOk = () => {
//     form.submit(); // 启用Form，自动调用submit，自动验证通过后触发确认操作
//   };

//   //#region 需要暴露的内部方法实体
//   // 设值
//   const setValue = useCallback(
//     (value: any) => {
//       if (!enableForm && props.onChange) {
//         props.onChange(value);
//       } else {
//         form.setFieldsValue(value);
//       }
//     },
//     [enableForm, form, props],
//   );
//   // 取值
//   const getValue = useCallback(() => {
//     if (!enableForm && props.onGetValue) {
//       return props.onGetValue();
//     } else {
//       return form.getFieldsValue();
//     }
//   }, [enableForm, form, props]);

//   // 打开窗体（赋初值）
//   const handleOpen = useCallback(
//     (value?: any) => {
//       if (value != undefined) {
//         setValue(value);
//       }
//       setOpen(true);
//     },
//     [setValue],
//   );
//   // 取消操作（关闭窗体）
//   const handleCancel = useCallback(() => {
//     setOpen(false);
//   }, []);
//   // 确认操作
//   const handleFinish = () => {
//     if (props.onFinish) {
//       // 返回false中止
//       if (props.onFinish(getValue()) === false) {
//         return;
//       }
//     }
//     handleCancel();
//   };
//   //#endregion

//   //重置数据
//   useResetModalOnCloseModal({
//     reset: handleReset,
//     open,
//   });

//   // 通过Ref对外暴露属性和方法
//   useImperativeHandle(
//     modalInstance,
//     () => ({
//       open: handleOpen,
//       close: handleCancel,
//       getValue: getValue,
//       // modal: enableForm ? form : null,
//     }),
//     [handleOpen, handleCancel, getValue],
//   );

//   let labelCol;
//   if (props.labelCol == undefined) {
//     labelCol = { span: '4' };
//   }

//   /**
//    * 直接使用组件接口已完成。
//    * 目前针对二次封装开发支持需求完善：
//    * 1. 可以不启用内部的Form机制，有二次封装组件接管数据读写和校验。
//    * 通过属性开关，是否激活Form，enableForm。
//    * 涉及方法useResetFormOnCloseModal，useImperativeHandle，setValue，getValue，handleOk
//    * 增加事件onAfterValidateFields开放自定义验证。（得到基类验证结果。不返回则不修改基类判断。返回结果，则以返回为准）
//    * 增加开放读写数据方法props.onSetValue，props.onGetValue
//    *
//    * 2. 二次封装可以自定义属性和暴露接口
//    * 自定义属性可以，但再次暴露需要研究
//    *
//    * 3. 弹窗宽度和高度可自定义
//    *
//    * 3. 选人、选部门组件基于此版整合
//    */

//   /** 弹窗渲染到外部与root同级的div#modal-root中 */
//   const modalRoot = document.getElementById('modal-root') as HTMLElement;

//   /**
//    * ReactDOM.createPortal用于将ReactElement绘制到指定元素中，且事件传递关系不变。
//    */
//   return createPortal(
//     <Modal
//       // confirmLoading={loading}
//       cancelText="取消"
//       okText="确定"
//       bodyStyle={{ padding: '10px', minHeight: '200px' }}
//       width={800}
//       {...props}
//       className={`nbl-choose nbl-choose-pupup ${props.className}`}
//       open={open}
//       onOk={handleOk}
//       onCancel={handleCancel}
//     >
//       <Form
//         form={form}
//         labelCol={labelCol}
//         name="chooseModalForm"
//         onFinish={handleFinish}
//       >
//         {props.children}
//       </Form>
//     </Modal>,
//     modalRoot,
//   );
// };
// ChoosePopup.typeName = 'ChooseModal';
// //使用 forwardRef 包裹 组件
// export default memo(forwardRef(ChoosePopup));
