# 组件层规范

[返回项目结构说明](/src/README.md)
