//#region 导入
import { FC, useEffect, useState } from 'react';
import { Avatar, Steps, Tag } from 'antd';
import { FieldTimeOutlined, UserOutlined } from '@ant-design/icons';
import { getApprovalHistory } from '@/services/approvalHistory';
import {
  ApprovalHistoryChangeEventHandle,
  ApprovalHistoryType,
} from '@/stores/approvalHistory';

import './ApprovalHistory.less';

const { Step } = Steps;
//#endregion

/** 组件属性 */
interface Props {
  /** 流程实例号 */
  procInstId: string;
  /** 历史记录数据变更时间 */
  onChange?: ApprovalHistoryChangeEventHandle;
}

/**
 * 审批历史记录
 * @param props 组件属性
 * @returns 返回组件
 */
const ApprovalHistory: FC<Props> = (props) => {
  const [history, setHistory] = useState<ApprovalHistoryType[]>();
  const { procInstId, onChange } = props;

  // 启动时异步加载审批历史记录数据
  useEffect(() => {
    getApprovalHistory(procInstId).then((res) => {
      setHistory(res);
      if (onChange) {
        onChange({ data: res });
      }
      // [待处理]想要Steps完成步骤也始终显示数字，就需要使用progressDot来自定义步骤元素，但问题是使用了progressDot后Steps会自动增加nbl-steps-dot样式，导致数字样式污染。目前没找到更优雅的方法来破解。暂时通过如下暴力方式破解，后期希望可以找到react渲染完成的钩子，然后来处理替换问题。
      const st = setTimeout(() => {
        const dot = document.querySelector(
          '.nbl-approval-history.nbl-steps-dot',
        );
        if (dot) {
          dot.className = dot.className.replace('nbl-steps-dot', '');
          clearTimeout(st);
        }
      }, 20);
    });
  }, [onChange, procInstId]);

  return (
    <Steps
      direction="vertical"
      className="nbl-approval-history"
      size="small"
      // 组件显示从0开始需加1
      // {(_dot, { status, index }) => <>{index + 1}</>}
      progressDot={(_dot, { index }) => <>{index + 1}</>}
      // 组件计数从0开始，需要从总步骤数减一。
      // 后台返回步骤，包含一个待完成步骤，需减一。
      // 所以已完成步骤数 = 总步骤数 - 2
      current={(history?.length ?? 0) - 2}
      // percent={60}
    >
      {history?.map((step, i) => {
        return (
          <Step
            className="nbl-approval-history-step"
            key={i}
            //显示头像、步骤名、操作、审批人、开始时间、结束时间
            title={
              <>
                <Avatar
                  className="nbl-approval-history-avatar"
                  size="large"
                  icon={<UserOutlined />}
                />
                <div className="nbl-approval-history-card">
                  <p className="nbl-approval-history-card-primary">
                    <span>{step.destActName}</span>
                    {step.action ? (
                      <Tag color="green">{step.action}</Tag>
                    ) : null}
                  </p>
                  <p>
                    <UserOutlined />
                    {step.destUserName}
                  </p>
                  <p className="nbl-approval-history-period">
                    <FieldTimeOutlined />
                    {step.startTime}-{step.endTime}
                  </p>
                </div>
              </>
            }
            description={step.approvalComments}
          />
        );
      })}
    </Steps>
  );
};
export default ApprovalHistory;
