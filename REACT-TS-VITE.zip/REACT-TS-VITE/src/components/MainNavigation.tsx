//#region 导入
import { FC, ReactNode, useEffect, useState } from 'react';
// import { useTranslation } from 'react-i18next';
import { Link as RouterLink, useHref } from 'react-router-dom';

import { Menu } from 'antd';
import { LinksType } from '@/stores/router';
import { getMainNav } from '@/services/router';
import { MenuItem } from '@/stores';
//#endregion

/** Link组件属性 */
interface Props {
  /** 流程实例号 */
  to: string;
  text: ReactNode;
  target?: string; //target: `_blank`,
}

/**
 * 解决router在hash模式下无法Link到target="_blank"新标签中的问题
 * @param props
 * @returns
 */
const Link: FC<Props> = (props: Props) => {
  const text = {
    text: props.text,
    target: props.target,
  };
  return import.meta.env.VITE_APP_HISTORY_MODEL == 'HASH' &&
    props.target != undefined ? (
    <a href={`#/${props.to}`} rel="noreferrer" {...text}>
      {props.text}
    </a>
  ) : (
    <RouterLink {...props}>{props.text}</RouterLink>
  );
};

const getItem = (item: LinksType): MenuItem => {
  if ('key' in item) {
    return {
      label: item.text,
      key: item.key,
      children: getItems(item.children),
    };
  } else {
    return {
      label: <Link {...item}>{item.text}</Link>,
      key: `${item.to}`,
    };
  }
};

const getItems = (items: LinksType[]): MenuItem[] => {
  return items.map<MenuItem>(getItem);
};

/**
 * 平台主导航
 * @returns 返回组件
 */
const MainNavigation: FC = () => {
  // const { t } = useTranslation();
  const [items, setItems] = useState<LinksType[]>([]);
  useEffect(() => {
    getMainNav().then((res) => {
      setItems(res);
    });
  }, []);

  // 获取当前路由
  // const matches = useMatches();
  // matches;
  console.log('trip/TandEView -> ', useHref('trip/TandEView'));
  console.log('trip/TandEView -> ', useHref('#/form/demo/FormView'));
  return (
    <Menu
      className="sidebar-container main-nav"
      defaultSelectedKeys={['/']}
      defaultOpenKeys={['formview']}
      theme="light"
      mode="inline"
      items={getItems(items)}
    />
  );
};
export default MainNavigation;
