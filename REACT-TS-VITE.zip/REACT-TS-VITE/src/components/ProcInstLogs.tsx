import { FC, useState } from 'react';
// import { useTranslation } from 'react-i18next';

import { Card, Tabs } from 'antd';
import ApprovalHistory from './ApprovalHistory';

import './ProcInstLogs.less';

/** 组件属性 */
interface Props {
  /** 流程实例号 */
  procInstId: string;
}

/**
 * 流转记录(流程实例日志)[通用组件]
 * 包含两个标签页：审批记录，传阅记录
 * @param procInstId 流程实例号
 * @returns 返回本组件
 */
const ProcInstLogs: FC<Props> = ({ procInstId }) => {
  // 多语言
  // const { t } = useTranslation();

  // 审批次数
  const [approvalCount, setApprovalCount] = useState(0);
  // 传阅次数[checkCount, setCheckCount]
  const [checkCount] = useState(0);

  // 绘制tabs板块
  const items = [
    {
      label: `审批记录(${approvalCount})`,
      key: 'approval-history',
      className: 'nbl-approval-history-container',
      children: (
        <ApprovalHistory
          procInstId={procInstId}
          onChange={(e) => {
            setApprovalCount(e.data.length);
          }}
        ></ApprovalHistory>
      ),
    },
    {
      label: `传阅记录(${checkCount})`,
      key: 'circulation_records',
      children: '没有记录',
    },
  ];

  return <Tabs items={items} className="nbl-procinst-logs" />;
};
export default ProcInstLogs;
