//#region 导入
import { createElement, FC, PropsWithChildren, useState } from 'react';
// import { useTranslation } from 'react-i18next';

import { MenuFoldOutlined, MenuUnfoldOutlined } from '@ant-design/icons';
import { Layout, Row } from 'antd';
//#endregion

/** 组件属性 */
// interface Props {
// }

/**
 * 平台顶部组件
 * @param params 组件属性
 * @returns 返回组件
 */
const MainHeader: FC<PropsWithChildren> = ({ children }) => {
  // const { t } = useTranslation();
  const [collapsed, setCollapsed] = useState(false);

  const toggleCollapsed = () => {
    setCollapsed(!collapsed);
  };

  return (
    <Layout.Header className="nbl-main-header main-header">
      <Row align="middle">
        <a href="form" className="nbl-logo">
          <img src="/logo.png" className="logo" alt="NBL logo" />
          {/* <h1>平台标题</h1> */}
        </a>
        {createElement(collapsed ? MenuUnfoldOutlined : MenuFoldOutlined, {
          className: 'trigger',
          onClick: toggleCollapsed,
        })}
        {children}
      </Row>
    </Layout.Header>
  );
};
export default MainHeader;
