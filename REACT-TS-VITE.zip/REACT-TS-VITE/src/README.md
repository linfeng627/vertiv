# 项目原文件目录结构说明

---

## 目录结构

- .cert ➜ HTTPS 证书
- .env ➜ 环境变量地址
  - `.env` ➜ 默认环境变量配置文件，适用于所有环境
  - `.env.development` ➜ 开发环境环境变量配置文件（合并覆盖默认环境变量,pnpm run dev）
  - `.env.production` ➜ 生产环境环境变量配置文件（合并覆盖默认环境变量,pnpm run bulid）
  - `env.d.ts` ➜ 环境变量 TS 类型声明
- .vscode ➜ 保存 VsCode 自定义配置
  - `*`.code-snippets ➜ 在 vscode 里可以定义代码片段模板，方便快速开发
- public ➜ 静态资源文件，`build`时此目录原封不动一起打包。代码中直接使用`/`调用此间文件
- docs ➜ 帮助文档
- src ➜ 项目应用源码
  - assets ➜ 通用静态目录（图片、字体、样式）
    - styles ➜ 样式目录
  - layouts ➜ 布局目录（`layouts`）
  - components ➜ 通用组件目录（`component`）
  - locales ➜ 通用多语言目录
    - `en-us.json` ➜ 英文语言包
    - `zh-cn.json` ➜ 中文语言包
  - router ➜ 通用路由配置目录
    - index.tsx ➜ 定义路由地址，路由懒加载
  - services ➜ 通用业务逻辑目录
  - stores ➜ 通用业务数据模型目录
  - tests ➜ 测试目录
    - \_\_tests\_\_ ➜ 测试用例目录（vitest 测试工具会自动测试.spec.ts 结尾文件）
      - `001_xxx.spec.ts` ➜ 测试用例代码，后缀`.spec.ts`
    - `test.http` ➜ 接口测试
  - utils ➜ 通用工具类目录
    - `i18n.ts` ➜ 多语言封装
    - `request.ts` ➜ 请求二次封装
  - views ➜ 路由视图目录（`view`）
    - `LoginView.tsx` ➜ 简单视图页面（仅单独一个文件即可）
    - demo ➜ 复杂视图页面（可以作为一个独立包，便于重构）
      - components ➜ 专用组件
        - `DemoList.tsx`
      - services ➜ 专业业务逻辑
      - stores ➜ 专业数据模型
      - `DemoView.tsx` ➜ 复杂视图主页
  - `App.tsx` ➜ 单例应用
  - `main.tsx` ➜ 主框架
- `index.html` ➜ 项目应用主页，引入 src/main.tsx
- `package.json` ➜ 包配置
- `tsconfig.json` ➜ TS 支持相关配置
- `vite.config.ts` ➜ VITE 统一配置

---

注：关于 layouts、views、components 目录用法，参考`项目规范文档`中[组件开发规范](/docs/specification.md)章节

[返回主页](/README.md)
