import { FormBlock } from '../001_partial2';

const aa = {
  key: 'af',
  initialValues: 'd',
  header: 'ds',
};
describe('数据检测', () => {
  test('count = 1', () => {
    const a = FormBlock(aa);
    expect(a.header).toBe(1);
  });
});
