import { count } from '../000_ref';

describe('数据检测', () => {
  test('count = 1', () => {
    expect(count).toBe(1);
  });
});
