import { Partial2 } from '@/utils';

export type CollapsePanelProps = {
  header: string;
  key: string | number;
};

// 将CollapsePanelProps接口中header属性改为可选
export type CollapsePanelProps2 = Partial2<CollapsePanelProps, 'header'>;

// 追加自定义属性（或给继承属性增加JsDoc注释）
export interface Props extends CollapsePanelProps2 {
  /** 板块标识 */
  key: string | number;
  /** 初始值 */
  initialValues: string;
}

/**
 * 表单板块（模板）
 * @param props 表单板块类型
 * @returns
 */
export const FormBlock = (props: Props) => {
  // 注：Collapse.Panel不能通过React.FC创建，直接箭头函数即可
  const cpProps = {
    header: '222', //赋默认值
    ...props,
  };

  return cpProps;
};
